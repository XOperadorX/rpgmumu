<?php
session_start();
include "db.php";

if(!isset($_SESSION['dungeon'])){
    die(json_encode(["erro"=>"Dungeon não iniciada."]));
}

$dungeon = &$_SESSION['dungeon'];
$char = &$dungeon['char'];
$enemies = &$dungeon['enemies'];
$idx = $dungeon['current'];

if($idx >= count($enemies)){
    echo json_encode([
        "fim"=>true,
        "char"=>$char,
        "enemy"=>null,
        "log"=>$dungeon['log']
    ]);
    exit;
}

$enemy = &$enemies[$idx];
$log = [];

// turno do player
$dano = rand(5,15);
$enemy['HP'] -= $dano;
$log[] = "{$char['Name']} atacou {$enemy['Name']} causando {$dano} de dano!";

// inimigo morre
if($enemy['HP'] <= 0){
    $log[] = "{$enemy['Name']} foi derrotado! 🎉";
    $char['Exp'] += $enemy['XP'];

    // upar de level
    if($char['Exp'] >= $char['Level']*50){
        $char['Exp'] = 0;
        $char['Level']++;
        $char['MaxHP'] += 10;
        $char['MaxMana'] += 5;
        $char['HP'] = $char['MaxHP'];
        $char['Mana'] = $char['MaxMana'];
        $log[] = "⬆️ {$char['Name']} subiu para o nível {$char['Level']}!";
    }

    // loot
    if(isset($enemy['Loot'])){
        foreach($enemy['Loot'] as $item){
            $log[] = "💎 Encontrou item: {$item}";
            $dungeon['loot'][] = $item;
            sqlsrv_query($conn, "INSERT INTO Items (CharID, Name) VALUES (?, ?)", [$char['CharID'], $item]);
        }
    }

    // próximo inimigo
    $dungeon['current']++;
    if($dungeon['current'] >= count($enemies)){
        echo json_encode([
            "fim"=>true,
            "char"=>$char,
            "enemy"=>null,
            "log"=>$log
        ]);
        $_SESSION['dungeon'] = $dungeon;
        exit;
    }
    $enemy = &$enemies[$dungeon['current']];
}

// turno do inimigo (se ainda estiver vivo)
if($enemy['HP'] > 0){
    $danoInimigo = rand(3,12);
    $char['HP'] -= $danoInimigo;
    $log[] = "{$enemy['Name']} atacou causando {$danoInimigo} de dano!";
    if($char['HP'] <= 0){
        $char['HP'] = 0;
        $log[] = "☠️ {$char['Name']} foi derrotado!";
        echo json_encode([
            "fim"=>true,
            "char"=>$char,
            "enemy"=>$enemy,
            "log"=>$log
        ]);
        $_SESSION['dungeon'] = $dungeon;
        exit;
    }
}

// salva
$dungeon['char'] = $char;
$dungeon['enemies'] = $enemies;
$dungeon['log'] = $log;
$_SESSION['dungeon'] = $dungeon;

// resposta JSON completa
echo json_encode([
    "fim"=>false,
    "char"=>$char,
    "enemy"=>[
        "Name"=>$enemy['Name'],
        "Level"=>$enemy['Level'],   // 👈 sempre enviado
        "XP"=>$enemy['XP'],         // 👈 sempre enviado
        "HP"=>$enemy['HP'],
        "MaxHP"=>$enemy['MaxHP'],
        "Mana"=>$enemy['Mana'],
        "MaxMana"=>$enemy['MaxMana']
    ],
    "log"=>$log,
    "loot"=>isset($dungeon['loot']) ? $dungeon['loot'] : []
]);
