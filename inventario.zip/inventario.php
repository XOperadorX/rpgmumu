<?php
session_start();
include "db.php";
include "check_ban.php";

if(!isset($_SESSION['PlayerID'])){
    die("⛔ Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// ==========================
// Nome do personagem
// ==========================
$stmtChar = sqlsrv_query($conn, "SELECT Name FROM dbo.Characters WHERE PlayerID = ?", [$playerID]);
if($stmtChar === false){
    die("Erro ao buscar personagem: " . print_r(sqlsrv_errors(), true));
}
$char = sqlsrv_fetch_array($stmtChar, SQLSRV_FETCH_ASSOC);
$nomeJogador = htmlspecialchars($char['Name'] ?? 'Desconhecido');

// ==========================
// Saldo de moedas
// ==========================
$stmtMoedas = sqlsrv_query($conn, "SELECT MoedaMumu FROM dbo.Players WHERE PlayerID = ?", [$playerID]);
if($stmtMoedas === false){
    die("Erro ao buscar saldo: " . print_r(sqlsrv_errors(), true));
}
$player = sqlsrv_fetch_array($stmtMoedas, SQLSRV_FETCH_ASSOC);
$saldo = intval($player['MoedaMumu'] ?? 0);

// ==========================
// Inventário direto do banco
// ==========================
$inventario = [];
$stmtItens = sqlsrv_query($conn, "
    SELECT ItemID, Nome, Quantidade, Descricao, DataAdquirido, PodeUsar, PodeMarcarLixo,
           PodeEnviarArmazem, PodeSoltar, Raridade, Valor, Categoria
    FROM dbo.Items
    WHERE PlayerID = ?
", [$playerID]);

if($stmtItens === false){
    die("Erro ao buscar inventário: " . print_r(sqlsrv_errors(), true));
}

while($row = sqlsrv_fetch_array($stmtItens, SQLSRV_FETCH_ASSOC)){
    if(!isset($row['ItemID'])) continue;

    $raridade = strtolower(trim($row['Raridade'] ?? 'comum'));
    $inventario[$row['ItemID']] = [
        'nome' => htmlspecialchars($row['Nome'] ?? 'Item Desconhecido'),
        'qtd' => intval($row['Quantidade'] ?? 0),
        'descricao' => htmlspecialchars($row['Descricao'] ?? ''),
        'data' => isset($row['DataAdquirido']) && $row['DataAdquirido'] instanceof DateTime ? 
                    $row['DataAdquirido']->format('d/m/Y H:i') : '',
        'pode_usar' => !empty($row['PodeUsar']),
        'pode_marcar_lixo' => !empty($row['PodeMarcarLixo']),
        'pode_enviar_armazem' => !empty($row['PodeEnviarArmazem']),
        'pode_soltar' => !empty($row['PodeSoltar']),
        'raridade' => $raridade,
        'valor' => intval($row['Valor'] ?? 0),
        'categoria' => $row['Categoria'] ?? 'geral'
    ];
}

// ==========================
// Cores por raridade
// ==========================
$cores = [
    'comum' => 'gray',
    'incomum' => 'green',
    'raro' => 'blue',
    'épico' => 'purple',
    'lendário' => 'orange'
];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Inventário - RPGMumu</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&display=swap" rel="stylesheet">
<style>
body { font-family:'Orbitron',sans-serif; background:#0a0a1f; color:#0ff; margin:0; text-align:center; padding:20px; }
#inventario-container { width:90%; margin:20px auto; background:#111; padding:15px; border-radius:10px; box-shadow:0 0 20px #0ff,0 0 40px #0ff inset; }
#inventario-container table { width:100%; border-collapse:collapse; }
th, td { padding:10px; border:1px solid #333; text-align:center; }
th { background:linear-gradient(90deg,#ff00ff,#00ffff); color:#fff; text-transform:uppercase; }
.item-box { cursor:pointer; transition: all 0.2s ease-in-out; }
.item-box:hover { box-shadow:0 0 15px #ff0,0 0 30px #f0f inset; transform:scale(1.05); }
button.vender-btn { background:#e74c3c; color:#fff; border:none; padding:8px 15px; border-radius:5px; cursor:pointer; transition: all 0.2s ease-in-out; }
button.vender-btn:hover { background:#c0392b; transform:scale(1.05); }
button.vender-btn:disabled { background:#555; cursor:not-allowed; }
#mensagem { margin-top:15px; font-weight:bold; color:#0ff; text-shadow:0 0 5px #0ff; }
a.botao { color:#fff; text-decoration:none; background: linear-gradient(90deg,#3498db,#9b59b6); padding:10px 15px; border-radius:5px; margin:5px; display:inline-block; transition: all 0.2s ease-in-out; }
a.botao:hover { background: linear-gradient(90deg,#2980b9,#8e44ad); transform:scale(1.05); }
.item-descricao { font-size:0.9em; color:#ccc; margin-top:4px; }
</style>
</head>
<body>

<nav style="display:flex; justify-content:center; align-items:center; margin:20px;">
    <a href="dashboard.php" class="botao">⬅ 🏰 Inicio</a>
</nav>

<h1>📦 Inventário de Itens</h1>
<p>Jogador: <strong><?= $nomeJogador ?></strong> | Saldo: <span id="saldo"><?= $saldo ?> 💰</span></p>

<div id="inventario-container">
<table>

<tr><th>Item</th>
<tr><th>Descricao</th>
<th>Quantidade</th>
<th>Valor</th>
<th>Ação</th></tr>

<?php foreach($inventario as $itemID => $dados):
    if(!is_array($dados)) continue;
    if(intval($dados['qtd']) <= 0) continue;
    $cor = $cores[$dados['raridade']] ?? 'white';
?>
<tr style="border-left:5px solid <?= $cor ?>" 
    data-itemid="<?= $itemID ?>" 
    data-nome="<?= htmlspecialchars($dados['nome']) ?>" 
    data-valor="<?= intval($dados['valor']) ?>" 
    data-pode-soltar="<?= intval($dados['pode_soltar']) ?>">
    
    <td class="item-box" onclick="equiparItem('<?= $itemID ?>')">
        <strong style="color:<?= $cor ?>"><?= htmlspecialchars($dados['nome']) ?></strong>
        <?php if(!empty($dados['descricao'])): ?>
            <div class="item-descricao"><?= nl2br($dados['descricao']) ?></div>
        <?php endif; ?>
    </td>
    <td class="qtd"><?= intval($dados['qtd']) ?></td>
    <td>💰 <?= intval($dados['valor']) ?></td>
    <td>
        <button class="vender-btn" onclick="venderItem(this)" <?= empty($dados['pode_soltar']) ? 'disabled' : '' ?>>Vender</button>
    </td>
</tr>
<?php endforeach; ?>
</table>
</div>

<div id="mensagem"></div>
<div id="equipamentos" style="margin-top:20px;"></div>

<script>
function venderItem(btn){
    const row = btn.closest('tr');
    const itemID = row.dataset.itemid;
    const valor = row.dataset.valor;
    const nome = row.dataset.nome;

    fetch('vender_item.php', {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'itemID='+itemID+'&valor='+valor+'&nome='+encodeURIComponent(nome)
    }).then(r=>r.json()).then(res=>{
        const msg = document.getElementById('mensagem');
        if(res.sucesso){
            const qtdEl = row.querySelector('.qtd');
            if(res.nova_qtd <= 0){
                row.remove();
            } else {
                qtdEl.innerText = res.nova_qtd;
            }
            document.getElementById('saldo').innerText = res.novo_saldo + " 💰";
            msg.style.color = '#0f0';
            msg.innerText = 'Item vendido! +' + res.moedas + ' moedas';
        } else {
            msg.style.color = '#f00';
            msg.innerText = res.mensagem;
        }
    });
}

function equiparItem(itemID){
    fetch('equipamento.php',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'ItemID='+itemID
    }).then(r=>r.json()).then(data=>{
        const msg = document.getElementById('mensagem');
        if(data.success){
            msg.style.color='#0f0';
            msg.innerText='Item equipado: '+data.nome;
            atualizarEquipamentos();
        } else {
            msg.style.color='#f00';
            msg.innerText='Erro: '+data.error;
        }
    });
}

function atualizarEquipamentos(){
    fetch('mostrar_equipamentos.php')
    .then(r=>r.text())
    .then(html=>{ document.getElementById('equipamentos').innerHTML = html; });
}

atualizarEquipamentos();
</script>

</body>
</html>
