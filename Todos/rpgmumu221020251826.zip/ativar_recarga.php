<?php
session_start();
include "db.php";
include "check_ban.php";

if (!isset($_SESSION['PlayerID'])) {
    die("⛔ Faça login primeiro.");
}

$playerID = $_SESSION['PlayerID'];

// Define data de expiração: agora + 1 dias
$expiraEm = date('Y-m-d H:i:s', strtotime('+1 days'));

// Atualiza no banco
$sql = "UPDATE Players SET RecargaExpiraEm = ? WHERE PlayerID = ?";
$stmt = sqlsrv_query($conn, $sql, [$expiraEm, $playerID]);

if ($stmt) {
    echo "✅ Recarga total ativada até $expiraEm!";
} else {
    echo "⚠️ Erro ao ativar recarga.";
}
?>
