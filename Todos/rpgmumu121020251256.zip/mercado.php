<?php
session_start();
include "db.php";
include "check_ban.php";

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login primeiro.");
}

$playerID = $_SESSION['PlayerID'];

// 🔹 Puxa dados do jogador
$sql = "SELECT Username, MoedaMumu, CarteiraJSON FROM Players WHERE PlayerID = ?";
$stmt = sqlsrv_query($conn, $sql, [$playerID]);
if($stmt === false){ die(print_r(sqlsrv_errors(), true)); }
$player = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

$username = $player['Username'];
$moedas = $player['MoedaMumu'];
$carteira = json_decode($player['CarteiraJSON'], true) ?: [];

// =====================================================================
// 🔹 VENDA DE ITEM
// =====================================================================
if(isset($_POST['vender'])){
    $itemID = intval($_POST['item_id']);
    $quantidade = intval($_POST['quantidade']);
    $preco = floatval($_POST['preco']);

    if($quantidade > 0 && $preco > 0 && isset($carteira[$itemID]) && $carteira[$itemID] >= $quantidade){
        // Remove do inventário
        $carteira[$itemID] -= $quantidade;
        if($carteira[$itemID] <= 0) unset($carteira[$itemID]);

        // Atualiza mercado
        $sql = "INSERT INTO Mercado (VendedorID, ItemID, Quantidade, PrecoMoedaMumu) VALUES (?, ?, ?, ?)";
        $stmt = sqlsrv_query($conn, $sql, [$playerID, $itemID, $quantidade, $preco]);
        if($stmt === false){ die(print_r(sqlsrv_errors(), true)); }

        // Atualiza carteira
        $json = json_encode($carteira);
        sqlsrv_query($conn, "UPDATE Players SET CarteiraJSON = ? WHERE PlayerID = ?", [$json, $playerID]);

        // Histórico
        $sql = "INSERT INTO HistoricoTransacoes (VendedorID, ItemID, Quantidade, PrecoMoedaMumu, Tipo) VALUES (?, ?, ?, ?, 'VENDA')";
        sqlsrv_query($conn, $sql, [$playerID, $itemID, $quantidade, $preco]);
    }
}

// =====================================================================
// 🔹 COMPRA DE ITEM
// =====================================================================
if(isset($_POST['comprar'])){
    $mercadoID = intval($_POST['mercado_id']);

    // Busca item no mercado
    $sql = "SELECT * FROM Mercado WHERE MercadoID = ?";
    $stmt = sqlsrv_query($conn, $sql, [$mercadoID]);
    if($stmt === false){ die(print_r(sqlsrv_errors(), true)); }
    $item = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
    if(!$item) die("Item não encontrado no mercado.");

    $total = $item['PrecoMoedaMumu'];

    if($moedas >= $total){
        // Atualiza comprador
        $moedas -= $total;
        $carteira[$item['ItemID']] = ($carteira[$item['ItemID']] ?? 0) + $item['Quantidade'];
        $json = json_encode($carteira);
        sqlsrv_query($conn, "UPDATE Players SET MoedaMumu = ?, CarteiraJSON = ? WHERE PlayerID = ?", [$moedas, $json, $playerID]);

        // Atualiza vendedor
        sqlsrv_query($conn, "UPDATE Players SET MoedaMumu = MoedaMumu + ? WHERE PlayerID = ?", [$total, $item['VendedorID']]);

        // Histórico
        $sql = "INSERT INTO HistoricoTransacoes (CompradorID, VendedorID, ItemID, Quantidade, PrecoMoedaMumu, Tipo) VALUES (?, ?, ?, ?, ?, 'COMPRA')";
        sqlsrv_query($conn, $sql, [$playerID, $item['VendedorID'], $item['ItemID'], $item['Quantidade'], $item['PrecoMoedaMumu']]);

        // Remove do mercado
        sqlsrv_query($conn, "DELETE FROM Mercado WHERE MercadoID = ?", [$mercadoID]);
    }
}

// =====================================================================
// 🔹 Puxa itens do mercado
// =====================================================================
$sql = "SELECT m.MercadoID, m.ItemID, m.Quantidade, m.PrecoMoedaMumu, p.Username AS Vendedor, i.Nome AS ItemNome
        FROM Mercado m
        JOIN Players p ON m.VendedorID = p.PlayerID
        JOIN Itens i ON m.ItemID = i.ItemID
        ORDER BY m.MercadoID DESC";
$stmtMercado = sqlsrv_query($conn, $sql);
if($stmtMercado === false){ die(print_r(sqlsrv_errors(), true)); }

// =====================================================================
// 🔹 Puxa histórico
// =====================================================================
$sql = "SELECT h.Tipo, h.Quantidade, h.PrecoMoedaMumu, i.Nome AS ItemNome, 
               c.Username AS Comprador, v.Username AS Vendedor, h.DataTransacao
        FROM HistoricoTransacoes h
        LEFT JOIN Players c ON h.CompradorID = c.PlayerID
        LEFT JOIN Players v ON h.VendedorID = v.PlayerID
        JOIN Itens i ON h.ItemID = i.ItemID
        ORDER BY h.HistoricoID DESC";
$stmtHistorico = sqlsrv_query($conn, $sql);
if($stmtHistorico === false){ die(print_r(sqlsrv_errors(), true)); }

// =====================================================================
// 🔹 Puxa nomes dos itens do inventário
// =====================================================================
$itensNome = [];
if(count($carteira) > 0){
    $ids = implode(',', array_keys($carteira));
    $sql = "SELECT ItemID, Nome FROM Itens WHERE ItemID IN ($ids)";
    $stmt = sqlsrv_query($conn, $sql);
    if($stmt !== false){
        while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)){
            $itensNome[$row['ItemID']] = $row['Nome'];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Mercado Público - MoedaMumu</title>
<style>
body { background:#1e1e2f; color:#fff; font-family:Arial; text-align:center; }
h2 { color:#00ffff; }
table { width:80%; margin:auto; border-collapse:collapse; }
th, td { padding:8px; border:1px solid #555; }
th { background:#333; }
form { margin:10px; }
input, button { padding:5px; }

/* ====== CABEÇALHO ====== */
nav {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: rgba(30,30,30,0.9);
    padding: 15px 30px;
    box-shadow: 0 0 15px rgba(255,204,0,0.2);
    border-bottom: 2px solid #ffcc00;
    backdrop-filter: blur(6px);
    animation: fadeDown 0.8s ease-in-out;
}
@keyframes fadeDown {
    from { opacity: 0; transform: translateY(-20px); }
    to { opacity: 1; transform: translateY(0); }
}
nav a, nav button {
    background: none;
    border: none;
    color: #ffcc00;
    font-size: 1rem;
    font-weight: bold;
    text-decoration: none;
    cursor: pointer;
    transition: color 0.3s, transform 0.2s;
}
nav a:hover, nav button:hover {
    color: #00ccff;
    transform: scale(1.1);
}

/* ====== TÍTULOS ====== */
h1 {
    color: #ffcc00;
    text-shadow: 0 0 10px rgba(255,204,0,0.8);
    margin-top: 25px;
    letter-spacing: 2px;
    animation: pulseGold 2s infinite alternate;
}
@keyframes pulseGold {
    from { text-shadow: 0 0 5px #ffcc00; }
    to { text-shadow: 0 0 20px #ff9900; }
}
h2 {
    color: #00ccff;
    margin-top: 25px;
    text-shadow: 0 0 8px rgba(0,204,255,0.6);
}

/* ====== CARD PRINCIPAL ====== */
.card {
    background: linear-gradient(160deg, #242424, #181818);
    padding: 25px;
    border-radius: 15px;
    margin: 30px auto;
    width: 90%;
    max-width: 420px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.6);
    border: 1px solid rgba(255,255,255,0.05);
    animation: floatCard 4s ease-in-out infinite;
}
@keyframes floatCard {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-5px); }
}

/* ====== FORMULÁRIO ====== */
form { margin-top: 10px; }
label { display: block; margin-bottom: 5px; color: #ccc; }
input[type=number] {
    width: 100px;
    padding: 6px 8px;
    border-radius: 6px;
    border: 1px solid #555;
    background: #1c1c1c;
    color: #fff;
    text-align: center;
    transition: border 0.3s, background 0.3s, box-shadow 0.3s;
}
input[type=number]:focus {
    border-color: #00ccff;
    background: #2b2b2b;
    box-shadow: 0 0 10px #00ccff55;
    outline: none;
}

/* ====== BOTÕES ====== */
button {
    padding: 10px 15px;
    border-radius: 8px;
    border: none;
    cursor: pointer;
    margin: 5px;
    background: linear-gradient(145deg, #ffcc00, #ff8800);
    color: #000;
    font-weight: bold;
    transition: all 0.3s ease;
    box-shadow: 0 0 10px rgba(255,204,0,0.3);
}
button:hover {
    background: linear-gradient(145deg, #ffee55, #ffaa00);
    transform: scale(1.08);
    box-shadow: 0 0 20px rgba(255,204,0,0.7);
}

/* ====== LINKS E BOTÕES GERAIS ====== */
.btn {
    display: inline-block;
    margin: 10px;
    padding: 10px 20px;
    border-radius: 8px;
    text-decoration: none;
    color: #fff;
    background: #333;
    font-weight: bold;
    transition: all 0.3s ease;
}
.btn:hover {
    background: #ffcc00;
    color: #000;
    box-shadow: 0 0 15px #ffcc0077;
}

</style>
</head>
<body>
<nav style="display:flex; justify-content:center; align-items:center; margin:20px;">
    <form method="post" style="margin:0; display:flex; gap:15px; justify-content:center; align-items:center;">
        <!-- Botão para atualizar -->
        <button type="submit" class="btn" name="refresh">🔄 Atualizar</button>
        <!-- Link para a página de trade -->
        <a href="trade.php" class="btn">📈 Trade</a>
        <!-- Link para voltar ao dashboard -->
        <a href="dashboard.php" class="btn">⬅️ Voltar</a>
    </form>
</nav>

<h1>🪙 Mercado Público - MoedaMumu</h1>
<p>Jogador: <b><?=htmlspecialchars($username)?></b> | Saldo: <b><?=$moedas?></b> 💰</p>

<!-- Inventário -->
<h2>🎒 Meu Inventário</h2>
<table>
<tr><th>Item</th><th>Quantidade</th><th>Vender</th></tr>
<?php
if(count($carteira) == 0){
    echo "<tr><td colspan='3'>Inventário vazio</td></tr>";
} else {
    foreach($carteira as $id => $qtd){
        $nome = $itensNome[$id] ?? "Item #$id";
        echo "<tr>
                <td>$nome</td>
                <td>$qtd</td>
                <td>
                    <form method='post'>
                        <input type='hidden' name='item_id' value='$id'>
                        <input type='number' name='quantidade' min='1' max='$qtd' required placeholder='Qtd'>
                        <input type='number' step='0.01' name='preco' required placeholder='Preço'>
                        <button type='submit' name='vender'>Vender</button>
                    </form>
                </td>
              </tr>";
    }
}
?>
</table>

<!-- Mercado -->
<h2>🏦 Itens à Venda</h2>
<table>
<tr><th>Item</th><th>Quantidade</th><th>Preço</th><th>Vendedor</th><th>Ação</th></tr>
<?php
while($row = sqlsrv_fetch_array($stmtMercado, SQLSRV_FETCH_ASSOC)){
    echo "<tr>
            <td>{$row['ItemNome']}</td>
            <td>{$row['Quantidade']}</td>
            <td>{$row['PrecoMoedaMumu']}</td>
            <td>{$row['Vendedor']}</td>
            <td>
                <form method='post'>
                    <input type='hidden' name='mercado_id' value='{$row['MercadoID']}'>
                    <button type='submit' name='comprar'>Comprar</button>
                </form>
            </td>
          </tr>";
}
?>
</table>

<!-- Histórico -->
<h2>📜 Histórico de Transações</h2>
<table>
<tr><th>Tipo</th><th>Item</th><th>Qtd</th><th>Preço</th><th>Comprador</th><th>Vendedor</th><th>Data</th></tr>
<?php
while($row = sqlsrv_fetch_array($stmtHistorico, SQLSRV_FETCH_ASSOC)){
    $tipo = $row['Tipo'] == 'COMPRA' ? '🟢' : '🔴';
    echo "<tr>
            <td>$tipo {$row['Tipo']}</td>
            <td>{$row['ItemNome']}</td>
            <td>{$row['Quantidade']}</td>
            <td>{$row['PrecoMoedaMumu']}</td>
            <td>".($row['Comprador'] ?? '-')."</td>
            <td>".($row['Vendedor'] ?? '-')."</td>
            <td>{$row['DataTransacao']->format('d/m H:i')}</td>
          </tr>";
}
?>
</table>

</body>
</html>
