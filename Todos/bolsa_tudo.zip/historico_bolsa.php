<?php
if (!isset($conn)) { include "db.php"; }
if (!isset($_SESSION)) { session_start(); }

$playerID = $_SESSION['PlayerID'] ?? null;
if(!$playerID){ echo json_encode(['error'=>"⛔ Faça login"]); exit; }

$sql = "
SELECT TOP 50 ht.*, a.Nome AS NomeAtivo, a.PrecoAtual
FROM dbo.HistoricoTransacoes ht
JOIN dbo.Ativos a ON ht.ItemID = a.AtivoID
WHERE ht.CompradorID = ? OR ht.VendedorID = ?
ORDER BY ht.DataHora ASC
";
$params = [$playerID,$playerID];
$stmt = sqlsrv_query($conn,$sql,$params);

if(!$stmt){ echo json_encode(['error'=>"Erro no SQL: ".print_r(sqlsrv_errors(),true)]); exit; }

$historicoTabela = [];
$historicoGrafico = [];

while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)){
    $nomeAtivo = $row['NomeAtivo'];
    $datahora = $row['DataHora'] ? $row['DataHora']->format('Y-m-d H:i:s') : '';
    $tipo = $row['Tipo'];
    $qtd = $row['Quantidade'];
    $preco_unit = $row['PrecoUnit'];
    $total = $row['Total'];

    $historicoTabela[] = [
        'datahora'=>$datahora,
        'acao'=>$tipo,
        'item'=>$nomeAtivo,
        'qtd'=>$qtd,
        'preco_unit'=>number_format($preco_unit,2),
        'total'=>number_format($total,2)
    ];

    if(!isset($historicoGrafico[$nomeAtivo])) $historicoGrafico[$nomeAtivo]=[];
    $historicoGrafico[$nomeAtivo][]=['datahora'=>$datahora,'preco'=>$preco_unit,'acao'=>$tipo,'qtd'=>$qtd];
}

$historicoTabela = array_slice($historicoTabela,-10);

echo json_encode([
    'tabela'=>$historicoTabela,
    'grafico'=>$historicoGrafico
], JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
