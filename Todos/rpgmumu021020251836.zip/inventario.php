<?php
session_start();
include "db.php";
include "check_ban.php"; // protege a página


if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// Pega itens do inventário
$itens = [];
$stmt = sqlsrv_query($conn, "SELECT * FROM Items WHERE PlayerID=? ORDER BY Nome", [$playerID]);
if($stmt && sqlsrv_has_rows($stmt)){
    while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)){
        $itens[] = $row;
    }
}

// Pega saldo do jogador
$stmtP = sqlsrv_query($conn, "SELECT MoedaMumu FROM Players WHERE PlayerID=?", [$playerID]);
$player = sqlsrv_fetch_array($stmtP, SQLSRV_FETCH_ASSOC);
$moeda = $player['MoedaMumu'] ?? 0;

// Processa venda
if($_POST && isset($_POST['vender']) && isset($_POST['ItemID']) && isset($_POST['Quantidade'])){
    $itemID = (int)$_POST['ItemID'];
    $qtd = (int)$_POST['Quantidade'];

    // Pega item
    $stmtI = sqlsrv_query($conn, "SELECT * FROM Items WHERE ItemID=? AND PlayerID=?", [$itemID, $playerID]);
    $item = sqlsrv_fetch_array($stmtI, SQLSRV_FETCH_ASSOC);

    if($item && $qtd > 0 && $qtd <= $item['Quantidade']){
        // Preço base = quantidade * 10 (ou qualquer lógica)
        $preco = $qtd * 10;
        $moeda += $preco;

        // Atualiza saldo do jogador
        sqlsrv_query($conn, "UPDATE Players SET MoedaMumu=? WHERE PlayerID=?", [$moeda, $playerID]);

        // Diminui quantidade ou remove item
        if($item['Quantidade'] - $qtd <= 0){
            sqlsrv_query($conn, "DELETE FROM Items WHERE ItemID=?", [$itemID]);
        } else {
            sqlsrv_query($conn, "UPDATE Items SET Quantidade=Quantidade-? WHERE ItemID=?", [$qtd, $itemID]);
        }

        // Historico
        sqlsrv_query($conn, "INSERT INTO Historico (PlayerID, Acao, Item, Quantidade) VALUES (?,?,?,?)",
            [$playerID,'Venda',$item['Nome'],$qtd]);

        $mensagem = "✅ Você vendeu $qtd x {$item['Nome']} por $preco moedas!";
    } else {
        $mensagem = "❌ Quantidade inválida!";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Inventário / Mercado - RPG Mumu</title>
</head>
<body>
<h2>💰 Saldo: <?= $moeda ?> moedas</h2>
<p><?= $mensagem ?? "" ?></p>

<h3>📦 Inventário</h3>
<table border="1" cellpadding="5">
<tr><th>Nome</th><th>Quantidade</th><th>Ação</th></tr>
<?php foreach($itens as $i): ?>
<tr>
<td><?= htmlspecialchars($i['Nome']) ?></td>
<td><?= $i['Quantidade'] ?></td>
<td>
<form method="post">
<input type="hidden" name="ItemID" value="<?= $i['ItemID'] ?>">
<input type="number" name="Quantidade" value="1" min="1" max="<?= $i['Quantidade'] ?>" style="width:50px;">
<button type="submit" name="vender">Vender</button>
</form>
</td>
</tr>
<?php endforeach; ?>
</table>

<a href="dashboard.php">⬅️ Voltar</a>
</body>
</html>
