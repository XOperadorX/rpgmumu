<?php
session_start();
include "db.php";

if (!isset($_SESSION['PlayerID'])) {
    die("Acesso negado. Faça login.");
}
$playerID = $_SESSION['PlayerID'];
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>🩺 Saúde da Conta</title>
<style>
body { font-family: Arial, sans-serif; background:#f4f6f7; margin:0; padding:20px; }
.container { max-width:1200px; margin:auto; }
.top-bar { display:flex; flex-wrap:wrap; justify-content:space-between; margin-bottom:20px; gap:10px; }
.voltar-btn { display:inline-block; padding:10px 20px; background:#2c3e50; color:#fff; border-radius:8px; text-decoration:none; transition:0.3s; }
.voltar-btn:hover { background:#34495e; }

.jogador-info {
    background:#333; color:#ffcc00; padding:15px; border-radius:10px; margin-bottom:20px; text-align:center;
    box-sizing: border-box; width:100%; max-width:800px; margin-left:auto; margin-right:auto;
}
.jogador-info h1 { margin-top:0; font-size:1.8em; }

.progress-bar { width:100%; background:#e0e0e0; border-radius:12px; overflow:hidden; height:25px; margin-top:8px; }
.progress-fill { height:100%; width:0%; border-radius:12px; text-align:center; color:white; line-height:25px; font-weight:bold; transition: width 1s ease-in-out; }

.table-container { overflow-x:auto; }
table { width:100%; border-collapse:collapse; margin-top:15px; }
th, td { border:1px solid #ddd; padding:8px; text-align:center; }
th { background:#2c3e50; color:#fff; }
button.comprar { padding:5px 10px; background:#3498db; color:#fff; border:none; border-radius:4px; cursor:pointer; transition:0.3s; }
button.comprar:hover { background:#2980b9; }

@media(max-width:768px){ .jogador-info h1 { font-size:1.5em; } }
@media(max-width:480px){ .jogador-info h1 { font-size:1.2em; } }
</style>
</head>
<body>

<div class="container">
    <div class="top-bar">
        <a href="dashboard.php" class="voltar-btn">⬅ Voltar</a>
    </div>

    <div class="jogador-info">
        <h1>🩺 Saúde da Conta</h1>
        <p><strong>Usuário:</strong> <span id="username">Carregando...</span></p>
        <p><strong>Moedas Mumu:</strong> <span id="moeda">0</span></p>
        <p><strong>Saúde da Conta:</strong></p>
        <div class="progress-bar">
            <div id="barraSaude" class="progress-fill">0%</div>
        </div>
        <div style="margin-top:10px;">
            <button id="comprarPontos" class="comprar">💰 Comprar Pontos</button>
        </div>
    </div>

    <h2 class="subtitulo">🔑 Últimos Logins (até 10)</h2>
    <table>
        <tr><th>Data e Hora</th><th>IP</th></tr>
        <?php if (!empty($logins)): ?>
            <?php foreach ($logins as $l): ?>
            <tr>
                <td>
                    <?php
                        if (isset($l['LoginTime']) && $l['LoginTime'] instanceof DateTime) echo $l['LoginTime']->format('d/m/Y H:i');
                        elseif (!empty($l['LoginTime'])) echo htmlspecialchars(date('d/m/Y H:i', strtotime($l['LoginTime'])));
                        else echo '-';
                    ?>
                </td>
                <td><?= htmlspecialchars($l['LoginIP']) ?></td>
            </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="2">Nenhum login encontrado.</td></tr>
        <?php endif; ?>
    </table>
    </div>
</div>

<script>
// Atualiza todas as informações via AJAX
function atualizarSaude() {
    fetch('saude_status.php')
    .then(res => res.json())
    .then(data => {
        if(data.error) return;

        // Atualiza usuário e moedas
        document.getElementById('username').textContent = data.username;
        document.getElementById('moeda').textContent = data.moeda;

        // Atualiza barra de saúde
        let barra = document.getElementById('barraSaude');
        barra.style.width = data.health+'%';
        barra.textContent = data.health+'%';
        barra.style.background = data.health>=70 ? '#2ecc71' : (data.health>=40 ? '#f1c40f' : '#e74c3c');

        // Atualiza últimos logins
        let tbody = document.getElementById('loginsBody');
        tbody.innerHTML = '';
        if(data.logins.length>0){
            data.logins.forEach(l=>{
                let tr = document.createElement('tr');
                tr.innerHTML = `<td>${l.LoginTime}</td><td>${l.LoginIP}</td>`;
                tbody.appendChild(tr);
            });
        } else {
            tbody.innerHTML = '<tr><td colspan="2">Nenhum login encontrado.</td></tr>';
        }
    })
    .catch(err => console.error(err));
}

// Atualiza a cada 5 segundos
atualizarSaude();
setInterval(atualizarSaude, 5000);

// Compra de pontos
document.getElementById('comprarPontos').addEventListener('click', ()=>{
    fetch('saude_comprar.php', {method:'POST'})
    .then(res=>res.json())
    .then(data=>{
        alert(data.msg);
        atualizarSaude();
    })
    .catch(err=>console.error(err));
});
</script>

</body>
</html>
