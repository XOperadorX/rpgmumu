<?php
session_start();
include "db.php";
include "check_ban.php"; // protege a página

header('Content-Type: application/json');

if(!isset($_SESSION['PlayerID'])){
    echo json_encode([]);
    exit;
}

$playerID = $_SESSION['PlayerID'];
$sql = "
SELECT TOP 1000 CharID, Name, Level, Exp, HP, MaxHP, Mana, MaxMana
FROM Characters WHERE PlayerID=?";

$stmt = sqlsrv_query($conn,$sql,[$playerID]);
$chars=[];

while($row=sqlsrv_fetch_array($stmt,SQLSRV_FETCH_ASSOC)){
    $chars[]=[
        'CharID'=>$row['CharID'],
        'Name'=>$row['Name'],
        'Level'=>$row['Level'],
        'Exp'=>$row['Exp'],
        'HP'=>$row['HP'],
        'MaxHP'=>$row['MaxHP'],
        'Mana'=>$row['Mana'],
        'MaxMana'=>$row['MaxMana']
    ];
}

echo json_encode($chars);
