<?php
session_start();
include "db.php";
include "check_ban.php"; // protege a página


if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// Ativos do mercado
$ativos = [
    ['Nome'=>'Ouro','Preco'=>50],
    ['Nome'=>'Prata','Preco'=>30],
    ['Nome'=>'Bronze','Preco'=>10],
    ['Nome'=>'Cristal','Preco'=>100],
    ['Nome'=>'Esmeralda','Preco'=>150],
];

// Pega saldo
$stmtP = sqlsrv_query($conn, "SELECT MoedaMumu FROM Players WHERE PlayerID=?", [$playerID]);
$moeda = 0;
if($stmtP !== false){
    $player = sqlsrv_fetch_array($stmtP, SQLSRV_FETCH_ASSOC);
    if($player){
        $moeda = $player['MoedaMumu'] ?? 0;
    }
}

// Inventário para vender loot
$itens = [];
$stmtI = sqlsrv_query($conn, "SELECT * FROM Items WHERE PlayerID=?", [$playerID]);
if($stmtI !== false){
    while($row = sqlsrv_fetch_array($stmtI, SQLSRV_FETCH_ASSOC)){
        $itens[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Mercado RPG Mumu</title>
</head>
<body>

<style>
body {
    background-color: black;
    color: white;
    font-family: 'Roboto', sans-serif;
    margin: 0;
    padding: 20px;
}
h1, h2, h3 {
    text-align: center;
    color: #ffd700;
}
.moedas {
    font-size: 1.2em;
    color: #ff9900;
    font-weight: bold;
    text-align: center;
}
table {
    width: 80%;
    margin: 20px auto;
    border-collapse: collapse;
    background: #1a1a1a;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 0 10px rgba(255,255,255,0.2);
}
th, td {
    padding: 12px;
    text-align: center;
    border-bottom: 1px solid #333;
}
th {
    background: #333;
    color: #ffd700;
}
tr:hover {
    background: rgba(255,255,255,0.05);
}
button {
    padding: 6px 12px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    color: white;
    background: #333;
    transition: 0.3s;
}
button:hover {
    background: #555;
}
a {
    display: block;
    text-align: center;
    margin-top: 20px;
    text-decoration: none;
    color: #00bfff;
    font-weight: bold;
}
a:hover {
    text-decoration: underline;
}

nav {
    position: fixed;          /* fixa no topo */
    top: 20px;                /* distância do topo */
    left: 20px;               /* distância da esquerda */
    z-index: 1000;            /* acima de outros elementos */
}

nav a {
    display: inline-block;
    padding: 0.5em 1em;
    background: rgba(0, 191, 255, 0.15);
    border-radius: 0.5em;
    color: #00bfff;
    text-decoration: none;
    font-weight: bold;
    font-size: 1.1em;
    box-shadow: 0 0 10px rgba(0,191,255,0.3);
    transition: 0.3s;
}

nav a:hover {
    color: #1ec8ff;
    background: rgba(0, 191, 255, 0.25);
    box-shadow: 0 0 15px rgba(0,191,255,0.5);
}

/* Ajustes para telas pequenas (mobile) */
@media (max-width: 480px) {
    nav {
        top: 10px;
        left: 10px;
    }

    nav a {
        padding: 0.4em 0.8em;
        font-size: 1em;
    }
}




</style>

<nav>
    <a href="dashboard.php">⬅️ Voltar</a>
</nav>


<h2>💰 Saldo: <?= $moeda ?> moedas</h2>

<h3>📈 Mercado de Ativos</h3>
<table border="1" cellpadding="5">
<tr><th>Ativo</th><th>Preço</th><th>Ação</th></tr>
<?php foreach($ativos as $a): ?>
<tr>
<td><?= $a['Nome'] ?></td>
<td><?= $a['Preco'] ?> moedas</td>
<td>
<form method="post" action="comprar_ativo.php" style="display:inline-block;">
    <input type="hidden" name="AtivoID" value="<?= $a['Nome'] ?>">
    <input type="number" name="Quantidade" value="1" min="1" style="width:50px;">
    <button type="submit">Comprar</button>
</form>

<form method="post" action="vender_ativo.php" style="display:inline-block; margin-left:5px;">
    <input type="hidden" name="AtivoID" value="<?= $a['Nome'] ?>">
    <input type="number" name="Quantidade" value="1" min="1" style="width:50px;">
    <button type="submit">Vender</button>
</form>
</td>
</tr>
<?php endforeach; ?>
</table>

<h3>📦 Vender Itens do Inventário</h3>
<table border="1" cellpadding="5">
<tr><th>Nome</th><th>Quantidade</th><th>Ação</th></tr>
<?php foreach($itens as $i): ?>
<tr>
<td><?= htmlspecialchars($i['Nome']) ?></td>
<td><?= $i['Quantidade'] ?></td>
<td>
<form method="post" action="inventario.php">
    <input type="hidden" name="ItemID" value="<?= $i['ItemID'] ?>">
    <input type="number" name="Quantidade" value="1" min="1" max="<?= $i['Quantidade'] ?>" style="width:50px;">
    <button type="submit" name="vender">Vender</button>
</form>
</td>
</tr>
<?php endforeach; ?>
</table>

</body>
</html>
