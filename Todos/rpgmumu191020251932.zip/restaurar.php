<?php
if (!isset($conn)) {
    include "db.php"; // Garante que a conexão está disponível
}

if (!isset($_SESSION)) {
    session_start();
}

$playerID = $_SESSION['PlayerID'] ?? null;

if ($playerID) {
    $stmt = sqlsrv_query($conn, "SELECT Banido FROM Players WHERE PlayerID = ?", [$playerID]);
    if ($stmt && $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        if (!empty($row['Banido']) && $row['Banido'] == 1) {
            die("⛔ Você está banido e não pode acessar o jogo.");
        }
    }
}

$valorRestaurar = 500; // custo para restaurar

// Pega o saldo do jogador
$sql = "SELECT MoedaMumu FROM Players WHERE PlayerID = ?";
$stmt = sqlsrv_query($conn, $sql, [$playerID]);
if($stmt === false){
    die("Erro ao consultar saldo.");
}
$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
$saldo = $row['MoedaMumu'] ?? 0;

// Verifica se o jogador tem saldo suficiente
if($saldo < $valorRestaurar){
    // Mostra a mensagem e interrompe qualquer operação
    $mensagem = "⛔ Saldo insuficiente. Você precisa de $valorRestaurar MoedaMumu para restaurar.";
} else {
    // Deduz o valor
    $sql = "UPDATE Players SET MoedaMumu = MoedaMumu - ? WHERE PlayerID = ?";
    $stmt = sqlsrv_query($conn, $sql, [$valorRestaurar, $playerID]);
    if($stmt === false){
        die("Erro ao deduzir MoedaMumu.");
    }

    // Atualiza HP, Mana e Power do personagem
    $sql = "UPDATE Characters 
            SET HP = MaxHP, 
                Mana = MaxMana,
                Power = MaxPower
            WHERE PlayerID = ?";
    $stmt = sqlsrv_query($conn, $sql, [$playerID]);
    if($stmt === false){
        die("Erro ao restaurar atributos.");
    }

    // Atualiza também na sessão
    if(isset($_SESSION['char'])){
        $_SESSION['char']['HP'] = $_SESSION['char']['MaxHP'];
        $_SESSION['char']['Mana'] = $_SESSION['char']['MaxMana'];
        $_SESSION['char']['Power'] = $_SESSION['char']['MaxPower'];
    }

    // Redireciona de volta para o dashboard
    header("Location: dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <style>
        #mensagem {
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            padding: 15px;
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            border-radius: 5px;
            z-index: 9999;
        }
    </style>
    <script>
        // Faz a mensagem desaparecer após 3 segundos
        window.onload = function() {
            const msg = document.getElementById('mensagem');
            if(msg){
                setTimeout(() => msg.style.display = 'none', 3000);
            }
        };
    </script>
</head>
<body>

<?php if(isset($mensagem)): ?>
    <div id="mensagem"><?= $mensagem ?></div>
<?php endif; ?>

<!-- O resto da sua página aqui -->

</body>
</html>
<?php 
    // Redireciona de volta para o dashboard
    header("Location: dashboard.php");
    exit;
?>
	