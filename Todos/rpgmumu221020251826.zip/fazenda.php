<?php
session_start();
include "db.php";

if (!isset($_SESSION['PlayerID'])) {
    die("⛔ Faça login primeiro.");
}

$playerID = $_SESSION['PlayerID'];

// ===== Funções auxiliares =====
function safeQuery($conn, $sql, $params = []) {
    $stmt = sqlsrv_query($conn, $sql, $params);
    if ($stmt === false) {
        echo "<pre>❌ Erro na query:\n$sql\n";
        print_r(sqlsrv_errors());
        echo "</pre>";
        return [];
    }
    $result = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $result[] = $row;
    }
    return $result;
}

function registrarHistorico($conn, $playerID, $acao, $nomeFruta, $quantidade){
    $sql = "INSERT INTO dbo.HistoricoFazenda (PlayerID, Acao, NomeFruta, Quantidade, DataRegistro)
            VALUES (?, ?, ?, ?, GETDATE())";
    sqlsrv_query($conn, $sql, [$playerID, $acao, $nomeFruta, $quantidade]);
}

// ===== Dados principais =====
$slots = safeQuery($conn, "
    SELECT pf.SlotID, pf.FrutaID, pf.DataPlantio, f.Nome AS Fruta, f.TempoCrescimento
    FROM dbo.PlantacaoFazenda pf
    LEFT JOIN dbo.Frutas f ON pf.FrutaID = f.FrutaID
    WHERE pf.PlayerID = ?", [$playerID]);

$sementes = safeQuery($conn, "
    SELECT s.FrutaID, f.Nome, s.Quantidade
    FROM dbo.Sementes s
    JOIN dbo.Frutas f ON s.FrutaID = f.FrutaID
    WHERE s.PlayerID = ?", [$playerID]);

$frutas = safeQuery($conn, "
    SELECT i.FrutaID, f.Nome, i.Quantidade
    FROM dbo.InventarioFrutas i
    JOIN dbo.Frutas f ON i.FrutaID = f.FrutaID
    WHERE i.PlayerID = ?", [$playerID]);

$todasFrutas = safeQuery($conn, "SELECT FrutaID, Nome, PrecoSemente, PrecoVenda FROM dbo.Frutas");

$saldo = safeQuery($conn, "SELECT Poupanca FROM dbo.BankAccounts WHERE PlayerID = ?", [$playerID]);
$poupanca = isset($saldo[0]['Poupanca']) ? number_format($saldo[0]['Poupanca'], 2, ',', '.') : '0,00';

$historico = safeQuery($conn, "
    SELECT TOP 10 Acao, NomeFruta, Quantidade, DataRegistro
    FROM dbo.HistoricoFazenda
    WHERE PlayerID = ?
    ORDER BY DataRegistro DESC", [$playerID]);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>🌾 Fazenda - RPG</title>
<style>
/* ======== Estilo Futurista ======== */
body {
    font-family: 'Orbitron', sans-serif;
    background: linear-gradient(120deg, #0b0b0b, #0d0d1a);
    color: #00ffcc;
    text-align: center;
    padding: 20px;
}
.top-bar {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 12px;
    background: linear-gradient(90deg, #0b0b0b, #111111);
    padding: 12px 0;
    border-bottom: 3px solid #00ffcc;
    box-shadow: 0 0 15px #00ffcc inset, 0 0 20px #00ffcc;
    border-radius: 0 0 20px 20px;
}
.top-bar a {
    color: #00ffcc;
    text-decoration: none;
    padding: 8px 16px;
    border: 2px solid #00ffcc;
    border-radius: 12px;
    font-weight: bold;
    font-size: 14px;
    transition: 0.3s;
    position: relative;
}
.top-bar a:hover {
    color: #fff;
    background: linear-gradient(45deg, #00ffcc, #00d4a0);
    box-shadow: 0 0 10px #00ffcc, 0 0 20px #00d4a0 inset;
    border-color: #00d4a0;
}
@media (max-width: 800px) {
    .top-bar { flex-direction: column; gap: 8px; }
    .top-bar a { width: 80%; text-align: center; }
}
h1, h2 { margin: 10px 0; }
.container { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-top: 20px; }
.slot {
    background: #111;
    border: 3px double #00ffcc;
    border-radius: 20px;
    padding: 15px;
    height: 160px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    box-shadow: 0 0 15px rgba(0, 255, 204, 0.6);
    transition: transform 0.3s, box-shadow 0.3s, border-color 0.3s;
}
.slot:hover { transform: translateY(-5px) scale(1.02); box-shadow: 0 0 25px #00ffd0, 0 0 40px #00ffcc inset; border-color: #00d4a0; }
.btn, .btn-historico {
    background: linear-gradient(45deg, #00ffcc, #00d4a0);
    border: 2px solid #00ffcc;
    padding: 8px 16px;
    border-radius: 12px;
    cursor: pointer;
    font-weight: bold;
    transition: 0.3s;
}
table { 
    width: 80%; margin: 10px auto; border-collapse: collapse; border: 3px double #00ffcc;
    border-radius: 12px; overflow: hidden; box-shadow: 0 0 15px #00ffcc inset;
}
th, td { border: 1px solid #00ffcc; padding: 10px; text-align: center; }
th { background: linear-gradient(90deg, #0b0b0b, #111111); }
.log { background: #111; border: 3px double #00ffcc; border-radius: 12px; padding: 15px; margin: 10px auto; width: 80%; height: 100px; overflow-y: auto; box-shadow: 0 0 15px #00ffcc inset; }
</style>
</head>
<body>

<nav class="top-bar">
    <a href="logout.php">🚪 Sair</a>
    <a href="personagens.php">👤 Personagens</a>
    <a href="bank.php">🏦 Banco 💰</a>
    <a href="start_dungeon.php">🗡️ Masmorra</a>
    <a href="inventario.php">🎒 Inventário</a>
    <a href="saude.php">🩺 Saúde</a>
    <a href="mercado.php">🛒 Mercado</a>
    <a href="bolsa.php">📈 Bolsa</a>
    <a href="fazenda.php">🌱 Fazenda</a>
</nav>

<h1>🏡 Fazenda RPG - MoedaMumu</h1>
<a href="historico_fazenda.php" class="btn-historico">📜 Histórico Completo</a>

<h2>💰 Saldo da Poupança: 💎 <?= $poupanca ?> </h2>

<!-- ==================== COMPRA DE SEMENTES ==================== -->
<h2>🛒 Comprar Semente 🌱</h2>
<select id="compraSemente">
    <option value="">-- Escolha --</option>
    <?php foreach($todasFrutas as $f): ?>
        <option value="<?= $f['FrutaID'] ?>"><?= htmlspecialchars($f['Nome']) ?> (💰 <?= $f['PrecoSemente'] ?>)</option>
    <?php endforeach; ?>
</select>
<button class="btn" onclick="comprarSemente()">Comprar</button>

<!-- ==================== INVENTÁRIO DE SEMENTES ==================== -->
<h2>🌱 Inventário de Sementes</h2>
<table>
<tr><th>Nome</th><th>Quantidade</th><th>Qtd Venda</th><th>Preço Total</th><th>Ação</th></tr>
<?php foreach($sementes as $s): ?>
<tr>
    <td><?= htmlspecialchars($s['Nome']) ?></td>
    <td><?= $s['Quantidade'] ?></td>
    <td><input type="number" min="1" max="<?= $s['Quantidade'] ?>" value="1" id="qtdSemente<?= $s['FrutaID'] ?>" style="width:60px"></td>
    <td id="precoSemente<?= $s['FrutaID'] ?>">0</td>
    <td><button class="btn" onclick="venderItem('semente', <?= $s['FrutaID'] ?>)">💰 Vender</button></td>
</tr>
<?php endforeach; ?>
</table>

<!-- ==================== INVENTÁRIO DE FRUTAS ==================== -->
<h2>🍎 Inventário de Frutas</h2>
<table>
<tr><th>Nome</th><th>Quantidade</th><th>Qtd Venda</th><th>Preço Total</th><th>Ação</th></tr>
<?php foreach($frutas as $f): ?>
<tr>
    <td><?= htmlspecialchars($f['Nome']) ?></td>
    <td><?= $f['Quantidade'] ?></td>
    <td><input type="number" min="1" max="<?= $f['Quantidade'] ?>" value="1" id="qtdFruta<?= $f['FrutaID'] ?>" style="width:60px"></td>
    <td id="precoFruta<?= $f['FrutaID'] ?>">0</td>
    <td><button class="btn" onclick="venderItem('fruta', <?= $f['FrutaID'] ?>)">💰 Vender</button></td>
</tr>
<?php endforeach; ?>
</table>

<!-- ==================== HISTÓRICO ==================== -->
<h2>📜 Últimas Ações na Fazenda</h2>
<table>
<tr><th>Ação</th><th>Fruta</th><th>Quantidade</th><th>Data</th></tr>
<?php foreach($historico as $h): ?>
<tr>
    <td><?= htmlspecialchars($h['Acao']) ?></td>
    <td><?= htmlspecialchars($h['NomeFruta']) ?></td>
    <td><?= $h['Quantidade'] ?></td>
    <td><?= $h['DataRegistro']->format('d/m/Y H:i') ?></td>
</tr>
<?php endforeach; ?>
</table>

<!-- ==================== FAZENDA / SLOTS ==================== -->
<h1>🌱 Sua Fazenda</h1>
<div class="container">
<?php for($i=1;$i<=6;$i++):
    $slot = array_filter($slots, fn($s) => $s['SlotID'] == $i);
    $slot = reset($slot);
?>
<div class="slot" id="slot<?= $i ?>">
<?php if(!$slot || !$slot['FrutaID']): ?>
    <p>Vazio 🌿</p>
    <select id="sem<?= $i ?>">
        <option value="">-- Escolha --</option>
        <?php foreach($sementes as $s): ?>
            <option value="<?= $s['FrutaID'] ?>"><?= htmlspecialchars($s['Nome']) ?> (x<?= $s['Quantidade'] ?>)</option>
        <?php endforeach; ?>
    </select><br>
    <button class="btn" onclick="plantar(<?= $i ?>)">Plantar</button>
<?php else:
    $plantio = $slot['DataPlantio'] instanceof DateTime ? $slot['DataPlantio'] : new DateTime($slot['DataPlantio']);
    $colheita = (clone $plantio)->modify("+{$slot['TempoCrescimento']} minutes");
?>
    <p>🌾 <?= htmlspecialchars($slot['Fruta']) ?></p>
    <p id="tempoRestante<?= $i ?>"></p>
    <button class="btn" id="btnColher<?= $i ?>" onclick="colher(<?= $i ?>)" style="display:none;">Colher</button>
    <script>window["colheita<?= $i ?>"] = <?= $colheita->getTimestamp() ?>;</script>
<?php endif; ?>
</div>
<?php endfor; ?>
</div>

<button class="btn" onclick="colherFrutas()">🌾 Colher Todas as Frutas Maduras</button>

<script>
// ====== Preços de Venda ======
const precos = {};
<?php foreach($todasFrutas as $f){ echo "precos[{$f['FrutaID']}] = {$f['PrecoVenda']};\n"; } ?>

// ====== Atualização de preço ======
function atualizarPreco(tipo, frutaID){
    const input = document.getElementById(`${tipo=='semente'?'qtdSemente':'qtdFruta'}${frutaID}`);
    const totalElem = document.getElementById(`${tipo=='semente'?'precoSemente':'precoFruta'}${frutaID}`);
    let qtd = parseInt(input.value) || 1;
    totalElem.textContent = "💎 " + (qtd * precos[frutaID]);
}

<?php foreach($sementes as $s): ?>
document.getElementById('qtdSemente<?= $s['FrutaID'] ?>').addEventListener('input', ()=>atualizarPreco('semente', <?= $s['FrutaID'] ?>));
atualizarPreco('semente', <?= $s['FrutaID'] ?>);
<?php endforeach; ?>
<?php foreach($frutas as $f): ?>
document.getElementById('qtdFruta<?= $f['FrutaID'] ?>').addEventListener('input', ()=>atualizarPreco('fruta', <?= $f['FrutaID'] ?>));
atualizarPreco('fruta', <?= $f['FrutaID'] ?>);
<?php endforeach; ?>

// ====== Funções principais ======
function venderItem(tipo, frutaID){
    const input = document.getElementById(`${tipo=='semente'?'qtdSemente':'qtdFruta'}${frutaID}`);
    const quantidade = parseInt(input.value);
    if(!quantidade || quantidade <= 0){ alert("Quantidade inválida!"); return; }
    fetch('vender.php',{method:'POST',body:new URLSearchParams({tipo,frutaID,quantidade})})
    .then(r=>r.json()).then(d=>{alert(d.message);if(d.success)location.reload();});
}
function comprarSemente(){
    const frutaID=document.getElementById('compraSemente').value;
    if(!frutaID){alert("Escolha uma semente!");return;}
    fetch('comprar_semente.php',{method:'POST',body:new URLSearchParams({frutaID})})
    .then(r=>r.json()).then(d=>{alert(d.message);if(d.success)location.reload();});
}
function plantar(id){
    const frutaID=document.getElementById('sem'+id).value;
    if(!frutaID){alert("Escolha uma semente!");return;}
    fetch('plantar.php',{method:'POST',body:new URLSearchParams({slotID:id,frutaID})})
    .then(r=>r.json()).then(d=>{alert(d.message);if(d.success)location.reload();});
}
function colher(id){
    fetch('colher.php',{method:'POST',body:new URLSearchParams({slotID:id})})
    .then(r=>r.json()).then(d=>{alert(d.message);if(d.success)location.reload();});
}
function colherFrutas(){
    fetch('colherFrutas.php',{method:'POST'}).then(r=>r.json())
    .then(d=>{alert(d.message);if(d.success)location.reload();});
}
function atualizarTempo(){
    for(let i=1;i<=6;i++){
        const elem=document.getElementById("tempoRestante"+i);
        const btn=document.getElementById("btnColher"+i);
        if(!elem||!window["colheita"+i])continue;
        let restante=window["colheita"+i]-Math.floor(Date.now()/1000);
        if(restante<=0){elem.textContent="🌾 Pronto para colher!";btn.style.display="inline-block";}
        else{
            let h=Math.floor(restante/3600),m=Math.floor((restante%3600)/60),s=restante%60;
            elem.textContent=`⏳ ${h}h ${m}m ${s}s`;btn.style.display="none";
        }
    }
}
setInterval(atualizarTempo,1000);
window.onload=atualizarTempo;
</script>
</body>
</html>
