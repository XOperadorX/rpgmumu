<?php
if (!isset($conn)) {
    include "db.php"; // Garante que a conexão está disponível
}

if (!isset($_SESSION)) {
    session_start();
}

$playerID = $_SESSION['PlayerID'] ?? null;

if ($playerID) {
    $stmt = sqlsrv_query($conn, "SELECT Banido FROM Players WHERE PlayerID = ?", [$playerID]);
    if ($stmt && $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        if (!empty($row['Banido']) && $row['Banido'] == 1) {
            die("⛔ Você está banido e não pode acessar o jogo.");
        }
    }
}


// Puxa personagem
$stmtChar = sqlsrv_query($conn, "SELECT TOP 1 CharID, Name FROM dbo.Characters WHERE PlayerID=?", [$playerID]);
$char = sqlsrv_fetch_array($stmtChar, SQLSRV_FETCH_ASSOC);
$charID = $char['CharID'];

// Puxa equipamentos
$stmtEq = sqlsrv_query($conn, "SELECT * FROM dbo.Equipamento WHERE CharID=?", [$charID]);
$eq = sqlsrv_fetch_array($stmtEq, SQLSRV_FETCH_ASSOC);

// Cores por raridade (você pode armazenar raridade de cada slot na tabela Equipamento)
$cores = [
    'comum' => 'gray',
    'incomum' => 'green',
    'raro' => 'blue',
    'epico' => 'purple',
    'lendario' => 'orange'
];

$slots = ['Arma','Escudo','Capacete','Armadura','Luva','Calca'];
?>

<h3>Personagem: <?=htmlspecialchars($char['Name'])?></h3>
<div style="display:flex; flex-wrap: wrap; width:600px;">
<?php foreach($slots as $slot):
    $nome = $eq[$slot] ?? '-';
    // Se não tiver raridade na tabela, usamos 'comum' por padrão
    $cor = 'gray';
?>
    <div style="border:3px solid <?=$cor?>; width:100px; height:100px; margin:5px; text-align:center; line-height:100px;" title="<?=$slot?>: <?=$nome?>">
        <?=$nome?>
    </div>
<?php endforeach; ?>
</div>
