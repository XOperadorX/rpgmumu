
<?php
session_start();
//include "check_ban.php"; // protege a página

if (!isset($_SESSION['PlayerID'])) {
    die("Acesso negado. Faça login.");
}

// Saldo do jogador (exemplo)
$moeda = $_SESSION['MoedaMumu'] ?? 500;

// Carteira do jogador (quantidade de cada ativo)
$carteira = $_SESSION['carteira'] ?? [
    'Ouro'=>0,
    'Prata'=>0,
    'Bronze'=>0,
    'Cristal'=>0,
    'Esmeralda'=>0
];

// Ativos disponíveis
$ativos = [
    ['Nome'=>'Ouro','Preco'=>50],
    ['Nome'=>'Prata','Preco'=>30],
    ['Nome'=>'Bronze','Preco'=>10],
    ['Nome'=>'Cristal','Preco'=>100],
    ['Nome'=>'Esmeralda','Preco'=>150],
];

// Processa compra/venda
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['ativo'] ?? '';
    $qtd = intval($_POST['quantidade'] ?? 1);
    foreach($ativos as $a) {
        if($a['Nome'] === $nome){
            $preco = $a['Preco'];
            if(isset($_POST['comprar'])){
                $custo = $preco * $qtd;
                if($moeda >= $custo){
                    $moeda -= $custo;
                    $carteira[$nome] += $qtd;
                    $msg = "✅ Comprou $qtd x $nome por $custo moedas!";
                } else {
                    $msg = "❌ Saldo insuficiente!";
                }
            }
            if(isset($_POST['vender'])){
                if($carteira[$nome] >= $qtd){
                    $moeda += $preco * $qtd;
                    $carteira[$nome] -= $qtd;
                    $msg = "🔹 Vendeu $qtd x $nome por ".($preco*$qtd)." moedas!";
                } else {
                    $msg = "❌ Você não possui essa quantidade!";
                }
            }
        }
    }
    $_SESSION['MoedaMumu'] = $moeda;
    $_SESSION['carteira'] = $carteira;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Bolsa de Valores - RPG Mumu</title>
<style>
body {
    background: radial-gradient(circle at top, #111 0%, #000 100%);
    color: white;
    font-family: 'Roboto', sans-serif;
    margin: 0;
    padding: 2em; /* padding relativo à tela */
    box-sizing: border-box;
}

h1 {
    text-align: center;
    color: #ffd700;
    text-shadow: 0 0 8px rgba(255,215,0,0.8);
    margin-bottom: 0.5em;
    font-size: 2.5em; /* tamanho responsivo */
}

.moedas {
    text-align: center;
    font-size: 1.5em;
    color: #ff9900;
    font-weight: bold;
}

.top-bar {
    display: flex;
    flex-wrap: wrap; /* ajusta se a tela for pequena */
    justify-content: space-between;
    background: #1a1a1a;
    padding: 1em 2em;
    border-radius: 1em;
    box-shadow: 0 0 1em rgba(255,255,255,0.1);
}

.top-bar a {
    color: #00bfff;
    text-decoration: none;
    font-weight: bold;
    transition: 0.3s;
}

.top-bar a:hover {
    color: #1ec8ff;
    text-decoration: underline;
}

.container {
    max-width: 1100px;
    margin: 2em auto;
    padding: 0 1em;
}

.ativos {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(min(220px, 80%), 1fr));
    gap: 1.5em;
    margin-top: 2em;
}

.ativo {
    background: #111;
    border: 2px solid rgba(255,215,0,0.3);
    border-radius: 1em; /* curva proporcional ao conteúdo */
    box-shadow: 0 0 0.75em rgba(255,215,0,0.15);
    padding: 1.5em;
    text-align: center;
    transition: transform 0.2s, box-shadow 0.3s;
    word-wrap: break-word; /* evita overflow de texto */
}

.ativo:hover {
    transform: translateY(-0.3em);
    box-shadow: 0 0 1.25em rgba(255,215,0,0.4);
}

.ativo h3 {
    margin: 0.5em 0;
    font-size: 1.5em;
    color: #ffd700;
}

.ativo p {
    margin: 0.5em 0;
    font-size: 1em;
}

input[type=number] {
    width: 4em; /* largura proporcional */
    text-align: center;
    padding: 0.4em;
    border-radius: 0.5em;
    border: 1px solid #555;
    margin: 0.5em 0;
}

button {
    padding: 0.6em 1em;
    margin: 0.25em;
    border: none;
    border-radius: 0.5em;
    cursor: pointer;
    font-weight: bold;
    transition: 0.3s;
}

.buy {
    background: linear-gradient(45deg, #28a745, #34d058);
    color: white;
    box-shadow: 0 0 0.5em rgba(40,167,69,0.6);
}

.buy:hover {
    background: linear-gradient(45deg, #218838, #28a745);
    box-shadow: 0 0 1em rgba(40,167,69,0.9);
}

.sell {
    background: linear-gradient(45deg, #dc3545, #ff4b5c);
    color: white;
    box-shadow: 0 0 0.5em rgba(220,53,69,0.6);
}

.sell:hover {
    background: linear-gradient(45deg, #b52a37, #dc3545);
    box-shadow: 0 0 1em rgba(220,53,69,0.9);
}

.msg {
    text-align: center;
    font-weight: bold;
    margin: 1.5em 0;
    font-size: 1.2em;
}

.msg .ok { color: #4caf50; }
.msg .erro { color: #ff4b5c; }

/* Tornar tudo responsivo em telas pequenas */
@media (max-width: 480px) {
    h1 { font-size: 2em; }
    .moedas { font-size: 1.2em; }
    .ativo { padding: 1em; }
    input[type=number] { width: 3em; }
}

</style>
</head>
<body>

<div class="container">
    <!-- Top bar -->
    <nav class="top-bar">
        <a href="dashboard.php">🏠 Dashboard</a>
        <a href="logout.php">🚪 Sair</a>
    </nav>


	
<div class="container">
<h1>📈 Bolsa de Valores - RPG Mumu</h1>
<p>💰 Saldo: <?= $moeda ?> moedas</p>

<?php if(isset($msg)) echo "<p>$msg</p>"; ?>

<?php foreach($ativos as $a): 
    $qtd = $carteira[$a['Nome']] ?? 0;
?>
<div class="ativo">
    <h3><?= $a['Nome'] ?></h3>
    <p>Preço: <?= $a['Preco'] ?> moedas</p>
    <p>Você possui: <?= $qtd ?></p>
    <form method="post">
        <input type="hidden" name="ativo" value="<?= $a['Nome'] ?>">
        <input type="number" name="quantidade" value="1" min="1" style="width:50px;">
        <br>
        <button type="submit" class="buy" name="comprar">Comprar</button>
        <button type="submit" class="sell" name="vender">Vender</button>
    </form>
</div>
<?php endforeach; ?>

</div>
</body>
</html>
