<?php
session_start();
include "db.php";
include "check_ban.php"; // protege a página


if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// Pega personagem
$stmt = sqlsrv_query($conn, "SELECT TOP 1 * FROM Characters WHERE PlayerID=?", [$playerID]);
$char = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
if(!$char){
    die("Você precisa ter pelo menos um personagem. <a href='dashboard.php'>⬅ Voltar</a>");
}

// Dungeon ativa?
if(!isset($_SESSION['dungeon']) || $_SESSION['dungeon']['playerID'] != $playerID){
    echo "<p>⚠️ A dungeon não está ativa. ⬅️ <a href='dashboard.php'>Voltar</a></p>";
    exit;
}

$dungeon = &$_SESSION['dungeon'];
$enemy = $dungeon['enemies'][$dungeon['current']] ?? null;
$fim = $dungeon['fim'] ?? false;
$hpZerado = $char['HP'] <= 0;

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Dungeon - RPGMumu</title>
<style>
body{background:#222;color:#fff;font-family:Arial,sans-serif;text-align:center;margin:0;padding:20px;}
.cards-container{display:flex;justify-content:center;gap:40px;flex-wrap:wrap;margin-top:40px;}
.card{background:#111;border:3px solid gold;border-radius:15px;width:260px;padding:10px;box-shadow:0 0 20px rgba(255,255,255,0.4);transition:transform 0.3s;}
.card:hover{transform:scale(1.05);}
.progress{width:100%;background:#555;border-radius:5px;margin:5px 0;}
.bar{height:18px;border-radius:5px;transition:width 0.5s;}
.player-bar{background:limegreen;}
.enemy-bar{background:red;}
.mana-bar{background:#3498db;}
.xp-bar{background:purple;}
.log{background:#333;padding:10px;margin:20px auto;width:540px;height:200px;overflow-y:auto;border-radius:5px;text-align:left;}
#voltar{display:none;position:fixed;top:15px;left:15px;padding:10px 20px;background:#444;color:#fff;text-decoration:none;border-radius:5px;font-weight:bold;box-shadow:0 0 6px rgba(0,0,0,0.5);transition:0.3s;z-index:1000;font-size:1.1em;}
#voltar:hover{background:#ffcc00;color:#000;transform:scale(1.05);}
.pulsar{animation:pulse 1s infinite;}
@keyframes pulse{0%{transform:scale(1);box-shadow:0 0 6px rgba(255,255,0,0.5);}50%{transform:scale(1.1);box-shadow:0 0 12px rgba(255,255,0,1);}100%{transform:scale(1);box-shadow:0 0 6px rgba(255,255,0,0.5);}}
</style>
</head>
<body>

<a id="voltar" href="dashboard.php">⬅️ Voltar</a>
<h1>🗡️ Masmorra - <?= htmlspecialchars($char['Name']) ?></h1>

<?php if($hpZerado): ?>
    <p style="color:red; font-size:1.3em;">💀 Você morreu! Dungeon encerrada.</p>
<?php elseif($fim): ?>
    <p style="color:yellow; font-size:1.3em;">🏁 Parabéns! Todos os inimigos foram derrotados!</p>
<?php endif; ?>

<div class="cards-container">
    <!-- Player -->
    <div class="card">
        <h3><?= htmlspecialchars($char['Name']) ?></h3>
        <p>Level: <?= $char['Level'] ?> | XP: <?= $char['Exp'] ?></p>
        <div class="progress"><div class="bar player-bar" style="width:<?= round($char['HP']/$char['MaxHP']*100) ?>%"></div></div>
        <p>HP: <?= $char['HP'] ?> / <?= $char['MaxHP'] ?></p>
        <div class="progress"><div class="bar mana-bar" style="width:<?= round($char['Mana']/$char['MaxMana']*100) ?>%"></div></div>
        <p>Mana: <?= $char['Mana'] ?> / <?= $char['MaxMana'] ?></p>
        <div class="progress"><div class="bar xp-bar" style="width:<?= round(($char['Exp']/($char['Level']*50))*100) ?>%"></div></div>
        <p>XP: <?= $char['Exp'] ?> / <?= $char['Level']*50 ?></p>
    </div>

    <!-- Enemy -->
    <?php if($enemy): ?>
    <div class="card">
        <h3><?= htmlspecialchars($enemy['Name']) ?></h3>
        <p>Level: <?= $enemy['Level'] ?> | XP: <?= $enemy['XP'] ?></p>
        <div class="progress"><div class="bar enemy-bar" style="width:<?= round($enemy['HP']/$enemy['MaxHP']*100) ?>%"></div></div>
        <p>HP: <?= $enemy['HP'] ?> / <?= $enemy['MaxHP'] ?></p>
        <div class="progress"><div class="bar mana-bar" style="width:<?= round($enemy['Mana']/$enemy['MaxMana']*100) ?>%"></div></div>
        <p>Mana: <?= $enemy['Mana'] ?> / <?= $enemy['MaxMana'] ?></p>
    </div>
    <?php endif; ?>
</div>

<h2>🎒 Loot / Inventário</h2>
<div class="log" id="log"></div>

<script>
<?php if(!$hpZerado && !$fim): ?>
function atualizarDungeon(){
    fetch("turno.php")
    .then(r=>r.json())
    .then(data=>{
        // Atualiza player
        document.querySelector(".player-bar").style.width = (data.char.HP/data.char.MaxHP*100)+"%";
        document.querySelector(".xp-bar").style.width = (data.char.Exp/(data.char.Level*50)*100)+"%";
        document.getElementById("log").innerHTML += data.log.map(l=>"<div>"+l+"</div>").join("");

        // Atualiza enemy se existir
        if(data.enemy){
            document.querySelector(".enemy-bar").style.width = (data.enemy.HP/data.enemy.MaxHP*100)+"%";
        }

        // Dungeon fim
        if(data.fim){
            let btn = document.getElementById("voltar");
            btn.style.display="inline-block";
            btn.classList.add('pulsar');
        } else {
            setTimeout(atualizarDungeon, 1200);
        }
    })
    .catch(err=>console.error(err));
}
atualizarDungeon();
<?php else: ?>
document.getElementById("voltar").style.display="inline-block";
<?php endif; ?>
</script>

</body>
</html>
