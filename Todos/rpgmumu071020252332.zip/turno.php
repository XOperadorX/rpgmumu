<?php
session_start();
include "db.php"; // conexão com o banco
include "check_ban.php"; // protege a página

header('Content-Type: application/json');

if(!isset($_SESSION['dungeon'])){
    echo json_encode(['fim'=>true, 'msg'=>'A dungeon não está ativa.']);
    exit;
}

// Referências da sessão
$dungeon = &$_SESSION['dungeon'];
$char = &$dungeon['char'];
$currentEnemy = &$dungeon['enemies'][$dungeon['current']] ?? null;
$log = [];
$hora = date('d/m/Y H:i:s'); // Data + hora

// 1️⃣ Checa se jogador morreu
if($char['HP'] <= 0){
    $log[] = "💀 [$hora] Você morreu! Dungeon encerrada.";
    $dungeon['fim'] = true;
    unset($_SESSION['dungeon']); // libera memória
    echo json_encode(['char'=>$char, 'enemy'=>$currentEnemy, 'log'=>$log, 'fim'=>true]);
    exit;
}

// 2️⃣ Checa se acabou a dungeon
if(!$currentEnemy){
    $log[] = "🏁 [$hora] Todos os inimigos foram derrotados!";
    $dungeon['fim'] = true;
    unset($_SESSION['dungeon']); // libera memória
    echo json_encode(['char'=>$char, 'enemy'=>null, 'log'=>$log, 'fim'=>true]);
    exit;
}

// 3️⃣ Ataque do jogador
$damage = rand(5,10) + $char['Level'];
$currentEnemy['HP'] -= $damage;
$currentEnemy['HP'] = max(0, $currentEnemy['HP']);
$log[] = "<span style='color:blue;'>⚔️ [$hora] {$char['Name']} atacou {$currentEnemy['Name']} causando $damage de dano. HP do inimigo: {$currentEnemy['HP']}/{$currentEnemy['MaxHP']}";

// 4️⃣ Ataque do inimigo se ainda vivo
if($currentEnemy['HP'] > 0){
    $damageEnemy = rand(3,8) + ($currentEnemy['Level'] ?? 1);
    $char['HP'] -= $damageEnemy;
    $char['HP'] = max(0, $char['HP']);
    $log[] = "<span style='color:red;'>👹 [$hora] {$currentEnemy['Name']} atacou {$char['Name']} causando $damageEnemy de dano. Seu HP: {$char['HP']}/{$char['MaxHP']}";
} 
// 5️⃣ Caso inimigo morra
else {
    $char['Exp'] += $currentEnemy['XP'] ?? 0;
    $log[] =  "<span style='color:green;'>✅ [$hora] Você derrotou {$currentEnemy['Name']}! Ganhou {$currentEnemy['XP']} XP. HP restante: {$char['HP']}/{$char['MaxHP']}";

    // Loot
    if(!empty($currentEnemy['Loot']) && is_array($currentEnemy['Loot'])){
        foreach($currentEnemy['Loot'] as $item){
            $dungeon['loot'][] = $item;

            // Insere no banco de forma segura
            $sqlItem = "INSERT INTO Items (PlayerID, CharID, Nome, Quantidade) VALUES (?,?,?,?)";
            $stmtItem = sqlsrv_prepare($conn, $sqlItem, [$dungeon['playerID'], $char['CharID'], $item, 1]);
            sqlsrv_execute($stmtItem);

            $sqlHist = "INSERT INTO Historico (PlayerID, CharID, Acao, Item) VALUES (?,?,?,?)";
            $stmtHist = sqlsrv_prepare($conn, $sqlHist, [$dungeon['playerID'], $char['CharID'], 'Loot', $item]);
            sqlsrv_execute($stmtHist);

            $log[] = "<span style='color:orange;'>🎁 [$hora] Você pegou: $item";
        }
    }

    // Próximo inimigo
    $dungeon['current']++;
    $enemiesLeft = count($dungeon['enemies']) - $dungeon['current'];
    if($enemiesLeft > 0){
        $log[] = "📌 [$hora] Próximo inimigo: {$dungeon['enemies'][$dungeon['current']]['Name']}. Inimigos restantes: $enemiesLeft";
    } else {
        $log[] = "🏁 [$hora] Todos os inimigos foram derrotados!";
        $dungeon['fim'] = true;
        unset($_SESSION['dungeon']); // libera memória
    }
}

// 6️⃣ Level-up automático
while($char['Exp'] >= $char['Level']*50){
    $char['Exp'] -= $char['Level']*50;
    $char['Level']++;
    $char['MaxHP'] += 10;
    $char['HP'] = $char['MaxHP'];
    $char['MaxMana'] += 5;
    $char['Mana'] = $char['MaxMana'];
    $log[] = "🎉 [$hora] Parabéns! Você subiu para o nível {$char['Level']}!";
}

// 7️⃣ Atualiza personagem no banco
$sqlChar = "UPDATE Characters SET HP=?, Mana=?, Exp=?, Level=?, MaxHP=?, MaxMana=? WHERE CharID=?";
$paramsChar = [$char['HP'], $char['Mana'], $char['Exp'], $char['Level'], $char['MaxHP'], $char['MaxMana'], $char['CharID']];
$stmtChar = sqlsrv_prepare($conn, $sqlChar, $paramsChar);
sqlsrv_execute($stmtChar);

// 8️⃣ Retorna JSON para front-end
echo json_encode([
    'char' => $char,
    'enemy' => $dungeon['enemies'][$dungeon['current']] ?? null,
    'log' => $log,
    'fim' => $dungeon['fim'] ?? false
]);
