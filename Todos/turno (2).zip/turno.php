<?php
// turno.php - Combate seguro com loot avançado
session_start();
include "db.php";
include "check_ban.php";

header('Content-Type: application/json; charset=utf-8');

if(!isset($_SESSION['PlayerID'])){
    echo json_encode(['status'=>'error','msg'=>'Não logado']);
    exit;
}

$playerID = $_SESSION['PlayerID'];

// ==========================
// Funções auxiliares
// ==========================
function carregarInventario($playerID){
    global $conn;
    $inventario = [];
    $stmt = sqlsrv_query($conn, "SELECT ItemID, Nome, Quantidade, Raridade, Valor FROM dbo.Items WHERE PlayerID = ?", [$playerID]);
    if($stmt){
        while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)){
            $inventario[$row['ItemID']] = [
                'nome' => $row['Nome'] ?? 'Item',
                'qtd' => intval($row['Quantidade'] ?? 0),
                'raridade' => $row['Raridade'] ?? 'comum',
                'valor' => intval($row['Valor'] ?? 0)
            ];
        }
    }
    return $inventario;
}

function carregarInimigos(){
    global $conn;
    $stmt = sqlsrv_query($conn, "SELECT EnemyID, Name, HP, MaxHP, XP, Mana, MaxMana, Level, Loot FROM dbo.Enemies");
    $enemies = [];
    if($stmt){
        while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)){
            $row['HP'] = intval($row['HP'] ?? 0);
            $row['MaxHP'] = intval($row['MaxHP'] ?? $row['HP']);
            $row['Mana'] = intval($row['Mana'] ?? 0);
            $row['MaxMana'] = intval($row['MaxMana'] ?? $row['Mana']);
            $row['XP'] = intval($row['XP'] ?? 0);

            if(!empty($row['Loot'])){
                $lootParsed = json_decode($row['Loot'], true);
                if(json_last_error() === JSON_ERROR_NONE && is_array($lootParsed)){
                    $row['Loot'] = $lootParsed;
                } else {
                    $row['Loot'] = array_map('trim', explode(',', $row['Loot']));
                }
            } else {
                $row['Loot'] = [];
            }

            $enemies[] = $row;
        }
    }
    return $enemies;
}

function adicionarItemInventario(&$inventario, $item){
    $id = $item['ItemID'] ?? uniqid();
    if(isset($inventario[$id])){
        $inventario[$id]['qtd'] += intval($item['Quantidade'] ?? 1);
    } else {
        $inventario[$id] = [
            'nome' => $item['Nome'] ?? 'Item Aleatório',
            'qtd' => intval($item['Quantidade'] ?? 1),
            'raridade' => $item['Raridade'] ?? 'comum',
            'valor' => intval($item['Valor'] ?? 10)
        ];
    }
}

function gerarLootAvancado($baseLoot, $quantidade = 1){
    $chanceRaridade = [
        'lendário' => 1,
        'épico'    => 9,
        'raro'     => 20,
        'comum'    => 70
    ];

    $itens = [];
    for($i=0; $i<$quantidade; $i++){
        $rand = rand(1,100);
        $acum = 0;
        $raridade = 'comum';
        foreach($chanceRaridade as $r => $p){
            $acum += $p;
            if($rand <= $acum){
                $raridade = $r;
                break;
            }
        }

        $multiplicador = ['comum'=>1,'raro'=>2,'épico'=>4,'lendário'=>8];

        $item = [
            'Nome' => $baseLoot['Nome'] ?? 'Item Aleatório',
            'Quantidade' => $baseLoot['Quantidade'] ?? 1,
            'Raridade' => $raridade,
            'Valor' => intval(($baseLoot['Valor'] ?? 10) * ($multiplicador[$raridade] ?? 1))
        ];

        $itens[] = $item;
    }
    return $itens;
}

// ==========================
// Carrega personagem
// ==========================
$stmtChar = sqlsrv_query($conn, "SELECT TOP 1 * FROM dbo.Characters WHERE PlayerID = ?", [$playerID]);
if(!$stmtChar){
    echo json_encode(['status'=>'error','msg'=>'Erro ao carregar personagem']);
    exit;
}
$char = sqlsrv_fetch_array($stmtChar, SQLSRV_FETCH_ASSOC);

// Normaliza colunas
$char['Exp'] = intval($char['Exp'] ?? $char['Experience'] ?? 0);
$char['HP'] = intval($char['HP'] ?? 100);
$char['MaxHP'] = intval($char['MaxHP'] ?? 100);
$char['Mana'] = intval($char['Mana'] ?? 50);
$char['MaxMana'] = intval($char['MaxMana'] ?? 50);
$char['Power'] = intval($char['Power'] ?? 0);
$char['MaxPower'] = intval($char['MaxPower'] ?? 100);
$char['Level'] = intval($char['Level'] ?? 1);
$char['NextLevelXP'] = $char['Level'] * 100;

// ==========================
// Inicializa dungeon
// ==========================
if(!isset($_SESSION['dungeon']) || ($_SESSION['dungeon']['playerID'] ?? 0) != $playerID){
    $_SESSION['dungeon'] = [
        'playerID' => $playerID,
        'current' => 0,
        'enemies' => carregarInimigos(),
        'fim' => false,
        'char' => $char
    ];
}

$dungeon = &$_SESSION['dungeon'];
$enemy = &$dungeon['enemies'][$dungeon['current']] ?? null;
$hpZerado = $char['HP'] <= 0;

// ==========================
// Carrega inventário
// ==========================
$inventarioDB = carregarInventario($playerID);
foreach($_SESSION['inventario'] ?? [] as $id => $item){
    if(isset($inventarioDB[$id])){
        $inventarioDB[$id]['qtd'] += intval($item['qtd'] ?? 0);
    } else {
        $inventarioDB[$id] = $item;
    }
}
$_SESSION['inventario'] = $inventarioDB;
$inventario = $inventarioDB;

// ==========================
// Combate
// ==========================
$log = $_SESSION['log'] ?? [];

if(!$hpZerado && !$dungeon['fim'] && $enemy){
    // Ataque jogador
    $playerDamage = rand(10,25);
    $enemy['HP'] -= $playerDamage;
    $log[] = "Você causou <b>{$playerDamage}</b> de dano em {$enemy['Name']}!";

    if($enemy['HP'] <= 0){
        $log[] = "{$enemy['Name']} foi derrotado!";
        $xpGanho = $enemy['XP'];
        $char['Exp'] += $xpGanho;
        $log[] = "Você ganhou <b>{$xpGanho}</b> de XP!";

        // Loot múltiplo
        foreach($enemy['Loot'] as $baseItem){
            $quantidadeDrops = rand(1,3);
            $itensDrop = gerarLootAvancado($baseItem, $quantidadeDrops);
            foreach($itensDrop as $itemDrop){
                adicionarItemInventario($inventario, $itemDrop);
                $log[] = "💎 Você encontrou <b>{$itemDrop['Nome']}</b> ({$itemDrop['Raridade']})!";
            }
        }

        // Próximo inimigo
        $dungeon['current']++;
        if($dungeon['current'] >= count($dungeon['enemies'])){
            $dungeon['fim'] = true;
            $log[] = "🏁 Todos os inimigos foram derrotados!";
        } else {
            $enemy = &$dungeon['enemies'][$dungeon['current']];
        }
    } else {
        // Ataque inimigo
        $enemyDamage = rand(5,15);
        $char['HP'] -= $enemyDamage;
        $log[] = "{$enemy['Name']} causou <b>{$enemyDamage}</b> de dano em você!";
        if($char['HP'] <= 0){
            $log[] = "💀 Você morreu!";
        }
    }
}

// ==========================
// Atualiza sessão
// ==========================
$_SESSION['log'] = $log;
$_SESSION['inventario'] = $inventario;
$_SESSION['dungeon']['char'] = $char;

// ==========================
// Retorna JSON
// ==========================
echo json_encode([
    'status' => 'ok',
    'char' => [
        'HP' => $char['HP'],
        'MaxHP' => $char['MaxHP'],
        'Mana' => $char['Mana'],
        'MaxMana' => $char['MaxMana'],
        'Power' => $char['Power'],
        'MaxPower' => $char['MaxPower'],
        'Exp' => $char['Exp'],
        'NextLevelXP' => $char['NextLevelXP'],
        'Level' => $char['Level']
    ],
    'enemy' => $enemy ? [
        'Name' => $enemy['Name'],
        'HP' => $enemy['HP'],
        'MaxHP' => $enemy['MaxHP'],
        'Mana' => $enemy['Mana'],
        'MaxMana' => $enemy['MaxMana'],
        'Level' => $enemy['Level'],
        'XP' => $enemy['XP']
    ] : null,
    'inventario' => $inventario,
    'log' => $log,
    'fim' => $dungeon['fim']
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

