<?php
session_start();
include "db.php";

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// Busca personagens + inventário
$sql = "SELECT c.[CharID],
               c.[PlayerID],
               c.[Name],
               c.[Class],
               c.[Level],
               c.[Exp],
               c.[HP],
               i.[Arma],
               i.[Escudo],
               i.[Capacete],
               i.[Armadura],
               i.[Luva],
               i.[Calca]  -- sem acento
        FROM [MumuDB].[dbo].[Characters] c
        LEFT JOIN [MumuDB].[dbo].[Inventario] i
            ON i.[CharID] = c.[CharID]
        WHERE c.[PlayerID] = ?";

$params = [$playerID];
$stmt = sqlsrv_query($conn, $sql, $params);
if ($stmt === false) {
    die(print_r(sqlsrv_errors(), true));
}

// Saldo de moedas
$moedaRow = sqlsrv_fetch_array(
    sqlsrv_query($conn, "SELECT [MoedaMumu] FROM [MumuDB].[dbo].[Players] WHERE [PlayerID] = ?", [$playerID]),
    SQLSRV_FETCH_ASSOC
);
$moedas = $moedaRow['MoedaMumu'] ?? 0;
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Personagens</title>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
<style>
body { font-family:'Roboto',sans-serif; background:#f0f2f5; margin:0; padding:20px; color:#333; }
h1,h2 { text-align:center; }
.moedas { font-size:1.2em; color:#ff9900; }
.cards { display:flex; flex-wrap:wrap; justify-content:center; gap:20px; margin-top:20px; }
.card { background:#fff; border-radius:12px; box-shadow:0 4px 12px rgba(0,0,0,0.1); padding:20px; width:280px; transition:transform 0.2s; }
.card:hover { transform:translateY(-5px); }
.card h3 { margin-top:0; text-align:center; }
.stats,.inventory { margin-top:10px; }
.stats div,.inventory div { margin:5px 0; }
.hp-bar-container { background:#ddd; border-radius:10px; overflow:hidden; height:20px; margin-top:5px; }
.hp-bar { height:100%; background:#4caf50; width:100%; transition:width 0.5s; }
.hp-bar.warn { background:#ff9800; }
.hp-bar.low { background:#f44336; }
.btn { display:inline-block; padding:10px 20px; margin:10px 5px; text-decoration:none; color:#fff; border-radius:8px; background:#333; transition:background 0.3s; }
.btn:hover { background:#555; }
.btn.delete { background:#e53935; }
</style>
</head>
<body>
<nav style="background:#2c3e50; padding:10px; text-align:left;">
    <a href="dashboard.php" style="
        color:#fff;
        text-decoration:none;
        font-weight:bold;
        padding:8px 15px;
        background:#3498db;
        border-radius:5px;
        transition:0.3s;
    " onmouseover="this.style.background='#2980b9';" onmouseout="this.style.background='#3498db';">
        ⬅ Voltar
    </a>
</nav>
<h1>👥 Seus Personagens</h1>
<h2>💰 Moedas Mumu: <span class="moedas"><?= $moedas ?></span></h2>

<div class="cards">
<?php
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    echo "<div class='card'>
            <h3>{$row['Name']} ({$row['Class']})</h3>
            <div class='stats'>
                <div>Level: {$row['Level']}</div>
                <div>XP: {$row['Exp']}</div>
                <div>HP:</div>
                <div class='hp-bar-container'>
                    <div class='hp-bar' id='hp-{$row['CharID']}'></div>
                </div>
            </div>
            <div class='inventory'>
                <h4>🎒 Inventário</h4>
                <div>Arma: " . ($row['Arma'] ?? '-') . "</div>
                <div>Escudo: " . ($row['Escudo'] ?? '-') . "</div>
                <div>Capacete: " . ($row['Capacete'] ?? '-') . "</div>
                <div>Armadura: " . ($row['Armadura'] ?? '-') . "</div>
                <div>Luva: " . ($row['Luva'] ?? '-') . "</div>
                <div>Calça: " . ($row['Calca'] ?? '-') . "</div>
            </div>
            <a href='del_personagem.php?CharID={$row['CharID']}' class='btn delete'>🗑️ Excluir</a>
          </div>";
}
?>
</div>

<div style="text-align:center;">
    <a href="dashboard.php" class="btn">⬅️ Voltar</a>
</div>

<script>
// Atualiza HP de todos os personagens
function atualizarStatus() {
    fetch('status_personagem.php')
    .then(res => res.json())
    .then(data => {
        data.forEach(char => {
            let hpElem = document.getElementById('hp-' + char.CharID);
            let percent = Math.max(0, Math.min(100, Math.round(char.HP / char.MaxHP * 100)));
            hpElem.style.width = percent + '%';
            hpElem.className = (percent > 60) ? 'hp-bar' : ((percent > 30) ? 'hp-bar warn' : 'hp-bar low');
        });
    })
    .catch(err => console.error(err));
}
setInterval(atualizarStatus, 1500);
</script>

</body>
</html>
