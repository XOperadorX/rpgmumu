<?php
session_start();
include "db.php";

if (!isset($_SESSION['PlayerID'])) {
    die("❌ Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// ===== Carrega saldo e carteira do banco =====
$query = "SELECT MoedaMumu, CarteiraJSON FROM Players WHERE PlayerID = ?";
$stmt = sqlsrv_query($conn, $query, [$playerID]);
if($stmt === false) die(print_r(sqlsrv_errors(), true));

$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
$moeda = $row['MoedaMumu'] ?? 500;
$carteira = !empty($row['CarteiraJSON']) ? json_decode($row['CarteiraJSON'], true) : [
    'Ouro'=>0,'Prata'=>0,'Bronze'=>0,'Cristal'=>0,'Esmeralda'=>0
];

// Ativos disponíveis
$ativos = [
    ['Nome'=>'Ouro','Preco'=>50],
    ['Nome'=>'Prata','Preco'=>30],
    ['Nome'=>'Bronze','Preco'=>10],
    ['Nome'=>'Cristal','Preco'=>100],
    ['Nome'=>'Esmeralda','Preco'=>150],
];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>📈 Bolsa RPG - Super Imersiva</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
body { background: radial-gradient(circle at top, #111 0%, #000 100%); color: #fff; font-family: 'Roboto', sans-serif; padding:2em; }
h1 { text-align:center; color:#ffd700; text-shadow: 0 0 8px rgba(255,215,0,0.8); margin-bottom:1em; }
.moedas { text-align:center; font-size:1.5em; color:#ff9900; font-weight:bold; margin-bottom:1em; transition: all 0.3s ease; }
.top-bar { display:flex; justify-content:space-between; background:#1a1a1a; padding:1em 2em; border-radius:1em; margin-bottom:1em; }
.top-bar a { color:#00bfff; text-decoration:none; font-weight:bold; }
.top-bar a:hover { color:#1ec8ff; text-decoration:underline; }
.ativos { display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:1.5em; position:relative; }
.ativo { background:#111; border:2px solid rgba(255,215,0,0.3); border-radius:1em; padding:1.5em; text-align:center; box-shadow:0 0 0.75em rgba(255,215,0,0.15); position:relative; overflow:hidden; transition: transform 0.2s, box-shadow 0.3s; }
.ativo:hover { transform:translateY(-0.3em); box-shadow:0 0 1.25em rgba(255,215,0,0.4); }
.ativo h3 { color:#ffd700; margin:0.5em 0; font-size:1.5em; }
.ativo p { margin:0.5em 0; }
input[type=number] { width:4em; text-align:center; border-radius:0.5em; padding:0.4em; border:1px solid #555; margin:0.5em 0; }
button { padding:0.6em 1em; margin:0.25em; border:none; border-radius:0.5em; cursor:pointer; font-weight:bold; transition:0.3s; }
.buy { background:linear-gradient(45deg,#28a745,#34d058); color:white; box-shadow:0 0 0.5em rgba(40,167,69,0.6); }
.buy:hover { box-shadow:0 0 1em rgba(40,167,69,0.9); }
.sell { background:linear-gradient(45deg,#dc3545,#ff4b5c); color:white; box-shadow:0 0 0.5em rgba(220,53,69,0.6); }
.sell:hover { box-shadow:0 0 1em rgba(220,53,69,0.9); }
.msg { text-align:center; font-weight:bold; margin:1em 0; font-size:1.2em; transition: all 0.3s ease; }
.msg-ativo { font-size: 1em; font-weight: bold; transition: opacity 0.5s ease; position: absolute; top: 0.5em; left: 50%; transform: translateX(-50%); }
#msg-global { text-align:center; font-size:1.3em; font-weight:bold; margin-bottom:1em; transition: all 0.5s ease; }
@keyframes moedaAnim { 0% {transform: translateY(0); opacity:1;} 50% {transform: translateY(-30px); opacity:0.8;} 100% {transform: translateY(-60px); opacity:0;} }
.moeda-flutua { position:absolute; font-size:1.2em; animation:moedaAnim 1s ease forwards; pointer-events:none; }
/* ====== CABEÇALHO ====== */
nav {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: rgba(30,30,30,0.9);
    padding: 15px 30px;
    box-shadow: 0 0 15px rgba(255,204,0,0.2);
    border-bottom: 2px solid #ffcc00;
    backdrop-filter: blur(6px);
    animation: fadeDown 0.8s ease-in-out;
}
@keyframes fadeDown {
    from { opacity: 0; transform: translateY(-20px); }
    to { opacity: 1; transform: translateY(0); }
}
nav a, nav button {
    background: none;
    border: none;
    color: #ffcc00;
    font-size: 1rem;
    font-weight: bold;
    text-decoration: none;
    cursor: pointer;
    transition: color 0.3s, transform 0.2s;
}
nav a:hover, nav button:hover {
    color: #00ccff;
    transform: scale(1.1);
}
/* ====== LINKS E BOTÕES GERAIS ====== */
.btn {
    display: inline-block;
    margin: 10px;
    padding: 10px 20px;
    border-radius: 8px;
    text-decoration: none;
    color: #fff;
    background: #333;
    font-weight: bold;
    transition: all 0.3s ease;
}
.btn:hover {
    background: #ffcc00;
    color: #000;
    box-shadow: 0 0 15px #ffcc0077;
}

</style>
</head>
<body>

<div class="container">


<nav style="display:flex; justify-content:center; align-items:center; margin:20px;">
    <form method="post" style="margin:0; display:flex; gap:15px; justify-content:center; align-items:center;">
        <!-- Botão para atualizar -->
        <button type="submit" class="btn" name="refresh">🔄 Atualizar</button>
        <!-- Link para a página de trade -->
        <a href="trade.php" class="btn">📈 Trade</a>
        <!-- Link para voltar ao dashboard -->
        <a href="dashboard.php" class="btn">⬅️ Voltar</a>
    </form>
</nav>

<h1>📈 Bolsa de Valores RPG</h1>
<p class="moedas">💰 Saldo: <span id="saldo"><?= $moeda ?></span> moedas</p>
<div id="msg-global"></div>
<p class="msg" id="msg"></p>

<div class="ativos">
<?php foreach($ativos as $a): 
    $qtd = $carteira[$a['Nome']] ?? 0;
?>
    <div class="ativo" data-nome="<?= $a['Nome'] ?>">
        <h3><?= $a['Nome'] ?></h3>
        <p>Preço: <?= $a['Preco'] ?> moedas</p>
        <p>Você possui: <span class="qtd"><?= $qtd ?></span></p>
        <input type="number" class="quantidade" value="1" min="1">
        <br>
        <button class="buy">Comprar</button>
        <button class="sell">Vender</button>
        <canvas class="grafico" width="220" height="100"></canvas>
        <div class="msg-ativo"></div>
    </div>
<?php endforeach; ?>
</div>
</div>

<script>
// ===== Bolsa RPG Super Imersiva =====
const ativosData = {
    'Ouro': { preco: 50, historico: [], ultimaVariacao: 0 },
    'Prata': { preco: 30, historico: [], ultimaVariacao: 0 },
    'Bronze': { preco: 10, historico: [], ultimaVariacao: 0 },
    'Cristal': { preco: 100, historico: [], ultimaVariacao: 0 },
    'Esmeralda': { preco: 150, historico: [], ultimaVariacao: 0 },
};

const charts = {};
const msgGlobal = document.getElementById('msg-global');

// Inicializa gráficos
document.querySelectorAll('.ativo').forEach(div => {
    const nome = div.dataset.nome;
    const ctx = div.querySelector('.grafico').getContext('2d');
    charts[nome] = new Chart(ctx, {
        type: 'line',
        data: { labels: [], datasets: [{ label: nome, data: [], borderColor: '#ffd700', backgroundColor: 'rgba(255,215,0,0.2)', tension:0.3, pointRadius:0 }] },
        options: { responsive:false, plugins:{legend:{display:false}}, scales:{x:{display:false}, y:{beginAtZero:true}} }
    });
});

// Atualiza preços e gráficos
function atualizarPrecos() {
    let somaVariacao = 0;

    document.querySelectorAll('.ativo').forEach(div => {
        const nome = div.dataset.nome;
        const ativo = ativosData[nome];

        div.querySelector('p').innerText = `Preço: ${ativo.preco} moedas`;
        const cor = ativo.ultimaVariacao > 0 ? '#4caf50' : (ativo.ultimaVariacao < 0 ? '#ff4b5c' : '#ffd700');
        div.querySelector('p').style.color = cor;

        ativo.historico.push(ativo.preco);
        if(ativo.historico.length > 20) ativo.historico.shift();
        charts[nome].data.labels = ativo.historico.map((_,i)=>i+1);
        charts[nome].data.datasets[0].data = ativo.historico;
        charts[nome].update();

        const msg = ativo.ultimaVariacao > 0 ? `📈 ${nome} subiu!` :
                    ativo.ultimaVariacao < 0 ? `📉 ${nome} caiu!` : '';
        mostrarMensagem(div, msg, cor);

        somaVariacao += ativo.ultimaVariacao;
    });

    if(somaVariacao > 0) {
        msgGlobal.innerText = "📈 Mercado em alta!";
        msgGlobal.style.color = "#4caf50";
    } else if(somaVariacao < 0) {
        msgGlobal.innerText = "📉 Mercado em baixa!";
        msgGlobal.style.color = "#ff4b5c";
    } else {
        msgGlobal.innerText = "💛 Mercado estável!";
        msgGlobal.style.color = "#ffd700";
    }
}

function mostrarMensagem(div, msg, cor) {
    const msgDiv = div.querySelector('.msg-ativo');
    msgDiv.innerText = msg;
    msgDiv.style.color = cor;
    msgDiv.style.opacity = 1;
    setTimeout(()=>{ msgDiv.style.opacity = 0; }, 2000);
}

function novaCotacao(nome) {
    const ativo = ativosData[nome];
    const precoAtual = ativo.preco;
    const variacao = precoAtual * (Math.random() * 0.2 - 0.1);
    ativo.preco = Math.max(1, Math.round(precoAtual + variacao));
    ativo.ultimaVariacao = ativo.preco - precoAtual;
    atualizarPrecos();
}

Object.keys(ativosData).forEach((nome, i) => {
    const intervalo = 30000 + i*15000;
    setInterval(()=>novaCotacao(nome), intervalo);
});

// ===== Animação de moedas ao comprar/vender =====
document.querySelectorAll('.ativo').forEach(div => {
    const input = div.querySelector('.quantidade');
    const qtdSpan = div.querySelector('.qtd');

    div.querySelector('.buy').addEventListener('click', () => { flutuarMoeda(qtdSpan, '+', input.value); });
    div.querySelector('.sell').addEventListener('click', () => { flutuarMoeda(qtdSpan, '-', input.value); });
});

function flutuarMoeda(element, sinal, quantidade){
    for(let i=0;i<Math.min(quantidade,10);i++){
        const moeda = document.createElement('span');
        moeda.className = 'moeda-flutua';
        moeda.innerText = sinal + '💰';
        document.body.appendChild(moeda);
        const rect = element.getBoundingClientRect();
        moeda.style.left = rect.left + rect.width/2 + 'px';
        moeda.style.top = rect.top + 'px';
        setTimeout(()=>moeda.remove(),1000);
    }
}
// ===== Comunicação AJAX =====
document.querySelectorAll('.ativo').forEach(div => {
    const nome = div.dataset.nome;
    const input = div.querySelector('.quantidade');
    const qtdSpan = div.querySelector('.qtd');

    div.querySelector('.buy').addEventListener('click', () => {
        transacao('comprar', nome, input.value, qtdSpan);
    });

    div.querySelector('.sell').addEventListener('click', () => {
        transacao('vender', nome, input.value, qtdSpan);
    });
});

function transacao(acao, ativo, quantidade, qtdSpan) {
    fetch('bolsa_ajax.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ acao, ativo, quantidade })
    })
    .then(r => r.json())
    .then(data => {
        if (data.error) {
            alert("⚠️ " + data.error);
            return;
        }
        document.getElementById('saldo').innerText = data.novo_saldo;
        qtdSpan.innerText = data.nova_qtd;
        mostrarMensagem(document.querySelector(`[data-nome="${ativo}"]`), data.msg, '#00ffcc');
    })
    .catch(err => console.error(err));
}

atualizarPrecos();
</script>

</body>
</html>
