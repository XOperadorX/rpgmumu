<?php
session_start();
include "db.php";
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['PlayerID'])) {
    echo json_encode(['success'=>false, 'message'=>"⛔ Faça login primeiro."]);
    exit;
}

$playerID = $_SESSION['PlayerID'];
$slotID   = $_POST['slotID'] ?? null;
$frutaID  = $_POST['frutaID'] ?? null;

if (!$slotID || !$frutaID) {
    echo json_encode(['success'=>false, 'message'=>"🌱 Escolha uma semente e um slot."]);
    exit;
}

// Função auxiliar
function safeQuery($conn, $sql, $params = []) {
    $stmt = sqlsrv_query($conn, $sql, $params);
    if ($stmt === false) {
        echo json_encode(['success'=>false, 'message'=>"❌ Erro SQL: ".print_r(sqlsrv_errors(), true)]);
        exit;
    }
    return $stmt;
}

// Verifica se slot está livre
$stmt = safeQuery($conn, "SELECT FrutaID FROM dbo.PlantacaoFazenda WHERE PlayerID = ? AND SlotID = ?", [$playerID, $slotID]);
$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
if ($row && $row['FrutaID']) {
    echo json_encode(['success'=>false, 'message'=>"🚫 Este slot já está ocupado!"]);
    exit;
}

// Verifica se o jogador tem a semente
$stmt = safeQuery($conn, "SELECT Quantidade FROM dbo.Sementes WHERE PlayerID = ? AND FrutaID = ?", [$playerID, $frutaID]);
$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

if (!$row || $row['Quantidade'] < 1) {
    echo json_encode(['success'=>false, 'message'=>"❌ Você não possui esta semente."]);
    exit;
}

// Atualiza/inicia o plantio
safeQuery($conn, "
    UPDATE dbo.Sementes SET Quantidade = Quantidade - 1 WHERE PlayerID = ? AND FrutaID = ?;
    DELETE FROM dbo.PlantacaoFazenda WHERE PlayerID = ? AND SlotID = ?;
    INSERT INTO dbo.PlantacaoFazenda (PlayerID, SlotID, FrutaID, DataPlantio)
    VALUES (?, ?, ?, GETDATE());
", [$playerID, $frutaID, $playerID, $slotID, $playerID, $slotID, $frutaID]);

echo json_encode(['success'=>true, 'message'=>"🌾 Semente plantada com sucesso!"]);
?>
