<?php
session_start();
include "db.php";

$playerID = $_SESSION['PlayerID'] ?? null;
if(!$playerID){ die(json_encode(['error'=>"⛔ Faça login para acessar."])); }

$acao = $_POST['acao'] ?? '';
$ativo = $_POST['ativo'] ?? '';
$quantidade = max(1, intval($_POST['quantidade'] ?? 1));

if(!$acao || !$ativo){
    die(json_encode(['error'=>"Dados inválidos."]));
}

// Busca saldo e carteira atual
$stmt = sqlsrv_query($conn, "SELECT MoedaMumu, CarteiraJSON FROM Players WHERE PlayerID = ?", [$playerID]);
$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

$saldo = $row['MoedaMumu'] ?? 500;
$carteira = !empty($row['CarteiraJSON']) ? json_decode($row['CarteiraJSON'], true) : [];

// Preços base (mesmo que no arquivo principal)
$precos = ['Ouro'=>50,'Prata'=>30,'Bronze'=>10,'Cristal'=>100,'Esmeralda'=>150];
$preco_atual = $precos[$ativo] ?? 0;

$msg = '';
$variacao = 0;

if($acao === 'comprar'){
    $total = $preco_atual * $quantidade;
    if($saldo < $total){
        die(json_encode(['error'=>"Saldo insuficiente!"]));
    }
    $saldo -= $total;
    $carteira[$ativo] = ($carteira[$ativo] ?? 0) + $quantidade;
    $msg = "Compra realizada!";
    $variacao = rand(1,5); // simula variação de preço
} elseif($acao === 'vender'){
    if(($carteira[$ativo] ?? 0) < $quantidade){
        die(json_encode(['error'=>"Você não possui essa quantidade!"]));
    }
    $total = $preco_atual * $quantidade;
    $saldo += $total;
    $carteira[$ativo] -= $quantidade;
    $msg = "Venda realizada!";
    $variacao = -rand(1,5); // simula variação de preço
} else {
    die(json_encode(['error'=>"Ação inválida."]));
}

// Simula nova variação de preço
$novo_preco = max(1, $preco_atual + $variacao);

// Salva saldo e carteira
sqlsrv_query($conn, "UPDATE Players SET MoedaMumu = ?, CarteiraJSON = ? WHERE PlayerID = ?", [$saldo, json_encode($carteira), $playerID]);

// Retorna JSON
echo json_encode([
    'novo_saldo'=>$saldo,
    'nova_qtd'=>$carteira[$ativo],
    'novo_preco'=>$novo_preco,
    'msg'=>$msg,
    'variacao'=>$variacao
]);
