<?php
session_start();
include "db.php";
include "check_ban.php";

header('Content-Type: application/json');

$playerID = $_SESSION['PlayerID'] ?? 0;
$itemID   = intval($_POST['itemID'] ?? 0);

if($playerID <= 0 || $itemID == 0){
    echo json_encode(['sucesso'=>false, 'mensagem'=>'Item inválido']);
    exit;
}

// ==========================
// Carrega inventário do banco
// ==========================
$stmtItens = sqlsrv_query($conn, "SELECT ItemID, Nome, Quantidade, Raridade FROM dbo.Items WHERE PlayerID = ?", [$playerID]);
$inventario = [];
if($stmtItens){
    while($row = sqlsrv_fetch_array($stmtItens, SQLSRV_FETCH_ASSOC)){
        $inventario[$row['ItemID']] = [
            'nome' => $row['Nome'],
            'qtd' => intval($row['Quantidade']),
            'raridade' => $row['Raridade'] ?? 'comum'
        ];
    }
}

// Mescla com drops da sessão
if(isset($_SESSION['inventario'])){
    foreach($_SESSION['inventario'] as $nome => $qtd){
        $encontrado = false;
        foreach($inventario as $id => &$item){
            if($item['nome'] === $nome){
                $item['qtd'] += $qtd;
                $encontrado = true;
                break;
            }
        }
        if(!$encontrado){
            $tempID = -(count($inventario) + 1);
            $inventario[$tempID] = [
                'nome' => $nome,
                'qtd' => $qtd,
                'raridade' => 'comum'
            ];
        }
    }
}

// ==========================
// Procura o item pelo ID
// ==========================
if(!isset($inventario[$itemID])){
    echo json_encode(['sucesso'=>false, 'mensagem'=>'Item inválido']);
    exit;
}

$item = $inventario[$itemID];

// ==========================
// Calcula moedas da venda
// ==========================
$raridadeVal = [
    'comum' => 50,
    'raro' => 150,
    'épico' => 500,
    'lendário' => 1000
];
$moedasGanhas = ($raridadeVal[$item['raridade']] ?? 50);

// ==========================
// Atualiza inventário
// ==========================
$item['qtd'] -= 1;
if($item['qtd'] <= 0){
    unset($inventario[$itemID]);
    if($itemID > 0){
        sqlsrv_query($conn, "DELETE FROM dbo.Items WHERE ItemID = ?", [$itemID]);
    } else {
        unset($_SESSION['inventario'][$item['nome']]);
    }
} else {
    $inventario[$itemID]['qtd'] = $item['qtd'];
    if($itemID > 0){
        sqlsrv_query($conn, "UPDATE dbo.Items SET Quantidade = ? WHERE ItemID = ?", [$item['qtd'], $itemID]);
    } else {
        $_SESSION['inventario'][$item['nome']] = $item['qtd'];
    }
}

// ==========================
// Atualiza moedas do jogador
// ==========================
sqlsrv_query($conn, "UPDATE dbo.Players SET MoedaMumu = MoedaMumu + ? WHERE PlayerID = ?", [$moedasGanhas, $playerID]);

// ==========================
// Grava no histórico de vendas
// ==========================
$acao = "Vendeu 1x " . $item['nome'] . " por $moedasGanhas moedas";
sqlsrv_query($conn, "INSERT INTO dbo.histvend (PlayerID, Acao, Data) VALUES (?, ?, GETDATE())", [$playerID, $acao]);

// ==========================
// Retorna JSON
// ==========================
echo json_encode([
    'sucesso' => true,
    'nova_qtd' => $item['qtd'] > 0 ? $item['qtd'] : 0,
    'moedas' => $moedasGanhas,
    'item_nome' => $item['nome']
]);
exit;
