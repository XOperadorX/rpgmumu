-- 1?? Verifica se a coluna 'Level' existe e cria se n�o existir
IF NOT EXISTS (
    SELECT * 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'Enemies' 
      AND COLUMN_NAME = 'Level'
)
BEGIN
    ALTER TABLE Enemies
    ADD [Level] INT DEFAULT 1;
    PRINT 'Coluna [Level] criada com sucesso!';
END
ELSE
BEGIN
    PRINT 'Coluna [Level] j� existe.';
END

-- 2?? Atualiza os n�veis dos inimigos
-- Aqui voc� pode definir a l�gica que quiser
-- Exemplo: n�vel proporcional ao XP (ajuste conforme necess�rio)
UPDATE Enemies
SET [Level] = CASE 
                 WHEN XP < 100 THEN 1
                 WHEN XP < 500 THEN 2
                 WHEN XP < 1000 THEN 3
                 ELSE 4
              END;

PRINT 'N�veis dos inimigos atualizados com sucesso!';
