<?php
session_start();
include "db.php";

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// Pega saldo da Moeda Mumu
$stmtMoeda = sqlsrv_query($conn, "SELECT MoedaMumu FROM Players WHERE PlayerID=?", [$playerID]);
$moeda = 0;
if($stmtMoeda && $row = sqlsrv_fetch_array($stmtMoeda, SQLSRV_FETCH_ASSOC)){
    $moeda = $row['MoedaMumu'];
}

// Pega personagens do jogador
$stmt = sqlsrv_query($conn, "SELECT * FROM Characters WHERE PlayerID=?", [$playerID]);
$personagens = [];
if($stmt && sqlsrv_has_rows($stmt)){
    while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)){
        $personagens[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Dashboard Visual - Mumu RPG</title>
<link rel="stylesheet" href="assets/css/style.css">
<style>
.dashboard-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px;
}

.character-card {
    background: #333;
    border: 2px solid #555;
    border-radius: 10px;
    padding: 15px;
    width: 220px;
    text-align: center;
    transition: 0.3s;
}

.character-card:hover {
    border-color: #ffcc00;
    box-shadow: 0 0 15px #ffcc00;
}

.character-card h3 {
    color: #ffcc00;
    margin-bottom: 5px;
}

.character-card p {
    margin: 5px 0;
}

.character-card a {
    display: block;
    margin: 5px 0;
    padding: 5px 10px;
    background: #444;
    border-radius: 5px;
    color: #fff;
    text-decoration: none;
    transition: 0.3s;
}

.character-card a:hover {
    background: #ffcc00;
    color: #000;
}

.logout-btn {
    display: inline-block;
    margin: 20px;
    padding: 10px 25px;
    background: #444;
    color: #fff;
    border-radius: 8px;
    text-decoration: none;
    transition: 0.3s;
}

.logout-btn:hover {
    background: #ff3333;
    color: #fff;
}

/* HP bars */
.hp-container {
    background: #555;
    width: 100%;
    border-radius: 5px;
    height: 15px;
    margin: 5px 0;
}

.hp-bar {
    height: 100%;
    border-radius: 5px;
    transition: width 0.5s;
    background: lightgreen;
}

.hp-bar.warn { background: orange; }
.hp-bar.low  { background: red; }
</style>
</head>
<body>
<h1>🏰 Painel Visual do Mumu RPG</h1>
<p>Bem-vindo, aventureiro!</p>

<div style="background:#333; color:#ffcc00; padding:10px; border-radius:8px; display:inline-block; margin-bottom:20px;">
    <p>💰 Moedas Mumu: <strong><?= $moeda ?></strong></p>
</div>

<div class="dashboard-container">
<?php if(!empty($personagens)): ?>
    <?php foreach($personagens as $char): ?>
<div class="character-card" data-charid="<?= $char['CharID'] ?>">
    <h3><?= $char['Name'] ?> (<?= $char['Class'] ?>)</h3>
    <p id="level-<?= $char['CharID'] ?>">Level: <?= $char['Level'] ?></p>
    <p id="xp-<?= $char['CharID'] ?>">XP: <?= $char['Exp'] ?? 0 ?></p>

    <?php
        $hp = $char['Life'] ?? $char['HP'] ?? 100;
        $max = $char['MaxLife'] ?? $char['MaxHP'] ?? 100;
        $percent = round($hp / $max * 100);
        $percent = max(0, min(100, $percent));
        $cls = ($percent > 60) ? '' : (($percent > 30) ? 'warn' : 'low');
    ?>
    <div class="hp-container" role="progressbar" aria-valuemin="0" aria-valuemax="<?= $max ?>" aria-valuenow="<?= $hp ?>">
        <div id="hp-<?= $char['CharID'] ?>" class="hp-bar <?= $cls ?>" style="width:<?= $percent ?>%"></div>
    </div>
    <div class="hp-text" id="hptext-<?= $char['CharID'] ?>">❤️ HP: <?= $hp ?> / <?= $max ?> (<?= $percent ?>%)</div>

    <a href="dung.php?CharID=<?= $char['CharID'] ?>">🗡️ Masmorra</a>
    <a href="equipar_item_advanced.php?CharID=<?= $char['CharID'] ?>">🎒 Inventário</a>
    <a href="del_personagem.php?CharID=<?= $char['CharID'] ?>">🗑️ Excluir</a>
</div>
    <?php endforeach; ?>
<?php else: ?>
    <p>Nenhum personagem encontrado. <a href="criar_personagem.php">Crie um agora!</a></p>
<?php endif; ?>
</div>

<a href="logout.php" class="logout-btn">🚪 Sair</a>

<script>
// Atualiza HP/XP/Level de todos os personagens
function atualizarStatus() {
    fetch('status_personagem.php')
    .then(res => res.json())
    .then(data => {
        data.forEach(char => {
            // HP
            let hpElem = document.getElementById('hp-' + char.CharID);
            let hpText = document.getElementById('hptext-' + char.CharID);
            let percent = Math.round(char.HP / char.MaxHP * 100);
            percent = Math.max(0, Math.min(100, percent));
            hpElem.style.width = percent + '%';
            if(percent > 60) hpElem.className = 'hp-bar';
            else if(percent > 30) hpElem.className = 'hp-bar warn';
            else hpElem.className = 'hp-bar low';
            hpText.innerText = '❤️ HP: ' + char.HP + ' / ' + char.MaxHP + ' (' + percent + '%)';

            // Level e XP
            document.getElementById('level-' + char.CharID).innerText = 'Level: ' + char.Level;
            document.getElementById('xp-' + char.CharID).innerText = 'XP: ' + char.Exp;
        });
    })
    .catch(err => console.error(err));
}

// Atualiza a cada 1.5s
setInterval(atualizarStatus, 1500);

</script>

</body>
</html>
