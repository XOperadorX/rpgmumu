<?php
session_start();
include "db.php";

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];


$sql = "SELECT c.CharID, c.Name, c.Class, c.Level, c.Exp, c.HP, pc.MoedaMumu
        FROM Characters c
        JOIN Players pc ON c.PlayerID = pc.PlayerID
        WHERE c.PlayerID = ?";

$params = array($playerID);
$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt === false) {
    die(print_r(sqlsrv_errors(), true));
}




?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Personagens</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<h1>👥 Seus Personagens</h1>

<!-- Status geral -->
<?php

echo "<table border='1' cellspacing='0' cellpadding='8' style='margin:20px auto; border-collapse:collapse; text-align:center;'>";
echo "<tr style='background:#333; color:#fff;'>
        <th>👤 Personagem</th>
        <th>Classe</th>
        <th>Level</th>
        <th>Experiência</th>
        <th>Vitalidade</th>
        <th>💰 Moedas Mumu</th>
      </tr>";

while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    echo "<tr>
            <td>{$row['Name']}</td>
            <td>{$row['Class']}</td>
            <td>{$row['Level']}</td>
            <td>{$row['Exp']}</td>
            <td>{$row['HP']}</td>
            <td>{$row['MoedaMumu']}</td>
          </tr>";
}

echo "</table>";








?>
	<!-- Inventário -->
<h2>🎒 Inventário</h2>
<?php
echo "<table border='1' cellspacing='0' cellpadding='8' style='margin:20px auto; border-collapse:collapse; text-align:center;'>";
echo "<tr style='background:#333; color:#fff;'>
        <th>Arma</th>
        <th>Escudo</th>
        <th>Capacete</th>
        <th>Armadura</th>
        <th>Luva</th>
        <th>Calça</th>
      </tr>";

while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    echo "<tr>

            <td>{$row['Arma']}</td>
            <td>{$row['Escudo']}</td>
            <td>{$row['Capacete']}</td>
            <td>{$row['Armadura']}</td>
            <td>{$row['Luva']}</td>
            <td>{$row['Calça']}</td>
          </tr>";
}

echo "</table>";


?>







<table border="1" cellpadding="8" cellspacing="0" style="border-collapse: collapse; width: 60%; margin:20px auto; text-align:center;">
    <tr style="background:#333; color:#fff;">
 
        <th>HP</th>
        <th>Experiência</th>

    </tr>
    <tr>

        <td><?= $_SESSION['dungeon']['char']['HP'] ?? '-' ?></td>
        <td><?= $_SESSION['dungeon']['char']['Exp'] ?? '-' ?></td>

    </tr>
</table>







<!-- Botões -->
<a href="dashboard.php" class="btn">⬅️ Voltar</a>
<a href="del_personagem.php?CharID=<?= $char['CharID'] ?>" class="btn" style="background:#ff3333;">🗑️ Excluir Personagem</a>


<script>
// Atualiza HP/XP/Level de todos os personagens
function atualizarStatus() {
    fetch('status_personagem.php')
    .then(res => res.json())
    .then(data => {
        data.forEach(char => {
            let hpElem = document.getElementById('hp-' + char.CharID);
            let hpText = document.getElementById('hptext-' + char.CharID);
            let percent = Math.max(0, Math.min(100, Math.round(char.HP / char.MaxHP * 100)));
            hpElem.style.width = percent + '%';
            hpElem.className = (percent > 60) ? 'hp-bar' : ((percent > 30) ? 'hp-bar warn' : 'hp-bar low');
            hpText.innerText = '❤️ HP: ' + char.HP + ' / ' + char.MaxHP + ' (' + percent + '%)';
            document.getElementById('level-' + char.CharID).innerText = 'Level: ' + char.Level;
            document.getElementById('xp-' + char.CharID).innerText = 'XP: ' + char.Exp;
        });
    })
    .catch(err => console.error(err));
}
setInterval(atualizarStatus, 1500);
</script>
</body>
</html>
