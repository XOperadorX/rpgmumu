<?php
session_start();
include "db.php";
include "check_ban.php"; // protege a página

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// Pega personagem
$stmt = sqlsrv_query($conn, "SELECT TOP 1 * FROM Characters WHERE PlayerID=?", [$playerID]);
$char = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
if(!$char){
    die("Você precisa ter pelo menos um personagem. <a href='dashboard.php'>⬅ Voltar</a>");
}

// Função para carregar inimigos + loot
function carregarInimigos() {
    global $conn;

    $enemies = [];
    $sql = "SELECT * FROM Enemies";
    $stmt = sqlsrv_query($conn, $sql);
    while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)){
        $enemyID = $row['EnemyID'];

        $loot = [];
        $sqlLoot = "SELECT ItemName, DropRate FROM EnemyLoot WHERE EnemyID = ?";
        $stmtLoot = sqlsrv_query($conn, $sqlLoot, [$enemyID]);
        while($lootRow = sqlsrv_fetch_array($stmtLoot, SQLSRV_FETCH_ASSOC)){
            $loot[] = [
                'ItemName' => $lootRow['ItemName'],
                'DropRate' => $lootRow['DropRate']
            ];
        }

        $row['Loot'] = $loot;

        // Atributos extras para a dungeon
        $row['HP'] = $row['HP'];
        $row['MaxHP'] = $row['HP'];
        $row['Mana'] = $row['Mana'] ?? 0;
        $row['MaxMana'] = $row['Mana'] ?? 0;
        $row['XP'] = $row['XP'] ?? 0;

        $enemies[] = $row;
    }

    return $enemies;
}

// Dungeon ativa?
if(!isset($_SESSION['dungeon']) || $_SESSION['dungeon']['playerID'] != $playerID){
    $_SESSION['dungeon'] = [
        'playerID' => $playerID,
        'current' => 0,
        'enemies' => carregarInimigos(),
        'fim' => false
    ];
}

$dungeon = &$_SESSION['dungeon'];
$enemy = $dungeon['enemies'][$dungeon['current']] ?? null;
$fim = $dungeon['fim'] ?? false;
$hpZerado = $char['HP'] <= 0;

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Dungeon - RPGMumu</title>
<style>
/* ====== Body ====== */
body {
    background: linear-gradient(135deg, #1c1c1c, #121212);
    color: #eee;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    text-align: center;
    margin: 0;
    padding: 20px;
}

/* ====== Container de Cards ====== */
.cards-container {
    display: flex;
    justify-content: center;
    gap: 40px;
    flex-wrap: wrap;
    margin-top: 40px;
}

/* ====== Cards ====== */
.card {
    background: #2a2a2a;
    border: 2px solid #f39c12;
    border-radius: 15px;
    width: 260px;
    padding: 15px;
    box-shadow: 0 0 15px rgba(243, 156, 18, 0.7), inset 0 0 10px rgba(243, 156, 18, 0.2);
    transition: transform 0.3s, box-shadow 0.3s;
}

.card:hover {
    transform: scale(1.05);
    box-shadow: 0 0 25px rgba(243, 156, 18, 1), inset 0 0 15px rgba(243,156,18,0.3);
}

/* ====== Barras de Progresso ====== */
.progress {
    width: 100%;
    background: #444;
    border-radius: 5px;
    margin: 5px 0;
    height: 18px;
    overflow: hidden;
}

.bar {
    height: 100%;
    border-radius: 5px;
    transition: width 0.5s, background 0.5s;
}

/* ====== HP ====== */
.bar.hp {
    background: #2ecc71; /* verde */
}
.bar.hp-low {
    animation: pulse-red 0.8s infinite;
}

/* ====== MP ====== */
.bar.mp {
    background: #3498db; /* azul */
}
.bar.mp-low {
    animation: pulse-blue 1s infinite;
}

/* ====== XP ====== */
.bar.xp-bar {
    background: #9b59b6; /* roxo */
    animation: glow-purple 2s infinite alternate;
}

/* ====== Power ====== */
.bar.power-bar {
    background: #f1c40f; /* amarelo */
    box-shadow: 0 0 8px rgba(241,196,15,0.6);
    animation: glow-gold 1.2s infinite alternate;
}
.bar.power-bar.high { background: gold; box-shadow: 0 0 12px gold; animation: glow-gold 1s infinite alternate; }
.bar.power-bar.medium { background: orange; box-shadow: 0 0 8px orange; }
.bar.power-bar.low { background: #e67e22; box-shadow: 0 0 6px #e67e22; }

/* ====== Animações ====== */
@keyframes pulse-red {
    0% { box-shadow: 0 0 6px rgba(231,76,60,0.6); }
    50% { box-shadow: 0 0 25px rgba(231,76,60,1); transform: scaleX(1.08); }
    100% { box-shadow: 0 0 6px rgba(231,76,60,0.6); }
}

@keyframes pulse-blue {
    0% { box-shadow: 0 0 6px rgba(52,152,219,0.6); }
    50% { box-shadow: 0 0 20px rgba(52,152,219,1); transform: scaleX(1.05);}
    100% { box-shadow: 0 0 6px rgba(52,152,219,0.6); }
}

@keyframes glow-purple {
    0% { box-shadow: 0 0 6px rgba(155,89,182,0.5); }
    50% { box-shadow: 0 0 20px rgba(155,89,182,0.9); transform: scaleX(1.02);}
    100% { box-shadow: 0 0 6px rgba(155,89,182,0.5); }
}

@keyframes glow-gold {
    0% { box-shadow: 0 0 8px rgba(241,196,15,0.5); }
    50% { box-shadow: 0 0 20px rgba(241,196,15,1); transform: scaleX(1.05);}
    100% { box-shadow: 0 0 8px rgba(241,196,15,0.5); }
}

/* ====== Botão Voltar ====== */
#voltar {
    display: none;
    position: fixed;
    top: 15px;
    left: 15px;
    padding: 10px 20px;
    background: #34495e;
    color: #ecf0f1;
    text-decoration: none;
    border-radius: 5px;
    font-weight: bold;
    box-shadow: 0 0 10px rgba(0,0,0,0.7);
    transition: 0.3s, opacity 0.5s;
    z-index: 1000;
    font-size: 1.1em;
}

#voltar.show {
    display: block;
    opacity: 1;
}

#voltar:hover {
    background: #f1c40f;
    color: #2c3e50;
    transform: scale(1.1);
}

/* ====== Pulsar efeito mágico ====== */
.pulsar {
    animation: pulse 1s infinite;
}

.pulsar-strong {
    animation: pulse 0.7s infinite;
}

@keyframes pulse {
    0% { transform: scale(1); box-shadow: 0 0 8px rgba(241,196,15,0.6);}
    50% { transform: scale(1.15); box-shadow: 0 0 25px rgba(241,196,15,1);}
    100% { transform: scale(1); box-shadow: 0 0 8px rgba(241,196,15,0.6);}
}

</style>

</head>
<body>

<a id="voltar" href="dashboard.php">⬅️ Voltar</a>
<h1>🗡️ Masmorra - <?= htmlspecialchars($char['Name']) ?></h1>


<?php if($hpZerado): ?>
    <p style="color:red; font-size:1.3em;">💀 Você morreu! Dungeon encerrada.</p>
<?php elseif($fim): ?>
    <p style="color:yellow; font-size:1.3em;">🏁 Parabéns! Todos os inimigos foram derrotados!</p>
<?php endif; ?>

<div class="cards-container">
    <!-- Player -->
    <div class="card">
        <h3><?= htmlspecialchars($char['Name']) ?></h3>
        <p>Level: <?= $char['Level'] ?> | XP: <?= $char['Exp'] ?></p>
		
        <div class="progress"><div class="bar player-bar" style="width:<?= round($char['Power']/$char['MaxPower']*100) ?>%"></div></div>
        <p>Poder: <?= $char['Power'] ?> / <?= $char['MaxPower'] ?></p>
		
        <div class="progress"><div class="bar player-bar" style="width:<?= round($char['HP']/$char['MaxHP']*100) ?>%"></div></div>
        <p>HP: <?= $char['HP'] ?> / <?= $char['MaxHP'] ?></p>
		
        <div class="progress"><div class="bar mana-bar" style="width:<?= round($char['Mana']/$char['MaxMana']*100) ?>%"></div></div>
        <p>Mana: <?= $char['Mana'] ?> / <?= $char['MaxMana'] ?></p>
		
        <div class="progress"><div class="bar xp-bar" style="width:<?= round(($char['Exp']/($char['Level']*50))*100) ?>%"></div></div>
        <p>XP: <?= $char['Exp'] ?> / <?= $char['Level']*50 ?></p>
    </div>

    <!-- Enemy -->
    <?php if($enemy): ?>
    <div class="card">
        <h3><?= htmlspecialchars($enemy['Name']) ?></h3>
        <p>Level: <?= $enemy['Level'] ?> | XP: <?= $enemy['XP'] ?></p>
        <div class="progress"><div class="bar enemy-bar" style="width:<?= round($enemy['HP']/$enemy['MaxHP']*100) ?>%"></div></div>
        <p>HP: <?= $enemy['HP'] ?> / <?= $enemy['MaxHP'] ?></p>
        <div class="progress"><div class="bar mana-bar" style="width:<?= round($enemy['Mana']/$enemy['MaxMana']*100) ?>%"></div></div>
        <p>Mana: <?= $enemy['Mana'] ?> / <?= $enemy['MaxMana'] ?></p>
    </div>
    <?php endif; ?>
</div>

<h2>Historico de Ataques</h2>
<div class="log" id="log"></div>



<script>
function getGradient(value, type) {
    if(type === 'hp') {
        if(value > 0.5) return `linear-gradient(90deg, #2ecc71, #27ae60)`; // verde
        if(value > 0.25) return `linear-gradient(90deg, #f1c40f, #e67e22)`; // amarelo
        return `linear-gradient(90deg, #e74c3c, #c0392b)`; // vermelho
    }
    if(type === 'mana') return `linear-gradient(90deg, #3498db, #2980b9)`; // azul
    if(type === 'xp') return `linear-gradient(90deg, #9b59b6, #8e44ad)`; // roxo
}

// Atualiza barras e animações
function atualizarBarras(char, enemy=null) {
    const hpPercent = char.HP / char.MaxHP * 100;
    const manaPercent = char.Mana / char.MaxMana * 100;
    const xpPercent = char.Exp / (char.Level*50) * 100;

    const playerBar = document.querySelector(".player-bar");
    playerBar.style.width = hpPercent + "%";
    playerBar.style.background = getGradient(char.HP/char.MaxHP, 'hp');

    // Adiciona efeito pulsar se HP < 25%
    if(char.HP/char.MaxHP <= 0.25) playerBar.classList.add('hp-low');
    else playerBar.classList.remove('hp-low');

    const manaBar = document.querySelector(".mana-bar");
    manaBar.style.width = manaPercent + "%";
    manaBar.style.background = getGradient(char.Mana/char.MaxMana, 'mana');

    const xpBar = document.querySelector(".xp-bar");
    xpBar.style.width = xpPercent + "%";
    xpBar.style.background = getGradient(char.Exp/(char.Level*50), 'xp');

    if(enemy){
        const enemyHPBar = document.querySelector(".enemy-bar");
        enemyHPBar.style.width = (enemy.HP/enemy.MaxHP*100)+"%";
        enemyHPBar.style.background = getGradient(enemy.HP/enemy.MaxHP, 'hp');
        if(enemy.HP/enemy.MaxHP <= 0.25) enemyHPBar.classList.add('hp-low');
        else enemyHPBar.classList.remove('hp-low');
    }
}

// Fetch dos turnos
function atualizarDungeon(){
    fetch("turno.php")
    .then(r=>r.json())
    .then(data=>{
        atualizarBarras(data.char, data.enemy);
        document.getElementById("log").innerHTML += data.log.map(l=>"<div>"+l+"</div>").join("");
        if(data.fim){
            let btn = document.getElementById("voltar");
            btn.style.display="inline-block";
            btn.classList.add('pulsar');
        } else setTimeout(atualizarDungeon, 1200);
    })
    .catch(err=>console.error(err));
}

<?php if(!$hpZerado && !$fim): ?>
atualizarDungeon();
<?php else: ?>
document.getElementById("voltar").style.display="inline-block";
<?php endif; ?>
</script>




<script>
<?php if(!$hpZerado && !$fim): ?>
function atualizarDungeon(){
    fetch("turno.php")
    .then(r=>r.json())
    .then(data=>{
        // Atualiza player
        document.querySelector(".player-bar").style.width = (data.char.HP/data.char.MaxHP*100)+"%";
        document.querySelector(".xp-bar").style.width = (data.char.Exp/(data.char.Level*50)*100)+"%";
        document.getElementById("log").innerHTML += data.log.map(l=>"<div>"+l+"</div>").join("");

        // Atualiza enemy se existir
        if(data.enemy){
            document.querySelector(".enemy-bar").style.width = (data.enemy.HP/data.enemy.MaxHP*100)+"%";
        }

        // Dungeon fim
        if(data.fim){
            let btn = document.getElementById("voltar");
            btn.style.display="inline-block";
            btn.classList.add('pulsar');
        } else {
            setTimeout(atualizarDungeon, 1200);
        }
    })
    .catch(err=>console.error(err));
}
atualizarDungeon();
<?php else: ?>
document.getElementById("voltar").style.display="inline-block";
<?php endif; ?>


<?php
// --- Bonus dinâmico para mostrar no frontend ---
$bonusDisplay = [];

// Bonus por Level
$bonusDisplay[] = "Level: +".($char['Level'])."% de chance extra de loot";

// Bonus por itens de sorte
if(isset($_SESSION['itens'])){
    foreach($_SESSION['itens'] as $item => $qtd){
        if($qtd > 0) $bonusDisplay[] = "Item ativo: $item";
    }
}

// Eventos ativos
$hoje = date('Y-m-d');
$stmt = sqlsrv_query($conn, "SELECT EventName FROM LootEvents WHERE ? BETWEEN StartDate AND EndDate", [$hoje]);
while($event = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)){
    $bonusDisplay[] = "Evento ativo: {$event['EventName']}";
}
?>
// Mostra bônus de loot no frontend
let bonusLogDiv = document.getElementById("bonus-log");
<?php if(!empty($bonusDisplay)): ?>
bonusLogDiv.innerHTML = <?php echo json_encode(implode("<br>", $bonusDisplay)); ?>;
<?php else: ?>
bonusLogDiv.innerHTML = "Nenhum bônus ativo";
<?php endif; ?>



</script>

</body>
</html>
