<?php
session_start();
include "db.php";

$playerID = $_SESSION['PlayerID'] ?? 0;
$result = [];

// Pega personagens do player
$stmt = sqlsrv_query($conn, "SELECT * FROM Characters WHERE PlayerID=?", [$playerID]);
if($stmt){
    while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)){
        $charID = $row['CharID'];
        
        // Checa se está em dungeon ativa
        $hpAtual = $row['Life'] ?? $row['HP'] ?? 100;
        $maxHP = $row['MaxLife'] ?? $row['MaxHP'] ?? 100;
        $level = $row['Level'];
        $exp = $row['Exp'];

        if(isset($_SESSION['dungeon']['playerID']) && $_SESSION['dungeon']['playerID'] == $playerID){
            if(isset($_SESSION['dungeon']['char']) && $_SESSION['dungeon']['char']['CharID'] == $charID){
                // usa HP atual da dungeon
                $hpAtual = $_SESSION['dungeon']['char']['HP'];
                $maxHP = $_SESSION['dungeon']['char']['MaxHP'];
                $level = $_SESSION['dungeon']['char']['Level'];
                $exp = $_SESSION['dungeon']['char']['Exp'];
            }
        }

        $result[] = [
            'CharID' => $charID,
            'HP' => $hpAtual,
            'MaxHP' => $maxHP,
            'Level' => $level,
            'Exp' => $exp
        ];
    }
}

header('Content-Type: application/json');
echo json_encode($result);
