<?php
session_start();
include "db.php";
// include "check_ban.php";

// Buscar inimigos
$enemies = [];
$stmt = sqlsrv_query($conn, "SELECT * FROM Enemies ORDER BY Level");

if ($stmt) {
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        // Buscar loot do inimigo
        $loot = [];
        $stmtLoot = sqlsrv_query($conn, "SELECT ItemName FROM EnemyLoot WHERE EnemyID=?", [$row['EnemyID']]);
        if ($stmtLoot) {
            while ($l = sqlsrv_fetch_array($stmtLoot, SQLSRV_FETCH_ASSOC)) {
                if (!empty($l['ItemName'])) $loot[] = $l['ItemName'];
            }
        } else {
            die(print_r(sqlsrv_errors(), true));
        }

        $row['Loot'] = $loot;
        $enemies[] = $row;
    }
} else {
    die(print_r(sqlsrv_errors(), true));
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>⚔️ Editar Inimigos</title>
<style>
    table { border-collapse: collapse; width: 100%; max-width: 1000px; margin: 20px auto; }
    th, td { border: 1px solid #999; padding: 8px; text-align: center; vertical-align: top; }
    input { width: 90%; }
    button { padding: 4px 8px; margin:2px 0; }
    a { margin-left: 5px; }
    .loot-item { display: flex; gap:5px; margin-bottom:2px; }
    .top-bar { display: flex; justify-content: center; gap: 30px; padding: 12px 0; background-color: #2c3e50; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
    .top-bar a { text-decoration: none; color: #ecf0f1; font-weight: 600; font-size: 16px; padding: 6px 12px; border-radius: 6px; transition: all 0.3s ease; }
    .top-bar a:hover { background-color: #3498db; color: #fff; transform: translateY(-2px); box-shadow: 0 4px 6px rgba(0,0,0,0.2); }
</style>
<script>
function addLootField(enemyId) {
    const container = document.getElementById('loot-container-' + enemyId);
    const div = document.createElement('div');
    div.className = 'loot-item';
    div.innerHTML = `<input type="text" name="Loot[${enemyId}][]" value=""> 
                     <button type="button" onclick="this.parentNode.remove()">❌</button>`;
    container.appendChild(div);
}
</script>
</head>
<body>

<h1 style="text-align:center;">⚔️ Inimigos</h1>

<nav class="top-bar">
    <a href="admin_dashboard.php">⬅ Voltar</a>
    <a href="new_enemy.php">➕ Novo inimigo</a>
</nav>

<table>
<tr>
    <th>Nome</th><th>Lvl</th><th>XP</th><th>HP</th><th>Mana</th><th>Loot</th><th>Ações</th>
</tr>

<?php foreach ($enemies as $e): ?>
<tr>
    <form method="post" action="save_enemy.php">
        <input type="hidden" name="EnemyID" value="<?= $e['EnemyID'] ?>">
        <td><input type="text" name="Name" value="<?= htmlspecialchars($e['Name']) ?>"></td>
        <td><input type="number" name="Level" value="<?= $e['Level'] ?>" style="width:60px"></td>
        <td><input type="number" name="XP" value="<?= $e['XP'] ?>" style="width:60px"></td>
        <td>
            <input type="number" name="HP" value="<?= $e['HP'] ?>" style="width:70px"> / 
            <input type="number" name="MaxHP" value="<?= $e['MaxHP'] ?>" style="width:70px">
        </td>
        <td>
            <input type="number" name="Mana" value="<?= $e['Mana'] ?>" style="width:70px"> / 
            <input type="number" name="MaxMana" value="<?= $e['MaxMana'] ?>" style="width:70px">
        </td>
        <td>
            <div id="loot-container-<?= $e['EnemyID'] ?>">
                <?php foreach ($e['Loot'] as $item): ?>
                    <div class="loot-item">
                        <input type="text" name="Loot[<?= $e['EnemyID'] ?>][]" value="<?= htmlspecialchars($item) ?>">
                        <button type="button" onclick="this.parentNode.remove()">❌</button>
                    </div>
                <?php endforeach; ?>
            </div>
            <button type="button" onclick="addLootField(<?= $e['EnemyID'] ?>)">➕ Loot</button>
        </td>
        <td>
            <button type="submit" name="editar">Salvar Tudo</button>
        </td>
    </form>
</tr>
<?php endforeach; ?>
</table>
</body>
</html>
