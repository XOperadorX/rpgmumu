<?php
session_start();
include "db.php";
include "check_ban.php";

header('Content-Type: application/json');

if(!isset($_SESSION['PlayerID'])){
    echo json_encode(['success'=>false,'message'=>"⛔ Acesso negado. Faça login."]);
    exit;
}

$playerID = $_SESSION['PlayerID'];
$valorRestaurar = 500;

// Busca atributos atuais
$sql = "SELECT HP, MaxHP, Mana, MaxMana, Power, MaxPower, MoedaMumu 
        FROM Characters c
        JOIN Players p ON c.PlayerID = p.PlayerID
        WHERE c.PlayerID = ?";
$params = [$playerID];
$stmt = sqlsrv_query($conn, $sql, $params);
$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

if(!$row){
    echo json_encode(['success'=>false,'message'=>"Erro ao buscar atributos."]);
    exit;
}

// Verifica se todos atributos já estão 100%
$hpFull = $row['HP'] >= $row['MaxHP'];
$manaFull = $row['Mana'] >= $row['MaxMana'];
$powerFull = $row['Power'] >= $row['MaxPower'];

if($hpFull && $manaFull && $powerFull){
    // Não precisa gastar MoedaMumu
    echo json_encode([
        'success' => true,
        'message' => "⚡ Atributos já estão completos, nenhum gasto necessário!",
        'HP' => $row['HP'],
        'MaxHP' => $row['MaxHP'],
        'Mana' => $row['Mana'],
        'MaxMana' => $row['MaxMana'],
        'Power' => $row['Power'],
        'MaxPower' => $row['MaxPower'],
        'MoedaMumu' => $row['MoedaMumu']
    ]);
    exit;
}

// ⚠️ Caso algum atributo esteja abaixo do máximo, deduz MoedaMumu
$saldo = $row['MoedaMumu'] ?? 0;
if($saldo < $valorRestaurar){
    echo json_encode([
        'success' => false,
        'message' => "⛔ Saldo de MoedaMumu insuficiente. Você precisa de $valorRestaurar MoedaMumu."
    ]);
    exit;
}

// Deduz MoedaMumu
$sql = "UPDATE Players SET MoedaMumu = MoedaMumu - ? WHERE PlayerID = ?";
$params = [$valorRestaurar, $playerID];
$stmt = sqlsrv_query($conn, $sql, $params);
if($stmt === false){
    echo json_encode(['success'=>false,'message'=>"Erro ao deduzir MoedaMumu."]);
    exit;
}

// Restaura atributos
$sql = "UPDATE Characters SET HP = MaxHP, Mana = MaxMana, Power = MaxPower WHERE PlayerID = ?";
$params = [$playerID];
$stmt = sqlsrv_query($conn, $sql, $params);
if($stmt === false){
    echo json_encode(['success'=>false,'message'=>"Erro ao restaurar atributos."]);
    exit;
}

// Busca atributos atualizados
$sql = "SELECT HP, MaxHP, Mana, MaxMana, Power, MaxPower, MoedaMumu 
        FROM Characters c
        JOIN Players p ON c.PlayerID = p.PlayerID
        WHERE c.PlayerID = ?";
$params = [$playerID];
$stmt = sqlsrv_query($conn, $sql, $params);
$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

// Atualiza sessão
$_SESSION['char'] = [
    'HP' => $row['HP'],
    'MaxHP' => $row['MaxHP'],
    'Mana' => $row['Mana'],
    'MaxMana' => $row['MaxMana'],
    'Power' => $row['Power'],
    'MaxPower' => $row['MaxPower']
];

// Retorna sucesso
echo json_encode([
    'success' => true,
    'message' => "✅ Atributos restaurados por $valorRestaurar MoedaMumu!",
    'HP' => $row['HP'],
    'MaxHP' => $row['MaxHP'],
    'Mana' => $row['Mana'],
    'MaxMana' => $row['MaxMana'],
    'Power' => $row['Power'],
    'MaxPower' => $row['MaxPower'],
    'MoedaMumu' => $row['MoedaMumu']
]);
