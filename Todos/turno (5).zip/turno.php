<?php
session_start();
include "db.php";
include "check_ban.php";

header('Content-Type: application/json');

$response = ['log'=>[], 'char'=>null, 'enemy'=>null, 'loot'=>[], 'fim'=>false];

// Verifica sessão
if(!isset($_SESSION['PlayerID']) || !isset($_SESSION['dungeon'])){
    $response['fim'] = true;
    echo json_encode($response);
    exit;
}

$dungeon = &$_SESSION['dungeon'];
$char = &$dungeon['char'];
$enemy = &$dungeon['enemy'];

// === Validação dos campos obrigatórios ===
$camposObrigatorios = ['Name','HP','MaxHP','MinDmg','MaxDmg'];
foreach ($camposObrigatorios as $campo) {
    if(!isset($char[$campo]) || !isset($enemy[$campo])){
        die(json_encode([
            'erro'=>"Campo faltando: $campo",
            'char'=>$char,
            'enemy'=>$enemy
        ]));
    }
}

// Função de ataque
function ataque(&$atacante, &$alvo){
    $min = max(0, intval($atacante['MinDmg']));
    $max = max($min, intval($atacante['MaxDmg']));
    $dano = rand($min, $max);
    $alvo['HP'] -= $dano;
    if($alvo['HP'] < 0) $alvo['HP'] = 0;
    return "{$atacante['Name']} atacou {$alvo['Name']} causando $dano de dano!";
}

// Função de loot
function gerar_loot($enemyID, $conn){
    $loot = [];
    $stmt = sqlsrv_query($conn, "SELECT ItemName, DropChance FROM EnemyLoot WHERE EnemyID=?", [$enemyID]);
    if($stmt === false) return [];
    while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)){
        $chance = intval($row['DropChance'] ?? 0);
        if($chance > 0 && rand(1,100) <= $chance){
            $loot[] = $row['ItemName'];
        }
    }
    return $loot;
}

// ==== TURNO DO PERSONAGEM ====
$response['log'][] = ataque($char, $enemy);

// Verifica se inimigo morreu
if($enemy['HP'] <= 0){
    $response['log'][] = "{$enemy['Name']} foi derrotado!";
    $response['fim'] = true;

    // Gera loot
    $enemyLocal = $enemy; // salva antes de remover da sessão
    $response['loot'] = gerar_loot($enemyLocal['EnemyID'], $conn);
    if(!isset($_SESSION['loot'])) $_SESSION['loot'] = [];
    $_SESSION['loot'] = array_merge($_SESSION['loot'], $response['loot']);

    // Remove inimigo da dungeon
    unset($_SESSION['dungeon']['enemy']);

} else {
    // ==== TURNO DO INIMIGO ====
    $response['log'][] = ataque($enemy, $char);

    if($char['HP'] <= 0){
        $response['log'][] = "{$char['Name']} foi derrotado!";
        $response['fim'] = true;
        // Aqui você pode resetar a dungeon ou tomar outra ação
    }
}

// Atualiza sessão
$_SESSION['dungeon']['char'] = $char;
if(isset($enemy)) $_SESSION['dungeon']['enemy'] = $enemy;

$response['char'] = $char;
$response['enemy'] = $enemy ?? null;

echo json_encode($response);
