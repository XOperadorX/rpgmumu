<?php
session_start();
include "db.php";

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

if(!isset($_SESSION['dungeon'])){
    die(json_encode(['erro'=>'Dungeon não iniciada']));
}

$dungeon = &$_SESSION['dungeon'];
$char = &$dungeon['char'];
$current = $dungeon['current'];

// Se acabou
if($current >= count($dungeon['enemies'])){
    echo json_encode([
        'fim'=>true,
        'char'=>$char,
        'enemy'=>['Name'=>'Fim','HP'=>0,'MaxHP'=>0,'Mana'=>0,'MaxMana'=>0],
        'log'=>$dungeon['log'],
        'loot'=>[]
    ]);
    exit;
}

$enemy = &$dungeon['enemies'][$current];
$log = [];

// Player ataca
$dano = rand(5,15);
$enemy['HP'] -= $dano;
$log[] = "🗡️ ".$char['Name']." causou $dano de dano em ".$enemy['Name'];

// Inimigo ataca (se vivo)
if($enemy['HP'] > 0){
    $danoInimigo = rand(3,10);
    $char['HP'] -= $danoInimigo;
    $log[] = "💥 ".$enemy['Name']." causou $danoInimigo de dano em ".$char['Name'];
}

// Loot aleatório
$lootArray = [];
if($enemy['HP'] <= 0){
    $log[] = "⚔️ Você derrotou ".$enemy['Name']."!";

    // Chance de 50% de dropar algo
    if(rand(1,100) <= 50){
        // Inimigo pode ter mais de um loot possível
        $possiveis = (array)$enemy['Loot'];
        $loot = $possiveis[array_rand($possiveis)];

        // Insere no inventário
        $stmtLoot = sqlsrv_query($conn, "INSERT INTO Items (CharID, Name) VALUES (?,?)", [
            $char['CharID'], $loot
        ]);

        if($stmtLoot){
            $log[] = "🎁 Você encontrou: $loot";
            $lootArray[] = $loot;
        }
    } else {
        $log[] = "📭 Nenhum item encontrado desta vez...";
    }

    // Dá XP
    $char['Exp'] += $enemy['XP'];

    // Próximo inimigo
    $dungeon['current']++;
}

// Fim da dungeon se player morreu
$fim = false;
if($char['HP'] <= 0){
    $log[] = "☠️ Você foi derrotado...";
    $fim = true;
}

// Atualiza sessão
$dungeon['char'] = $char;
$dungeon['enemies'][$current] = $enemy;
$dungeon['log'] = array_merge($dungeon['log'],$log);

// Resposta JSON
echo json_encode([
    'fim'=>$fim,
    'char'=>$char,
    'enemy'=>$enemy,
    'log'=>$log,
    'loot'=>$lootArray
]);
