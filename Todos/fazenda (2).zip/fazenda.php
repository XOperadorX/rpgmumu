<?php
session_start();
include "db.php";

if (!isset($_SESSION['PlayerID'])) {
    die("⛔ Faça login primeiro.");
}

$playerID = $_SESSION['PlayerID'];

// Função segura para executar query
function safeQuery($conn, $sql, $params = []) {
    $stmt = sqlsrv_query($conn, $sql, $params);
    if ($stmt === false) {
        echo "<pre>❌ Erro na query:\n$sql\n";
        print_r(sqlsrv_errors());
        echo "</pre>";
        return [];
    }
    $result = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $result[] = $row;
    }
    return $result;
}

// Busca slots de plantio
$slots = safeQuery($conn, "
    SELECT pf.SlotID, pf.FrutaID, pf.DataPlantio, f.Nome AS Fruta, f.TempoCrescimento
    FROM dbo.PlantacaoFazenda pf
    LEFT JOIN dbo.Frutas f ON pf.FrutaID = f.FrutaID
    WHERE pf.PlayerID = ?", [$playerID]);

// Busca inventário de sementes
$sementes = safeQuery($conn, "
    SELECT s.FrutaID, f.Nome, s.Quantidade
    FROM dbo.Sementes s
    JOIN dbo.Frutas f ON s.FrutaID = f.FrutaID
    WHERE s.PlayerID = ?", [$playerID]);

// Busca inventário de frutas colhidas
$frutas = safeQuery($conn, "
    SELECT i.FrutaID, f.Nome, i.Quantidade
    FROM dbo.InventarioFrutas i
    JOIN dbo.Frutas f ON i.FrutaID = f.FrutaID
    WHERE i.PlayerID = ?", [$playerID]);
	
// Busca saldo da Poupança do jogador
$saldo = safeQuery($conn, "
    SELECT Poupanca 
    FROM dbo.BankAccounts 
    WHERE PlayerID = ?", [$playerID]);

$poupanca = isset($saldo[0]['Poupanca']) ? number_format($saldo[0]['Poupanca'], 2, ',', '.') : '0,00';


	
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>🌾 Fazenda - RPG</title>
<style>
/* ==================== BASE ==================== */
body { 
    font-family: 'Orbitron', Arial, sans-serif; 
    background: #0a0a0a; 
    color: #fff; 
    text-align: center; 
    padding: 20px; 
}

/* ==================== CONTAINER ==================== */
.container { 
    max-width: 900px; 
    margin: auto; 
}

/* ==================== SLOT ==================== */
.slot { 
    width: 120px; 
    height: 120px; 
    background: #222; 
    border: 2px solid #00ffcc; 
    border-radius: 12px; 
    display: inline-block; 
    margin: 10px; 
    position: relative; 
    box-shadow: 0 0 15px #00ffcc55; 
}
.slot p { 
    margin: 0; 
    font-size: 0.9em; 
}

/* ==================== BOTÕES PADRÃO ==================== */
button.btn { 
    background: #00ffcc; 
    color: #000; 
    border: none; 
    border-radius: 8px; 
    padding: 8px 10px; 
    cursor: pointer; 
    font-weight: bold; 
    margin-top: 10px; 
    transition: 0.3s;
}
button.btn:hover { 
    background: #00ffaa; 
}

/* ==================== SELECT ==================== */
select { 
    margin-top: 5px; 
    background: #111; 
    color: #fff; 
    border: 1px solid #00ffcc; 
    padding: 4px; 
}

/* ==================== LINK ESTILO BOTÃO ==================== */
a.btn-historico { 
    display: inline-block; 
    margin: 10px 0; 
    background: #00ffcc; 
    color: #000; 
    padding: 10px 20px; 
    border-radius: 8px; 
    text-decoration: none; 
    font-weight: bold; 
    transition: 0.3s;
}
a.btn-historico:hover { 
    background: #00ffaa; 
}

/* ==================== TABELA ==================== */
table { 
    margin: 10px auto; 
    border-collapse: collapse; 
    width: 80%; 
}
th, td { 
    border: 1px solid #00ffcc; 
    padding: 8px; 
}
th { 
    background: #00ffcc; 
    color: #000; 
}
tr:nth-child(even) { 
    background: #111; 
}

/* ==================== TOP BAR FUTURISTA ==================== */
.top-bar {
    display: flex;
    justify-content: center;
    gap: 10px;
    padding: 20px;
    background: #111;
    border-bottom: 2px solid #0ff;
}

/* ==================== BOTÕES TOP BAR ==================== */
.top-bar .btn { 
    text-decoration: none;
    color: #0ff;
    background: linear-gradient(145deg, #0ff, #08f);
    padding: 12px 20px;
    border-radius: 12px;
    font-weight: bold;
    text-align: center;
    transition: all 0.3s ease;
    box-shadow: 0 0 10px #0ff, 0 0 20px #08f;
    position: relative;
}
.top-bar .btn:hover {
    color: #fff;
    box-shadow: 0 0 20px #0ff, 0 0 40px #08f, 0 0 60px #0ff;
    transform: translateY(-3px);
}
.top-bar .btn::after {
    content: '';
    position: absolute;
    top: -2px;
    left: -2px;
    width: calc(100% + 4px);
    height: calc(100% + 4px);
    border-radius: 14px;
    background: linear-gradient(45deg, #0ff, #08f, #0ff, #08f);
    z-index: -1;
    filter: blur(10px);
    opacity: 0;
    transition: opacity 0.3s ease;
}
.top-bar .btn:hover::after {
    opacity: 1;
}
</style>

</head>
<body>
    <nav class="top-bar">
        <a href="logout.php">🚪 Sair</a>
        <a href="personagens.php">👤 Personagens</a>
        <a href="bank.php">🏦 Banco 💰</a>
        <a href="start_dungeon.php">🗡️ Masmorra</a>
        <a href="inventario.php">🎒 Inventário</a>
        <a href="saude.php">🩺 Saúde</a>
        <a href="mercado.php">🛒 Mercado</a>
        <a href="bolsa.php">📈 Bolsa</a>
        <a href="fazenda.php">🌱 Fazenda</a>
    </nav>
<h1>🏡 Fazenda RPG - MoedaMumu</h1>

<!-- Botão Histórico -->
<a href="historico_fazenda.php" class="btn-historico">📜 Histórico</a>


<h2>💰 Saldo da Poupança: 💎 <?= $poupanca ?> </h2>
<h2>💰 🛒 Comprar Semente 🌱</h2>
<select id="compraSemente">
    <option value="">-- Escolha --</option>
    <?php
    $todasFrutas = safeQuery($conn, "SELECT FrutaID, Nome, PrecoSemente FROM dbo.Frutas");
    foreach($todasFrutas as $f){
        echo "<option value='{$f['FrutaID']}'>{$f['Nome']} (💰 {$f['PrecoSemente']})</option>";
    }
    ?>
</select>
<button class="btn" onclick="comprarSemente()">Comprar</button>

<h2>🌱 Inventário de Sementes</h2>
<table id="tabelaSementes">
    <tr><th>Nome</th><th>Quantidade</th><th>Plantar</th></tr>
    <?php foreach($sementes as $s): ?>
    <tr>
        <td><?= htmlspecialchars($s['Nome']) ?></td>
        <td><?= $s['Quantidade'] ?></td>
        <td>—</td>
    </tr>
    <?php endforeach; ?>
</table>

<h2>🍎 Inventário de Frutas</h2>
<table id="tabelaFrutas">
    <tr><th>Nome</th><th>Quantidade</th></tr>
    <?php foreach($frutas as $f): ?>
    <tr>
        <td><?= htmlspecialchars($f['Nome']) ?></td>
        <td><?= $f['Quantidade'] ?></td>
    </tr>
    <?php endforeach; ?>
</table>

<button onclick="colherFrutas()">🌾 Colher Frutas Maduras</button>

<div class="log" id="log"></div>

<h1>🌱 Sua Fazenda</h1>
<div class="container">
<?php for($i=1;$i<=6;$i++):
    $slot = array_filter($slots, fn($s) => $s['SlotID'] == $i);
    $slot = reset($slot);
?>
<div class="slot" id="slot<?= $i ?>">
<?php if(!$slot || !$slot['FrutaID']): ?>
    <p>Vazio 🌿</p>
    <select id="sem<?= $i ?>">
        <option value="">-- Escolha --</option>
        <?php foreach($sementes as $s): ?>
            <option value="<?= $s['FrutaID'] ?>"><?= htmlspecialchars($s['Nome']) ?> (x<?= $s['Quantidade'] ?>)</option>
        <?php endforeach; ?>
    </select><br>
    <button class="btn" onclick="plantar(<?= $i ?>)">Plantar</button>
<?php else:
    $plantio = $slot['DataPlantio'] instanceof DateTime ? $slot['DataPlantio'] : new DateTime($slot['DataPlantio']);
    $tempo = $slot['TempoCrescimento'];
    $colheita = (clone $plantio)->modify("+$tempo minutes");
?>
    <p>🌾 <?= htmlspecialchars($slot['Fruta']) ?></p>
    <p id="tempoRestante<?= $i ?>"></p>
    <button class="btn" id="btnColher<?= $i ?>" onclick="colher(<?= $i ?>)" style="display:none;">Colher</button>
    <script>
    window["colheita<?= $i ?>"] = <?= $colheita->getTimestamp() ?>;
    </script>
<?php endif; ?>
</div>
<?php endfor; ?>
</div>

<script>
function atualizarTempo(){
    for(let i=1;i<=6;i++){
        const elem = document.getElementById("tempoRestante"+i);
        const btn = document.getElementById("btnColher"+i);
        if(!elem || !window["colheita"+i]) continue;
        const agora = Math.floor(Date.now()/1000);
        let restante = window["colheita"+i] - agora;
        if(restante <= 0){
            elem.textContent = "🌾 Frutas Maduras Pronta para colher!";
            btn.style.display = "inline-block";
        } else {
            let h = Math.floor(restante/3600);
            let m = Math.floor((restante%3600)/60);
            let s = restante%60;
            elem.textContent = `⏳ ${h}h ${m}m ${s}s`;
            btn.style.display = "none";
        }
    }
}
setInterval(atualizarTempo,1000);
window.onload = atualizarTempo;

function comprarSemente(){
    const frutaID = document.getElementById('compraSemente').value;
    if(!frutaID){ alert("Escolha uma semente!"); return; }
    fetch('comprar_semente.php', { method:'POST', body: new URLSearchParams({ frutaID }) })
    .then(res => res.json())
    .then(data => { alert(data.message); if(data.success) location.reload(); });
}

function plantar(slotID){
    const frutaID = document.getElementById('sem'+slotID).value;
    if(!frutaID){ alert("Escolha uma semente!"); return; }
    fetch('plantar.php', { method:'POST', body: new URLSearchParams({ slotID, frutaID }) })
    .then(res => res.json())
    .then(data => { alert(data.message); if(data.success) location.reload(); });
}

function colher(slotID){
    fetch('colher.php', { method:'POST', body: new URLSearchParams({ slotID }) })
    .then(res => res.json())
    .then(data => { alert(data.message); if(data.success) location.reload(); });
}

function colherFrutas(){
    fetch('colherFrutas.php', { method:'POST' })
    .then(res => res.json())
    .then(data => { alert(data.message); if(data.success) location.reload(); });
}
</script>
</body>
</html>
