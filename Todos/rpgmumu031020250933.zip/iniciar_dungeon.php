<?php
session_start();
include "db.php";
include "check_ban.php"; // Verifica se jogador está banido

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// Inicializa loot se ainda não existir
if(!isset($_SESSION['loot'])) $_SESSION['loot'] = [];

// Limpa dungeon antiga
$_SESSION['dungeon'] = [
    'enemies'=>[],
    'current'=>0,
    'fim'=>false
];

// Pega inimigos do banco
$sqlEnemies = sqlsrv_query($conn, "SELECT * FROM Enemies");
while($enemy = sqlsrv_fetch_array($sqlEnemies, SQLSRV_FETCH_ASSOC)){
    // Pega loot do inimigo
    $loot = [];
    $sqlLoot = sqlsrv_query($conn, "SELECT * FROM EnemyLoot WHERE EnemyID=?", [$enemy['EnemyID']]);
    while($item = sqlsrv_fetch_array($sqlLoot, SQLSRV_FETCH_ASSOC)){
        $loot[] = [
            'ItemName'=>$item['ItemName'],
            'Rarity'=>$item['Rarity'],
            'ChanceFinal'=>$item['ChanceFinal']
        ];
    }

    // Adiciona inimigo à dungeon
    $_SESSION['dungeon']['enemies'][] = [
        'EnemyID'=>$enemy['EnemyID'],
        'Name'=>$enemy['Name'],
        'HP'=>$enemy['HP'],
        'MaxHP'=>$enemy['MaxHP'],
        'Loot'=>$loot
    ];
}

echo "Dungeon inicializada com sucesso! Você tem ".count($_SESSION['dungeon']['enemies'])." inimigos.";
?>
