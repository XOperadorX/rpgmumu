<?php
session_start();
include "db.php";

// ===== Verifica login e admin =====
if (!isset($_SESSION['PlayerID'])) {
    header("Location: login.php");
    exit;
}

$adminID = $_SESSION['PlayerID'];
$stmt = sqlsrv_query($conn, "SELECT Username, Role FROM Players WHERE PlayerID = ?", [$adminID]);
$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

if (!$row || $row['Role'] !== 'admin') {
    die("⛔ Acesso negado. Apenas administradores podem acessar.");
}

$adminName = $row['Username'];

// ===== Bloquear/Desbloquear jogador =====
if (isset($_POST['toggle_block'])) {
    $playerID = intval($_POST['playerID']);
    
    $stmtCheck = sqlsrv_query($conn, "SELECT IsBanned FROM Players WHERE PlayerID = ?", [$playerID]);
    $player = sqlsrv_fetch_array($stmtCheck, SQLSRV_FETCH_ASSOC);

    if ($player) {
        $newStatus = $player['IsBanned'] ? 0 : 1;
        sqlsrv_query($conn, "UPDATE Players SET IsBanned = ? WHERE PlayerID = ?", [$newStatus, $playerID]);
    }
}

// ===== Busca todos jogadores =====
$sqlPlayers = "SELECT PlayerID, Username, Email, MoedaMumu, LastLoginTime, IsBanned FROM Players ORDER BY PlayerID ASC";
$stmtPlayers = sqlsrv_query($conn, $sqlPlayers);

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gerenciar Jogadores - Admin</title>
<style>
body { background:#1c1c1c; color:#fff; font-family:Arial, sans-serif; margin:0; }
header { background:#cc0000; padding:20px; text-align:center; }
header h1 { margin:0; font-size:26px; }
nav { background:#222; padding:15px; text-align:center; }
nav a { margin:5px; padding:10px 15px; border-radius:5px; background:#444; color:#fff; text-decoration:none; font-weight:bold; display:inline-block; transition:0.3s; }
nav a:hover { background:#666; }
main { padding:20px; overflow-x:auto; }
table { width:100%; border-collapse:collapse; margin-top:20px; }
th, td { padding:10px; border:1px solid #444; text-align:center; }
th { background:#cc0000; }
tr:nth-child(even){background:#2a2a2a;}
.status-ok { color:#00ff00; font-weight:bold; }
.status-block { color:#ff3333; font-weight:bold; }
button { padding:5px 10px; border:none; border-radius:5px; cursor:pointer; font-weight:bold; }
.btn-toggle { background:#ffaa00; color:#000; }
.btn-toggle:hover { background:#ffcc33; }
@media(max-width:600px){th, td{font-size:12px; padding:5px;} nav a{padding:6px 10px;}}
</style>
</head>
<body>
<header>
<h1>👥 Gerenciar Jogadores</h1>
<p>Admin: <?= htmlspecialchars($adminName) ?></p>
</header>

<nav>
  <a href="../admin_dashboard.php">⬅ Voltar</a>
  <a href="../logout.php">🚪 Sair</a>
</nav>

<main>
<h2>Lista de Jogadores</h2>
<table>
<tr>
<th>ID</th>
<th>Usuário</th>
<th>Email</th>
<th>MoedaMumu</th>
<th>Último Login</th>
<th>Status</th>
<th>Ações</th>
</tr>
<?php if ($stmtPlayers): ?>
    <?php while($player = sqlsrv_fetch_array($stmtPlayers, SQLSRV_FETCH_ASSOC)): ?>
        <tr>
            <td><?= $player['PlayerID'] ?></td>
            <td><?= htmlspecialchars($player['Username']) ?></td>
            <td><?= htmlspecialchars($player['Email']) ?></td>
            <td><?= number_format($player['MoedaMumu'],2,'.',',') ?></td>
            <td>
                <?php 
                if ($player['LastLoginTime'] instanceof DateTime) {
                    echo $player['LastLoginTime']->format("d/m/Y H:i:s");
                } else {
                    echo "—";
                }
                ?>
            </td>
            <td>
                <?php if ($player['IsBanned']): ?>
                    <span class="status-block">🚫 Bloqueado</span>
                <?php else: ?>
                    <span class="status-ok">✅ Ativo</span>
                <?php endif; ?>
            </td>
            <td>
                <form method="post" style="display:inline;">
                    <input type="hidden" name="playerID" value="<?= $player['PlayerID'] ?>">
                    <button type="submit" name="toggle_block" class="btn-toggle">
                        <?= $player['IsBanned'] ? "🔓 Desbloquear" : "🔒 Bloquear" ?>
                    </button>
                </form>
            </td>
        </tr>
    <?php endwhile; ?>
<?php else: ?>
    <tr><td colspan="7">❌ Nenhum jogador encontrado.</td></tr>
<?php endif; ?>
</table>
</main>
</body>
</html>
