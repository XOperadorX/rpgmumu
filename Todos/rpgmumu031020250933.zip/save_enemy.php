<?php
session_start();
include "db.php";
include "check_ban.php";

if(isset($_POST['EnemyID'])){
    $sql = "UPDATE Enemies SET Name=?, Level=?, XP=?, HP=?, MaxHP=?, Mana=?, MaxMana=? WHERE EnemyID=?";
    sqlsrv_query($conn, $sql, [
        $_POST['Name'], $_POST['Level'], $_POST['XP'], 
        $_POST['HP'], $_POST['MaxHP'], $_POST['Mana'], $_POST['MaxMana'],
        $_POST['EnemyID']
    ]);
}
header("Location: enemies.php");
exit;
