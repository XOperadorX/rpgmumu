<?php
session_start();
include "db.php";
include "check_ban.php";

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado.");
}

$playerID = $_SESSION['PlayerID'];
$moedaMumu = floatval($_POST['corrente'] ?? 0); // saldo em MoedaMumu

// Atualiza apenas o saldo corrente (MoedaMumu) no banco
$sql = "UPDATE [MumuDB].[dbo].[BankAccounts] SET Corrente = ? WHERE PlayerID = ?";
$params = [$moedaMumu, $playerID];
$stmt = sqlsrv_query($conn, $sql, $params);

if($stmt === false){
    die(print_r(sqlsrv_errors(), true));
}

echo "ok";
