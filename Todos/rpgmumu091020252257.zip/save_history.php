<?php
session_start();
include "db.php";
include "check_ban.php";

if(!isset($_SESSION['PlayerID'])) die("Acesso negado");

$playerID = $_SESSION['PlayerID'];
$acao = $_POST['acao'] ?? '';

$sql = "INSERT INTO [MumuDB].[dbo].[TradeHistory] (PlayerID, Acao, Hora) VALUES (?, ?, GETDATE())";
$params = [$playerID, $acao];
$stmt = sqlsrv_query($conn, $sql, $params);
if($stmt === false) die(print_r(sqlsrv_errors(), true));

echo "ok";
