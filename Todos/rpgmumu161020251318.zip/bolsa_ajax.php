<?php
session_start();
include "db.php";

header('Content-Type: application/json');

if (!isset($_SESSION['PlayerID'])) {
    echo json_encode(['error'=>'Acesso negado']);
    exit;
}

$playerID = $_SESSION['PlayerID'];

// Pega os dados do jogador
$stmtPlayer = sqlsrv_query($conn, "SELECT MoedaMumu, CarteiraJSON FROM Players WHERE PlayerID=?", [$playerID]);
$player = sqlsrv_fetch_array($stmtPlayer, SQLSRV_FETCH_ASSOC);

$saldo = $player['MoedaMumu'] ?? 500;
$carteira = !empty($player['CarteiraJSON']) ? json_decode($player['CarteiraJSON'], true) : [
    'Ouro'=>0,'Prata'=>0,'Bronze'=>0,'Cristal'=>0,'Esmeralda'=>0
];

// Ativos iniciais (preço base)
$ativosBase = [
    'Ouro'=>50,'Prata'=>30,'Bronze'=>10,'Cristal'=>100,'Esmeralda'=>150
];

// Simular pequenas flutuações de preço
$ativos = [];
foreach($ativosBase as $nome => $preco){
    $variacao = rand(-5,5); // variação aleatória
    $novoPreco = max(1, $preco + $variacao);
    $ativos[$nome] = ['preco'=>$novoPreco, 'variacao'=>$variacao];
}

// Se veio ação do front-end
$acao = $_POST['acao'] ?? null;
$ativo = $_POST['ativo'] ?? null;
$quantidade = intval($_POST['quantidade'] ?? 0);
$msg = '';

if($acao && $ativo && $quantidade>0 && isset($ativos[$ativo])){
    $precoAtual = $ativos[$ativo]['preco'];
    $total = $precoAtual * $quantidade;

    if($acao=='comprar'){
        if($saldo >= $total){
            $saldo -= $total;
            $carteira[$ativo] = ($carteira[$ativo] ?? 0) + $quantidade;
            $msg = "Comprou $quantidade $ativo!";
        } else {
            echo json_encode(['error'=>'Saldo insuficiente']);
            exit;
        }
    } elseif($acao=='vender'){
        if(($carteira[$ativo] ?? 0) >= $quantidade){
            $saldo += $total;
            $carteira[$ativo] -= $quantidade;
            $msg = "Vendeu $quantidade $ativo!";
        } else {
            echo json_encode(['error'=>'Não possui quantidade suficiente']);
            exit;
        }
    }

    // Atualiza saldo e carteira no banco
    sqlsrv_query($conn, "UPDATE Players SET MoedaMumu=?, CarteiraJSON=? WHERE PlayerID=?", [$saldo, json_encode($carteira), $playerID]);

    // Salvar no histórico
    $sqlHist = "INSERT INTO Historico (PlayerID, Acao, Item, MoedaChange, CreatedAt) VALUES (?, ?, ?, ?, GETDATE())";
    sqlsrv_query($conn, $sqlHist, [$playerID, $acao, $ativo, $quantidade]);
}

// Preparar retorno
$retorno = [
    'novo_saldo' => $saldo,
    'ativos' => [],
];

foreach($ativos as $nome => $data){
    $retorno['ativos'][$nome] = [
        'preco' => $data['preco'],
        'qtd' => $carteira[$nome] ?? 0,
        'variacao' => $data['variacao']
    ];
}

// Se houve ação específica, retornar dados dela
if($acao && $ativo){
    $retorno = array_merge($retorno, [
        'nova_qtd' => $carteira[$ativo],
        'novo_preco' => $ativos[$ativo]['preco'],
        'variacao' => $ativos[$ativo]['variacao'],
        'msg' => $msg
    ]);
}

echo json_encode($retorno);
