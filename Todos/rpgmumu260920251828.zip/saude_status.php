<?php
session_start();
include "db.php";

header('Content-Type: application/json');

if (!isset($_SESSION['PlayerID'])) {
    echo json_encode(['error'=>'Não logado']);
    exit;
}

$playerID = $_SESSION['PlayerID'];

// Pega dados do jogador
$sql = "SELECT Username, MoedaMumu, CreatedAt FROM Players WHERE PlayerID=?";
$stmt = sqlsrv_query($conn, $sql, [$playerID]);
$dados = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

if(!$dados){
    echo json_encode(['error'=>'Jogador não encontrado']);
    exit;
}

// Calcula saúde
$health = 0;
$loggedDays = [];
$now = new DateTime();

// Últimos 10 logins
$sqlLogins = "SELECT TOP 10 LoginTime, LoginIP FROM LoginHistory WHERE PlayerID=? ORDER BY LoginTime DESC";
$stmtLogins = sqlsrv_query($conn, $sqlLogins, [$playerID]);
$logins = [];
if ($stmtLogins !== false) {
    while ($row = sqlsrv_fetch_array($stmtLogins, SQLSRV_FETCH_ASSOC)) {
        $logins[] = [
            'LoginTime'=>!empty($row['LoginTime']) ? date('d/m/Y H:i', strtotime($row['LoginTime'])) : '-',
            'LoginIP'=>$row['LoginIP'] ?? '-'
        ];
        if (!empty($row['LoginTime'])) {
            $day = date('Y-m-d', strtotime($row['LoginTime']));
            if(!in_array($day,$loggedDays)) $loggedDays[]=$day;
        }
    }
}

// Últimos 7 dias
for($i=0;$i<7;$i++){
    $checkDay = (clone $now)->modify("-$i days")->format('Y-m-d');
    $health += in_array($checkDay,$loggedDays)?10:-10;
}
$health = min(max($health,0),100);

// Verifica exclusão automática
$createdAt = $dados['CreatedAt'] instanceof DateTime ? $dados['CreatedAt'] : new DateTime($dados['CreatedAt']);
$daysSinceCreation = (new DateTime())->diff($createdAt)->days;
$deleteAccount = false;

if($health <= 10 && $daysSinceCreation >= 7){
    // Deleta conta e histórico
    sqlsrv_query($conn, "DELETE FROM Players WHERE PlayerID=?", [$playerID]);
    sqlsrv_query($conn, "DELETE FROM LoginHistory WHERE PlayerID=?", [$playerID]);
    sqlsrv_query($conn, "DELETE FROM AccountHistory WHERE PlayerID=?", [$playerID]);
    session_destroy();
    $deleteAccount = true;
}

echo json_encode([
    'username'=>$dados['Username'] ?? 'Desconhecido',
    'moeda'=>(int)($dados['MoedaMumu'] ?? 0),
    'health'=>$health,
    'logins'=>$logins,
    'delete'=>$deleteAccount
]);
