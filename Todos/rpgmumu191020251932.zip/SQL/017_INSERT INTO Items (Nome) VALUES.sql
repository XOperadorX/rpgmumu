INSERT INTO Itens (Nome) VALUES
('Espada de Ferro'),
('Escudo de Madeira'),
('Po��o de Vida'),
('Po��o de Mana');
