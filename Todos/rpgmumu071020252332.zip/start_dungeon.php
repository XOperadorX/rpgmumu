<?php
session_start();
include "db.php";
include "check_ban.php"; // protege a página


if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login. <a href='login.php'>⬅️ Voltar</a>");
}

$playerID = $_SESSION['PlayerID'];

// Pega personagem do jogador
$stmt = sqlsrv_query($conn, "SELECT TOP 1 * FROM Characters WHERE PlayerID=?", [$playerID]);
$char = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

if(!$char){
    die("Você precisa ter pelo menos um personagem. <a href='dashboard.php'>⬅️ Voltar</a>");
}

// Inicializa dungeon na sessão
$_SESSION['dungeon'] = [
    'playerID' => $playerID,
    'char' => [
        'CharID' => $char['CharID'],
        'Name'   => $char['Name'],
        'HP'     => $char['HP'],
        'MaxHP'  => $char['MaxHP'],
        'Mana'   => $char['Mana'],
        'MaxMana'=> $char['MaxMana'],
        'Level'  => $char['Level'],
        'Exp'    => $char['Exp']
    ],
    'enemies' => [
        ['Name'=>'Goblin','Level'=>1,'XP'=>10,'HP'=>30,'MaxHP'=>30,'Mana'=>10,'MaxMana'=>10,'Loot'=>['Potion','Herb']],
        ['Name'=>'Orc','Level'=>2,'XP'=>20,'HP'=>50,'MaxHP'=>50,'Mana'=>20,'MaxMana'=>20,'Loot'=>['Gold','Shield']],
        ['Name'=>'Dragão','Level'=>5,'XP'=>50,'HP'=>100,'MaxHP'=>100,'Mana'=>50,'MaxMana'=>50,'Loot'=>['Sword','Dragon Scale']]
    ],
    'current'=>0,
    'log'=>[],
    'loot'=>[],
    'fim'=>false
];

// Redireciona para dungeon
header("Location: dung.php");
exit;
