<nav>
<a href="admin_dashboard.php">⬅ Voltar ao Painel</a>
<a href="logout.php">🚪 Sair</a>
</nav>

<?php
session_start();
include "../db.php"; // Ajuste o caminho conforme necessário

// Verifica login e role
if (!isset($_SESSION['PlayerID'])) die("⛔ Faça login.");
$stmt = sqlsrv_query($conn, "SELECT Role FROM Players WHERE PlayerID = ?", [$_SESSION['PlayerID']]);
$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
if ($row['Role'] !== 'admin') die("⛔ Acesso negado. Apenas admins.");

// Atualização via AJAX
if(isset($_POST['action']) && $_POST['action'] === 'update'){
    $sql = "UPDATE Characters SET 
                Name=?, Class=?, Level=?, Exp=?, 
                HP=?, MaxHP=?, Mana=?, MaxMana=?, 
                Power=?, MaxPower=?
            WHERE CharID=?";
    $params = [
        $_POST['Name'], $_POST['Class'], $_POST['Level'], $_POST['Exp'],
        $_POST['HP'], $_POST['MaxHP'], $_POST['Mana'], $_POST['MaxMana'],
        $_POST['Power'], $_POST['MaxPower'], $_POST['CharID']
    ];
    sqlsrv_query($conn, $sql, $params);
    echo "success";
    exit;
}

// Carregar lista de personagens
function renderCharacters($conn){
    $sql = "SELECT * FROM Characters";
    $result = sqlsrv_query($conn, $sql);

    while($char = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)){
        $hpPercent   = ($char['MaxHP']   > 0) ? ($char['HP']   / $char['MaxHP'])   * 100 : 0;
        $manaPercent = ($char['MaxMana'] > 0) ? ($char['Mana'] / $char['MaxMana']) * 100 : 0;
        $powPercent  = ($char['MaxPower']> 0) ? ($char['Power']/ $char['MaxPower'])* 100 : 0;

        echo "<div class='char-card' data-id='{$char['CharID']}'>
                <form class='char-form'>
                    <input type='hidden' name='CharID' value='{$char['CharID']}'>
                    Nome: <input type='text' name='Name' value='{$char['Name']}'>
                    Classe: <input type='text' name='Class' value='{$char['Class']}'>
                    Level: <input type='number' name='Level' value='{$char['Level']}'>
                    Exp: <input type='number' name='Exp' value='{$char['Exp']}'>
                    HP: <input type='number' name='HP' value='{$char['HP']}'>
                    MaxHP: <input type='number' name='MaxHP' value='{$char['MaxHP']}'>
                    Mana: <input type='number' name='Mana' value='{$char['Mana']}'>
                    MaxMana: <input type='number' name='MaxMana' value='{$char['MaxMana']}'>
                    Power: <input type='number' name='Power' value='{$char['Power']}'>
                    MaxPower: <input type='number' name='MaxPower' value='{$char['MaxPower']}'>
                    
                    <div class='bar'><div class='hp-bar' style='width:{$hpPercent}%;'>HP: {$char['HP']}/{$char['MaxHP']}</div></div>
                    <div class='bar'><div class='mana-bar' style='width:{$manaPercent}%;'>Mana: {$char['Mana']}/{$char['MaxMana']}</div></div>
                    <div class='bar'><div class='power-bar' style='width:{$powPercent}%;'>Power: {$char['Power']}/{$char['MaxPower']}</div></div>

                    <button type='submit'>Atualizar</button>
                </form>
              </div>";
    }
}
?>

<div id="characters-list">
    <?php renderCharacters($conn); ?>
</div>

<script>
window.addEventListener('DOMContentLoaded', () => {
    attachForms();

    function attachForms(){
        document.querySelectorAll('.char-form').forEach(form => {
            form.addEventListener('submit', e => {
                e.preventDefault();
                let data = new FormData(form);
                data.append('action','update');
                fetch('admin_Characters_Edit.php',{method:'POST',body:data})
                    .then(res=>res.text())
                    .then(resp=>{
                        if(resp==='success'){
                            // Recarrega a lista de personagens
                            fetch('admin_Characters_Edit.php')
                                .then(res=>res.text())
                                .then(html=>{
                                    let parser = new DOMParser();
                                    let doc = parser.parseFromString(html,'text/html');
                                    document.getElementById('characters-list').innerHTML =
                                        doc.getElementById('characters-list').innerHTML;
                                    attachForms();
                                });
                        }
                    });
            });
        });
    }
});
</script>

<style>
body { font-family: Arial,sans-serif; background:#f4f6f7; margin:0; padding:0; }
.container { max-width:1200px; margin:auto; padding:20px; }
.char-card { background:#fff; padding:15px; margin-bottom:15px; border-radius:10px; box-shadow:0 2px 5px rgba(0,0,0,0.1);}
.char-card form input { margin:5px; padding:5px; }
.bar { background:#ddd; border-radius:5px; margin:5px 0; height:20px; overflow:hidden;}
.hp-bar { background:red; height:100%; text-align:center; color:#fff; transition: width 0.5s;}
.mana-bar { background:blue; height:100%; text-align:center; color:#fff; transition: width 0.5s;}
.power-bar { background:gold; height:100%; text-align:center; color:#000; transition: width 0.5s;}
button { padding:5px 10px; cursor:pointer; border:none; border-radius:5px; background:#2ecc71; color:#fff;}
@media(max-width:768px){
    .char-card form input { width:100%; display:block; }
    .bar { font-size:12px; }
}
</style>
