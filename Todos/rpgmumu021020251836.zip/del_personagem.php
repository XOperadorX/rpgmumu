<?php
session_start();
include "db.php";
include "check_ban.php"; // protege a página


if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];
$mensagem = "";

if(isset($_GET['CharID'])){
    $charID = intval($_GET['CharID']);

    // Começa transação
    sqlsrv_begin_transaction($conn);

    try {
        // Deleta itens do personagem
        $deleteItems = sqlsrv_query($conn, "DELETE FROM Items WHERE CharID=?", [$charID]);
        if($deleteItems === false) throw new Exception("Erro ao excluir os itens: " . print_r(sqlsrv_errors(), true));

        // Deleta histórico do personagem
        $deleteHistorico = sqlsrv_query($conn, "DELETE FROM Historico WHERE CharID=?", [$charID]);
        if($deleteHistorico === false) throw new Exception("Erro ao excluir histórico: " . print_r(sqlsrv_errors(), true));

        // Deleta personagem
        $deleteChar = sqlsrv_query($conn, "DELETE FROM Characters WHERE CharID=? AND PlayerID=?", [$charID, $playerID]);
        if($deleteChar === false) throw new Exception("Erro ao excluir personagem: " . print_r(sqlsrv_errors(), true));

        sqlsrv_commit($conn);
        $mensagem = "✅ Personagem, itens e histórico excluídos com sucesso!";
    } catch(Exception $e){
        sqlsrv_rollback($conn);
        $mensagem = "❌ Falha ao excluir personagem: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Excluir Personagem</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<nav style="display:flex; justify-content:space-between; align-items:center; margin:20px;">
    <form method="post" style="margin:0; display:flex; gap:10px;">
        <button type="submit" class="btn" name="refresh">🔄 Atualizar</button>
        <a href="dashboard.php" class="btn">⬅️ Voltar</a>
    </form>
</nav>
<h2>🗑️ Excluir Personagem</h2>
<?php
$sql = "SELECT * FROM Characters WHERE PlayerID=?";
$stmt = sqlsrv_query($conn, $sql, [$playerID]);

if($stmt && sqlsrv_has_rows($stmt)){
    while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)){
        echo "<p>{$row['Name']} | {$row['Class']} | <a href='del_personagem.php?CharID={$row['CharID']}' onclick=\"return confirm('Tem certeza que deseja excluir este personagem e todos os itens e histórico?');\">Excluir</a></p>";
    }
} else {
    echo "<p>Nenhum personagem encontrado.</p>";
}
?>
<p><?= $mensagem ?></p>
</body>
</html>
