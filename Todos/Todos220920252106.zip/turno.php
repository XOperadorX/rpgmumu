<?php
session_start();
include "db.php"; // conexão com o banco

header('Content-Type: application/json');

if(!isset($_SESSION['dungeon'])){
    echo json_encode(['erro'=>'Dungeon não iniciada']);
    exit;
}



// referência para sessão
$d = &$_SESSION['dungeon'];
$char = &$d['char'];
$currentIndex = $d['current'];
$enemies = &$d['enemies'];
$log = &$d['log'];


// Supondo $charID e $novoHP já definidos
//$sql = "UPDATE Characters SET Life = ? WHERE CharID = ?";
//$stmt = sqlsrv_query($conn, $sql, [$novoHP, $charID]);




// se não tiver inimigos ou personagem morto, finaliza
if($currentIndex >= count($enemies) || $char['HP'] <= 0){
    echo json_encode([
        'char'=>$char,
        'enemy'=>['Name'=>'','HP'=>0,'MaxHP'=>0],
        'log'=>$log,
        'fim'=>true
    ]);
    exit;
}

$enemy = &$enemies[$currentIndex];

// hora para logs
$hora = date('H:i:s');

// Turno jogador ataca
$danoJogador = rand(5,15);
$enemy['HP'] -= $danoJogador;
$enemy['HP'] = max(0, $enemy['HP']);
$log[] = "<span style='color:lightgreen;'>[$hora] {$char['Name']} atacou {$enemy['Name']} causando {$danoJogador} de dano!</span>";

// se inimigo derrotado
if($enemy['HP'] <= 0){
    $log[] = "<span style='color:yellow;'>[$hora] {$enemy['Name']} foi derrotado! {$char['Name']} ganhou {$enemy['XP']} XP e loot: {$enemy['Loot']}</span>";
    $char['Exp'] += $enemy['XP'];

    // atualizar level simples
    while($char['Exp'] >= 100){
        $char['Exp'] -= 100;
        $char['Level']++;
    }

    // atualizar inventário no banco
    if(!empty($enemy['Loot'])){
        $sql = "INSERT INTO Items (CharID, Name) VALUES (?, ?)";
        sqlsrv_query($conn, $sql, [$char['CharID'], $enemy['Loot']]);
    }

    $d['current']++; // passa para próximo inimigo
} else {
    // turno inimigo ataca
    $danoInimigo = rand(3,12);
    $char['HP'] -= $danoInimigo;
    $char['HP'] = max(0,$char['HP']);
    $log[] = "<span style='color:red;'>[$hora] {$enemy['Name']} atacou {$char['Name']} causando {$danoInimigo} de dano!</span>";
}

// verifica se finalizou
$fim = false;
if($char['HP'] <= 0 || $d['current'] >= count($enemies)){
    $fim = true;
}

// retorna JSON
echo json_encode([
    'char' => [
        'HP'=>$char['HP'],
        'MaxHP'=>$char['MaxHP'],
        'Level'=>$char['Level'],
        'Exp'=>$char['Exp']
    ],
    'enemy' => [
        'Name'=>$enemy['Name'],
        'HP'=>$enemy['HP'],
        'MaxHP'=>$enemy['MaxHP']
    ],
    'log' => $log,
    'fim' => $fim
]);


