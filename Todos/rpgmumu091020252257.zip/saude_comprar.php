<?php
session_start();
include "db.php";
include "check_ban.php"; // protege a página

header('Content-Type: application/json');

if(!isset($_SESSION['PlayerID'])){
    echo json_encode(['error'=>'Não logado']);
    exit;
}

$playerID = $_SESSION['PlayerID'];
$days = isset($_POST['days']) ? (int)$_POST['days'] : 1;
$costPerDay = 2000; // exemplo: 10 MoedaMumu por dia
$totalCost = $days * $costPerDay;

// Pega saldo atual
$sql = "SELECT MoedaMumu, LastLoginTime FROM Players WHERE PlayerID=?";
$stmt = sqlsrv_query($conn, $sql, [$playerID]);
$player = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

if(!$player){
    echo json_encode(['error'=>'Jogador não encontrado']);
    exit;
}

if($player['MoedaMumu'] < $totalCost){
    echo json_encode(['msg'=>'Saldo insuficiente!']);
    exit;
}

// Subtrai MoedaMumu e adiciona dias ao LastLoginTime
$newMoeda = $player['MoedaMumu'] - $totalCost;
$lastLogin = $player['LastLoginTime'] instanceof DateTime ? $player['LastLoginTime'] : new DateTime($player['LastLoginTime']);
$lastLogin->modify("+$days days");

$sqlUpdate = "UPDATE Players SET MoedaMumu=?, LastLoginTime=? WHERE PlayerID=?";
sqlsrv_query($conn, $sqlUpdate, [$newMoeda, $lastLogin, $playerID]);

echo json_encode(['msg'=>"Você comprou $days dia(s) com sucesso!"]);
