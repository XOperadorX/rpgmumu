<?php
session_start();
include "db.php";
include "check_ban.php";

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado.");
}

$playerID = $_SESSION['PlayerID'];
$investimento = floatval($_POST['investimento'] ?? 0);

$sql = "UPDATE [MumuDB].[dbo].[BankAccounts] SET Investimento = ? WHERE PlayerID = ?";
$params = [$investimento, $playerID];
$stmt = sqlsrv_query($conn, $sql, $params);

if($stmt === false){
    die(print_r(sqlsrv_errors(), true));
}

echo "ok";
