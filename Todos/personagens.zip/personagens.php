<?php
session_start();
include "db.php";
include "check_ban.php"; // protege a página

if (!isset($_SESSION['PlayerID'])) {
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// Busca personagens
$sql = "SELECT TOP 1000 [CharID], [PlayerID], [Name], [Class], [Level], [Exp], [HP], [Mana], [MaxHP], [MaxMana], [Power]
        FROM [MumuDB].[dbo].[Characters]
        WHERE [PlayerID] = ?";
$stmt = sqlsrv_query($conn, $sql, [$playerID]);

// Busca moedas
$moedaRow = sqlsrv_fetch_array(
    sqlsrv_query($conn, "SELECT [MoedaMumu] FROM [MumuDB].[dbo].[Players] WHERE [PlayerID] = ?", [$playerID]),
    SQLSRV_FETCH_ASSOC
);
$moedas = $moedaRow['MoedaMumu'] ?? 0;
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Personagens</title>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
<style>
body {
    background-color: black;
    color: white;
    font-family: 'Roboto', sans-serif;
    margin: 0;
    padding: 20px;
}

h1, h2 {
    text-align: center;
    color: #ffd700;
}

.moedas {
    font-size: 1.2em;
    color: #ff9900;
    font-weight: bold;
    text-align: center;
}

.cards {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px;
    margin-top: 20px;
}

.card {
    background: #1a1a1a;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(255,255,255,0.1);
    padding: 20px;
    width: 280px;
    transition: transform 0.2s;
    color: white;
    text-align: center;
}
.card:hover {
    transform: translateY(-5px);
}
.card h3 {
    margin-top: 0;
    text-align: center;
}

.stats, .inventory {
    margin-top: 10px;
}
.stats div, .inventory div {
    margin: 5px 0;
}

.hp-bar-container, .mana-bar-container, .xp-bar-container, .power-bar-container {
    background: #333;
    border-radius: 10px;
    overflow: hidden;
    height: 20px;
    margin-top: 5px;
    position: relative;
}
.hp-bar, .mana-bar, .xp-bar, .power-bar {
    height: 100%;
    transition: width 0.5s;
}
.hp-bar {
    background: #4caf50;
}
.hp-bar.warn {
    background: #ff9800;
}
.hp-bar.low {
    background: #f44336;
}
.mana-bar {
    background: #3498db;
}
.mana-bar.low {
    background: #2980b9;
}
.xp-bar {
    background: purple;
}
.power-bar {
    background: #ff4500; /* laranja DBZ */
}
.power-bar.low { background: #ff6347; }
.power-bar.medium { background: #ff8c00; }
.power-bar.high { background: #ffd700; }

.stat-text {
    position: absolute;
    width: 100%;
    text-align: center;
    top: 0;
    left: 0;
    font-weight: bold;
    color: #fff;
    font-size: 0.9em;
    line-height: 20px;
}

.btn {
    display: inline-block;
    padding: 10px 20px;
    margin: 10px 5px;
    text-decoration: none;
    color: #fff;
    border-radius: 8px;
    background: #333;
    transition: 0.3s;
}
.btn:hover {
    background: #555;
}
.btn.delete {
    background: #e53935;
}

@media(max-width:768px) {
    .card { width: 45%; }
}
@media(max-width:480px) {
    .card { width: 90%; }
}
</style>
</head>
<body>

<nav style="text-align:left;">
    <a href="dashboard.php" class="btn">⬅ Voltar</a>
</nav>

<h1>👥 Seus Personagens</h1>
<h2>💰 Moedas Mumu: <span class="moedas"><?= $moedas ?></span></h2>

<div class="cards" id="cards-container">
<?php while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)): ?>
    <div class="card">
        <h3><?= htmlspecialchars($row['Name']) ?> (<?= htmlspecialchars($row['Class']) ?>)</h3>
        <div class="stats">
            <div>Level: <span id="level-<?= $row['CharID'] ?>"><?= $row['Level'] ?></span></div>
			
			
            <div>Poder :</div>
            <div class="power-bar-container">
                <div id="power-<?= $row['CharID'] ?>" class="power-bar" style="width:<?= ($row['Power']??0) ?>%"></div>
                <div class="stat-text" id="powertext-<?= $row['CharID'] ?>"><?= $row['Power']??0 ?> / 100</div>
            </div>
        </div>
            <div>HP:</div>
            <div class="hp-bar-container">
                <div id="hp-<?= $row['CharID'] ?>" class="hp-bar" style="width:<?= ($row['MaxHP']>0?round($row['HP']/$row['MaxHP']*100):0) ?>%"></div>
                <div class="stat-text" id="hptext-<?= $row['CharID'] ?>"><?= $row['HP'] ?> / <?= $row['MaxHP'] ?></div>
            </div>

            <div>Mana:</div>
            <div class="mana-bar-container">
                <div id="mana-<?= $row['CharID'] ?>" class="mana-bar" style="width:<?= ($row['MaxMana']>0?round($row['Mana']/$row['MaxMana']*100):0) ?>%"></div>
                <div class="stat-text" id="manatext-<?= $row['CharID'] ?>"><?= $row['Mana'] ?> / <?= $row['MaxMana'] ?></div>
            </div>

            <div>XP:</div>
            <div class="xp-bar-container">
                <div id="xp-<?= $row['CharID'] ?>" class="xp-bar" style="width:<?= ($row['Level']>0 ? min(100, round(($row['Exp']/($row['Level']*50))*100)) : 0) ?>%"></div>
                <div class="stat-text" id="xptext-<?= $row['CharID'] ?>"><?= $row['Exp'] ?> / <?= $row['Level']*50 ?></div>
            </div>



        <div class="inventory">

        </div>
        <a href="del_personagem.php?CharID=<?= $row['CharID'] ?>" class="btn delete">🗑️ Excluir</a>
    </div>
<?php endwhile; ?>
</div>

<script>
// Atualiza HP, Mana, XP, Level e Poder via AJAX
function atualizarStatus() {
    fetch('status_personagem.php')
    .then(res => res.json())
    .then(data => {
        data.forEach(c => {
            // HP
            let hpPerc = Math.max(0, Math.min(100, Math.round(c.HP / c.MaxHP * 100)));
            let hpElem = document.getElementById('hp-' + c.CharID);
            hpElem.style.width = hpPerc + '%';
            hpElem.className = (hpPerc>60?'hp-bar':(hpPerc>30?'hp-bar warn':'hp-bar low'));
            document.getElementById('hptext-' + c.CharID).innerText = c.HP + ' / ' + c.MaxHP;

            // Mana
            let manaPerc = Math.max(0, Math.min(100, Math.round(c.Mana / c.MaxMana * 100)));
            let manaElem = document.getElementById('mana-' + c.CharID);
            manaElem.style.width = manaPerc + '%';
            manaElem.className = (manaPerc>30?'mana-bar':'mana-bar low');
            document.getElementById('manatext-' + c.CharID).innerText = c.Mana + ' / ' + c.MaxMana;

            // XP
            let xpPerc = Math.max(0, Math.min(100, Math.round((c.Exp/(c.Level*50))*100)));
            let xpElem = document.getElementById('xp-' + c.CharID);
            xpElem.style.width = xpPerc + '%';
            document.getElementById('xptext-' + c.CharID).innerText = c.Exp + ' / ' + (c.Level*50);

            // Level
            document.getElementById('level-' + c.CharID).innerText = c.Level;

            // Poder / Ki
            let powerPerc = Math.max(0, Math.min(100, c.Power));
            let powerElem = document.getElementById('power-' + c.CharID);
            powerElem.style.width = powerPerc + '%';
            if(powerPerc>70) powerElem.className='power-bar high';
            else if(powerPerc>30) powerElem.className='power-bar medium';
            else powerElem.className='power-bar low';
            document.getElementById('powertext-' + c.CharID).innerText = c.Power + ' / 100';
        });
    })
    .catch(err => console.error(err));
}
setInterval(atualizarStatus, 1500);
</script>

</body>
</html>
