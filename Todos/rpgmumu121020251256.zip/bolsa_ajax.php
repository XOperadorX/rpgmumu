<?php
session_start();
include "db.php";

header('Content-Type: application/json');

// Verifica login
if (!isset($_SESSION['PlayerID'])) {
    echo json_encode(['error' => 'Acesso negado. Faça login.']);
    exit;
}

$playerID = $_SESSION['PlayerID'];

// ===== Carrega dados do jogador =====
$sql = "SELECT MoedaMumu, CarteiraJSON FROM Players WHERE PlayerID = ?";
$stmt = sqlsrv_query($conn, $sql, [$playerID]);
if ($stmt === false) {
    echo json_encode(['error' => 'Erro ao carregar dados.', 'sql' => sqlsrv_errors()]);
    exit;
}

$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
$saldo = $row['MoedaMumu'] ?? 0;
$carteira = !empty($row['CarteiraJSON']) ? json_decode($row['CarteiraJSON'], true) : [
    'Ouro'=>0,'Prata'=>0,'Bronze'=>0,'Cristal'=>0,'Esmeralda'=>0
];

// ===== Lista de ativos disponíveis =====
$ativos = [
    'Ouro' => 50,
    'Prata' => 30,
    'Bronze' => 10,
    'Cristal' => 100,
    'Esmeralda' => 150,
];

// ===== Verifica ação =====
$acao = $_POST['acao'] ?? '';
$ativo = $_POST['ativo'] ?? '';
$qtd = intval($_POST['quantidade'] ?? 0);

if (!isset($ativos[$ativo])) {
    echo json_encode(['error' => 'Ativo inválido.']);
    exit;
}
if ($qtd <= 0) {
    echo json_encode(['error' => 'Quantidade inválida.']);
    exit;
}

$precoUnitario = $ativos[$ativo];
$total = $precoUnitario * $qtd;

// ===== Compra =====
if ($acao === 'comprar') {
    if ($saldo < $total) {
        echo json_encode(['error' => 'Saldo insuficiente para comprar.']);
        exit;
    }

    // Atualiza carteira e saldo
    $saldo -= $total;
    $carteira[$ativo] = ($carteira[$ativo] ?? 0) + $qtd;

    // ===== Salva no banco =====
    $update = "UPDATE Players SET MoedaMumu = ?, CarteiraJSON = ? WHERE PlayerID = ?";
    $params = [$saldo, json_encode($carteira, JSON_UNESCAPED_UNICODE), $playerID];
    $res = sqlsrv_query($conn, $update, $params);

    if ($res === false) {
        echo json_encode(['error' => 'Erro ao salvar compra.', 'sql' => sqlsrv_errors()]);
        exit;
    }

    echo json_encode([
        'success' => true,
        'msg' => "Você comprou $qtdx $ativo por $total moedas.",
        'novo_saldo' => $saldo,
        'nova_qtd' => $carteira[$ativo],
    ]);
    exit;
}

// ===== Venda =====
if ($acao === 'vender') {
    if (($carteira[$ativo] ?? 0) < $qtd) {
        echo json_encode(['error' => 'Você não possui quantidade suficiente para vender.']);
        exit;
    }

    $carteira[$ativo] -= $qtd;
    $saldo += $total;

    $update = "UPDATE Players SET MoedaMumu = ?, CarteiraJSON = ? WHERE PlayerID = ?";
    $params = [$saldo, json_encode($carteira, JSON_UNESCAPED_UNICODE), $playerID];
    $res = sqlsrv_query($conn, $update, $params);

    if ($res === false) {
        echo json_encode(['error' => 'Erro ao salvar venda.', 'sql' => sqlsrv_errors()]);
        exit;
    }

    echo json_encode([
        'success' => true,
        'msg' => "Você vendeu $qtdx $ativo e recebeu $total moedas.",
        'novo_saldo' => $saldo,
        'nova_qtd' => $carteira[$ativo],
    ]);
    exit;
}

echo json_encode(['error' => 'Ação inválida.']);
