<?php
session_start();
include "db.php";
include "check_ban.php";

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// Atualiza HP, Mana e Power do personagem
$sql = "UPDATE Characters 
        SET HP = MaxHP, 
            Mana = MaxMana,
            Power = MaxPower
        WHERE PlayerID = ?";
$stmt = sqlsrv_query($conn, $sql, [$playerID]);

// Atualiza também na sessão (se os dados são usados na sessão)
if(isset($_SESSION['char'])){
    $_SESSION['char']['HP'] = $_SESSION['char']['MaxHP'];
    $_SESSION['char']['Mana'] = $_SESSION['char']['MaxMana'];
    $_SESSION['char']['Power'] = $_SESSION['char']['MaxPower'];
}

// Redireciona de volta para o dashboard
header("Location: dashboard.php");
exit;
