<?php
session_start();
include "db.php";

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

try {
    // Inicia transação
    sqlsrv_begin_transaction($conn);

    // Pega todos os CharID do jogador
    $charIDs = [];
    $stmtChars = sqlsrv_query($conn, "SELECT CharID FROM Characters WHERE PlayerID=?", [$playerID]);
    if($stmtChars){
        while($row = sqlsrv_fetch_array($stmtChars, SQLSRV_FETCH_ASSOC)){
            $charIDs[] = $row['CharID'];
        }
    }

    // Deleta itens e logs relacionados
    if(!empty($charIDs)){
        $in = str_repeat('?,', count($charIDs) - 1) . '?';
        sqlsrv_query($conn, "DELETE FROM Items WHERE CharID IN ($in)", $charIDs);
        sqlsrv_query($conn, "DELETE FROM DungeonLog WHERE CharID IN ($in)", $charIDs);
    }

    // Deleta personagens
    sqlsrv_query($conn, "DELETE FROM Characters WHERE PlayerID=?", [$playerID]);

    // Deleta a conta do jogador
    sqlsrv_query($conn, "DELETE FROM Players WHERE PlayerID=?", [$playerID]);

    // Confirma transação
    sqlsrv_commit($conn);

    // Limpa sessão
    session_destroy();

    // Atualiza a página (redireciona para index ou login)
    header("Location: index.php");
    exit;

} catch(Exception $e){
    sqlsrv_rollback($conn);
    die("❌ Erro ao deletar a conta: " . $e->getMessage());
}
