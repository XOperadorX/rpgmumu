function carregarInimigos() {
    global $conn;
    $playerID = $_SESSION['PlayerID'];

    // Pega personagem
    $stmtChar = sqlsrv_query($conn, "SELECT TOP 1 * FROM Characters WHERE PlayerID=?", [$playerID]);
    $char = sqlsrv_fetch_array($stmtChar, SQLSRV_FETCH_ASSOC);

    // Bônus do jogador
    $bonusLevel = $char['Level'];
    $bonusItens = 0;
    if(isset($_SESSION['itens'])){
        foreach($_SESSION['itens'] as $item => $qtd){
            if($qtd > 0) $bonusItens += 10;
        }
    }

    // Eventos ativos
    $bonusEvento = 0;
    $hoje = date('Y-m-d');
    $stmtEvt = sqlsrv_query($conn, "SELECT * FROM LootEvents WHERE ? BETWEEN StartDate AND EndDate", [$hoje]);
    while($event = sqlsrv_fetch_array($stmtEvt, SQLSRV_FETCH_ASSOC)){
        $bonusEvento += 20;
    }

    $enemies = [];
    $stmt = sqlsrv_query($conn, "SELECT * FROM Enemies");
    while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)){
        $enemyID = $row['EnemyID'];

        $loot = [];
        $stmtLoot = sqlsrv_query($conn, "SELECT ItemName, DropRate, Rarity FROM EnemyLoot WHERE EnemyID = ?", [$enemyID]);
        while($lootRow = sqlsrv_fetch_array($stmtLoot, SQLSRV_FETCH_ASSOC)){
            $chanceFinal = $lootRow['DropRate'] + $bonusLevel + $bonusItens + $bonusEvento;
            $chanceFinal = min($chanceFinal, 100);

            $loot[] = [
                'ItemName' => $lootRow['ItemName'],
                'DropRate' => $lootRow['DropRate'],
                'ChanceFinal' => $chanceFinal,
                'Rarity' => $lootRow['Rarity'] ?? 'common'
            ];
        }

        $row['HP'] = $row['HP'];
        $row['MaxHP'] = $row['HP'];
        $row['Mana'] = $row['Mana'] ?? 0;
        $row['MaxMana'] = $row['Mana'] ?? 0;
        $row['XP'] = $row['XP'] ?? 0;

        $row['Loot'] = $loot;
        $enemies[] = $row;
    }

    return $enemies;
}
