<?php
session_start();
include "db.php";

// Verifica se jogador está logado
if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// Confirmação via GET
if(!isset($_GET['confirm'])){
    echo "<!DOCTYPE html>
    <html lang='pt-br'>
    <head>
        <meta charset='UTF-8'>
        <title>Confirmação de Exclusão</title>
        <style>
            body { font-family: Arial, sans-serif; background:#1c1c1c; color:#fff; text-align:center; padding:50px; }
            a { display:inline-block; margin:10px; padding:10px 20px; border-radius:5px; text-decoration:none; font-weight:bold; }
            .sim { background:#ff3333; color:#fff; }
            .cancelar { background:#444; color:#fff; }
            .sim:hover { background:#ff0000; }
            .cancelar:hover { background:#666; }
        </style>
    </head>
    <body>
        <h2>⚠️ Confirmação de Exclusão</h2>
        <p>Tem certeza que deseja excluir sua conta? <strong>Essa ação é irreversível!</strong></p>
        <a href='del_conta.php?confirm=yes' class='sim'>Sim, excluir minha conta</a>
        <a href='dashboard.php' class='cancelar'>Cancelar</a>
    </body>
    </html>";
    exit;
}

// Se confirmou, deleta dados
try {
    // Inicia transação
    sqlsrv_begin_transaction($conn);

    // Pega todos os CharID do jogador
    $charIDs = [];
    $stmtChars = sqlsrv_query($conn, "SELECT CharID FROM Characters WHERE PlayerID=?", [$playerID]);
    if($stmtChars){
        while($row = sqlsrv_fetch_array($stmtChars, SQLSRV_FETCH_ASSOC)){
            $charIDs[] = $row['CharID'];
        }
    }

    // Deleta itens e logs
    if(!empty($charIDs)){
        $in = str_repeat('?,', count($charIDs) - 1) . '?';
        sqlsrv_query($conn, "DELETE FROM Items WHERE CharID IN ($in)", $charIDs);
        sqlsrv_query($conn, "DELETE FROM DungeonLog WHERE CharID IN ($in)", $charIDs);
    }

    // Deleta personagens
    sqlsrv_query($conn, "DELETE FROM Characters WHERE PlayerID=?", [$playerID]);

    // Deleta moedas
    sqlsrv_query($conn, "DELETE FROM Players WHERE PlayerID=?", [$playerID]);

    // Deleta jogador
    sqlsrv_query($conn, "DELETE FROM Players WHERE PlayerID=?", [$playerID]);

    // Confirma transação
    sqlsrv_commit($conn);

    // Limpa sessão
    session_destroy();

    // Redireciona ou mostra mensagem
    header("Location: index.php?msg=Conta+excluída+com+sucesso");
    exit;

} catch(Exception $e){
    // Em caso de erro, desfaz transação
    sqlsrv_rollback($conn);
    die("❌ Erro ao deletar a conta: " . $e->getMessage());
}
?>
