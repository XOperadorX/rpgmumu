<?php
session_start();
include "db.php";

header('Content-Type: application/json');

if(!isset($_SESSION['PlayerID'])){
    echo json_encode(['error'=>'Não logado']);
    exit;
}

$playerID = $_SESSION['PlayerID'];
$precoPorPonto = 10; // moedas por ponto
$pontosComprar = 10; // pontos por compra

// Pega dados atuais
$sql = "SELECT MoedaMumu, ContaSaude FROM Players WHERE PlayerID=?";
$stmt = sqlsrv_query($conn, $sql, [$playerID]);
$player = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

if(!$player){
    echo json_encode(['error'=>'Jogador não encontrado']);
    exit;
}

$moedaAtual = (int)$player['MoedaMumu'];
$saudeAtual = (int)$player['ContaSaude'];
$custo = $precoPorPonto * $pontosComprar;

if($moedaAtual < $custo){
    echo json_encode(['error'=>'Moedas insuficientes']);
    exit;
}

$novaSaude = min($saudeAtual + $pontosComprar, 100);
$novaMoeda = $moedaAtual - $custo;

// Atualiza banco
$sqlUpdate = "UPDATE Players SET ContaSaude=?, MoedaMumu=? WHERE PlayerID=?";
sqlsrv_query($conn, $sqlUpdate, [$novaSaude, $novaMoeda, $playerID]);

echo json_encode([
    'msg'=>"✅ Comprado +$pontosComprar pontos de saúde por $custo moedas!",
    'health'=>$novaSaude,
    'moeda'=>$novaMoeda
]);
