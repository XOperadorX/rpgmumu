<?php
session_start();
include "db.php";
include "check_ban.php";

// Listar inimigos
$enemies = [];
$stmt = sqlsrv_query($conn, "SELECT * FROM Enemies ORDER BY Level");
while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)){
    // Pega loot
    $loot = [];
    $stmtLoot = sqlsrv_query($conn, "SELECT ItemName FROM EnemyLoot WHERE EnemyID=?", [$row['EnemyID']]);
    while($l = sqlsrv_fetch_array($stmtLoot, SQLSRV_FETCH_ASSOC)){
        $loot[] = $l['ItemName'];
    }
    $row['Loot'] = $loot;
    $enemies[] = $row;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>⚔️ Editar Inimigos</title>
</head>
<body>
<h1>⚔️ Inimigos</h1>

<a href="dashboard.php">⬅ Voltar</a>

<table border="1" cellpadding="5">
<tr>
  <th>Nome</th><th>Lvl</th><th>XP</th><th>HP</th><th>Mana</th><th>Loot</th><th>Ações</th>
</tr>
<?php foreach($enemies as $e): ?>
<tr>
  <form method="post" action="save_enemy.php">
    <input type="hidden" name="EnemyID" value="<?= $e['EnemyID'] ?>">
    <td><input type="text" name="Name" value="<?= htmlspecialchars($e['Name']) ?>"></td>
    <td><input type="number" name="Level" value="<?= $e['Level'] ?>" style="width:60px"></td>
    <td><input type="number" name="XP" value="<?= $e['XP'] ?>" style="width:60px"></td>
    <td><input type="number" name="HP" value="<?= $e['HP'] ?>" style="width:70px"> / 
        <input type="number" name="MaxHP" value="<?= $e['MaxHP'] ?>" style="width:70px"></td>
    <td><input type="number" name="Mana" value="<?= $e['Mana'] ?>" style="width:70px"> / 
        <input type="number" name="MaxMana" value="<?= $e['MaxMana'] ?>" style="width:70px"></td>
    <td><?= implode(", ", $e['Loot']) ?></td>
    <td>
      <button type="submit" name="editar">Salvar</button>
      <a href="loot.php?EnemyID=<?= $e['EnemyID'] ?>">Loot</a>
    </td>
  </form>
</tr>
<?php endforeach; ?>
</table>

<a href="new_enemy.php">➕ Novo inimigo</a>
</body>
</html>
