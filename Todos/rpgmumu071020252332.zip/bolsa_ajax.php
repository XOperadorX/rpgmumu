<?php
session_start();
include "db.php";

if (!isset($_SESSION['PlayerID'])) {
    echo json_encode(['status'=>'erro','msg'=>'❌ Acesso negado. Faça login.']);
    exit;
}

$playerID = $_SESSION['PlayerID'];

// Carrega saldo e carteira
$query = "SELECT MoedaMumu, CarteiraJSON FROM Players WHERE PlayerID = ?";
$params = [$playerID];
$stmt = sqlsrv_query($conn, $query, $params);
if($stmt === false) die(json_encode(['status'=>'erro','msg'=>'Erro no banco']));

$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
$moeda = $row['MoedaMumu'] ?? 500;
$carteira = !empty($row['CarteiraJSON']) ? json_decode($row['CarteiraJSON'], true) : [
    'Ouro'=>0,'Prata'=>0,'Bronze'=>0,'Cristal'=>0,'Esmeralda'=>0
];

// Ativos
$ativos = [
    'Ouro'=>50,'Prata'=>30,'Bronze'=>10,'Cristal'=>100,'Esmeralda'=>150
];

// Recebe dados do AJAX
$nome = $_POST['ativo'] ?? '';
$qtd = max(1,intval($_POST['quantidade'] ?? 1));
$acao = $_POST['acao'] ?? '';

$msg = '';

if(!isset($ativos[$nome])){
    echo json_encode(['status'=>'erro','msg'=>'Ativo inválido']);
    exit;
}

$preco = $ativos[$nome];

if($acao === 'comprar'){
    $custo = $preco * $qtd;
    if($moeda >= $custo){
        $moeda -= $custo;
        $carteira[$nome] += $qtd;
        $msg = "✅ Comprou $qtd x $nome por $custo moedas!";
    } else {
        echo json_encode(['status'=>'erro','msg'=>'❌ Saldo insuficiente!']);
        exit;
    }
} elseif($acao === 'vender'){
    if($carteira[$nome] >= $qtd){
        $moeda += $preco * $qtd;
        $carteira[$nome] -= $qtd;
        $msg = "🔹 Vendeu $qtd x $nome por ".($preco*$qtd)." moedas!";
    } else {
        echo json_encode(['status'=>'erro','msg'=>'❌ Você não possui essa quantidade!']);
        exit;
    }
} else {
    echo json_encode(['status'=>'erro','msg'=>'Ação inválida']);
    exit;
}

// Atualiza banco
$updateQuery = "UPDATE Players SET MoedaMumu = ?, CarteiraJSON = ? WHERE PlayerID = ?";
$params = [$moeda, json_encode($carteira), $playerID];
sqlsrv_query($conn, $updateQuery, $params);

// Atualiza sessão
$_SESSION['MoedaMumu'] = $moeda;
$_SESSION['carteira'] = $carteira;

// Retorna JSON
echo json_encode([
    'status'=>'ok',
    'msg'=>$msg,
    'moeda'=>$moeda,
    'carteira'=>$carteira
]);
