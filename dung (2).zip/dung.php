<?php
// dung.php
session_start();
include "db.php";
include "check_ban.php";

// ==========================
// Checa login
// ==========================
if (!isset($_SESSION['PlayerID'])) {
    die("⛔ Acesso negado. Faça login.");
}
$playerID = $_SESSION['PlayerID'];

// ==========================
// Carrega personagem
// ==========================
$stmt = sqlsrv_query($conn, "SELECT TOP 1 * FROM dbo.Characters WHERE PlayerID = ?", [$playerID]);
if ($stmt === false) die("Erro ao consultar personagem: " . print_r(sqlsrv_errors(), true));
$char = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
if (!$char) die("Você precisa ter pelo menos um personagem. <a href='dashboard.php'>⬅ Voltar</a>");

// ==========================
// Calcula XP para o próximo nível
// ==========================
$char['NextLevelXP'] = intval($char['Level']) * 100;

// ==========================
// Função para carregar inimigos
// ==========================
function carregarInimigos() {
    global $conn;
    $sql = "SELECT EnemyID, Name, HP, MaxHP, XP, Loot, Mana, MaxMana, Level FROM dbo.Enemies";
    $stmt = sqlsrv_query($conn, $sql);
    if ($stmt === false) die("Erro ao carregar inimigos: " . print_r(sqlsrv_errors(), true));

    $enemies = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $row['HP'] = $row['HP'] ?? 0;
        $row['MaxHP'] = $row['MaxHP'] ?? $row['HP'];
        $row['Mana'] = $row['Mana'] ?? 0;
        $row['MaxMana'] = $row['MaxMana'] ?? $row['Mana'];
        $row['XP'] = $row['XP'] ?? 0;

        if (!empty($row['Loot'])) {
            $lootParsed = json_decode($row['Loot'], true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($lootParsed)) {
                $row['Loot'] = $lootParsed;
            } else {
                $row['Loot'] = array_map('trim', explode(',', $row['Loot']));
            }
        } else {
            $row['Loot'] = [];
        }

        $enemies[] = $row;
    }
    return $enemies;
}

// ==========================
// Inicializa dungeon
// ==========================
if (!isset($_SESSION['dungeon']) || !is_array($_SESSION['dungeon']) || ($_SESSION['dungeon']['playerID'] ?? 0) != $playerID) {
    $_SESSION['dungeon'] = [
        'playerID' => $playerID,
        'current' => 0,
        'enemies' => carregarInimigos(),
        'fim' => false,
        'char' => $char
    ];
    $_SESSION['log'] = []; // limpa log ao iniciar dungeon
}

$dungeon = &$_SESSION['dungeon'];
$enemy = &$dungeon['enemies'][$dungeon['current']] ?? null;
$hpZerado = ($char['HP'] ?? 0) <= 0;
$fim = $dungeon['fim'] ?? false;

// ==========================
// Carrega inventário
// ==========================
$inventario = [];
$stmtItens = sqlsrv_query($conn, "SELECT ItemID, Nome, Quantidade, Raridade, Valor FROM dbo.Items WHERE PlayerID = ?", [$playerID]);
if ($stmtItens !== false) {
    while ($row = sqlsrv_fetch_array($stmtItens, SQLSRV_FETCH_ASSOC)) {
        $inventario[$row['ItemID']] = [
            'nome' => $row['Nome'],
            'qtd' => intval($row['Quantidade']),
            'raridade' => $row['Raridade'] ?? 'comum',
            'valor' => intval($row['Valor'] ?? 0)
        ];
    }
}

// Mescla com inventário da sessão
if (isset($_SESSION['inventario']) && is_array($_SESSION['inventario'])) {
    foreach ($_SESSION['inventario'] as $itemID => $dados) {
        if (isset($inventario[$itemID])) {
            $inventario[$itemID]['qtd'] += intval($dados['qtd'] ?? 0);
        } else {
            $inventario[$itemID] = [
                'nome' => $dados['nome'] ?? $itemID,
                'qtd' => intval($dados['qtd'] ?? 0),
                'raridade' => $dados['raridade'] ?? 'comum',
                'valor' => intval($dados['valor'] ?? 0)
            ];
        }
    }
}

// ==========================
// Log seguro
// ==========================
$log = $_SESSION['log'] ?? [];
function logHtml($msg) {
    if (is_array($msg)) {
        $hora = $msg['hora'] ?? date('d/m/Y H:i:s');
        $texto = $msg['msg'] ?? json_encode($msg, JSON_UNESCAPED_UNICODE);
        return "<div class='log-msg'><span style='color:#0ff;'>[{$hora}]</span> {$texto}</div>";
    }
    return "<div class='log-msg'><span style='color:#0ff;'>[".date('d/m/Y H:i:s')."]</span> ".htmlspecialchars($msg)."</div>";
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Dungeon - RPGMumu</title>
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;900&display=swap" rel="stylesheet">
<style>
/* === CSS Futurista === */
body { font-family: 'Orbitron', Arial, sans-serif; background: radial-gradient(circle at top,#0d0d0d 0%,#000 100%); color:#fff; text-align:center; animation:bgPulse 20s infinite alternate;}
@keyframes bgPulse {0%{background-position:0 0;}50%{background-position:100% 100%;}100%{background-position:0 0;}}
.cards-container{display:flex;justify-content:center;flex-wrap:wrap;gap:30px;margin-top:30px;}
.card{background:linear-gradient(145deg,#1a1a1a,#2c2c2c);padding:25px;border-radius:16px;width:300px;box-shadow:0 0 15px #00ffe0,0 0 25px #ff00ff inset;border:2px solid #00ffe0;transition:transform 0.3s ease,box-shadow 0.3s ease;position:relative;overflow:hidden;}
.card::before{content:'';position:absolute;top:-50%;left:-50%;width:200%;height:200%;background:linear-gradient(60deg,#ff00ff,#00ffe0,#ffdd33,#ff0055);animation:neonMove 5s linear infinite;mix-blend-mode:overlay;}
@keyframes neonMove{0%{transform:rotate(0deg);}100%{transform:rotate(360deg);}}
.card:hover{transform:translateY(-8px) scale(1.03);box-shadow:0 0 30px #00ffe0,0 0 40px #ff00ff inset;}
.progress{background:#111;border-radius:12px;overflow:hidden;height:22px;margin-bottom:10px;border:1px solid #555;box-shadow:0 0 6px #00ffea inset;}
.bar{height:100%;transition:width .6s ease-in-out;box-shadow:0 0 10px #00ffea,0 0 15px #ff00ff inset;border-radius:8px;}
.player-bar{background:linear-gradient(90deg,#ff0055,#ff55aa);animation:glowBar 3s ease-in-out infinite alternate;}
.mana-bar{background:linear-gradient(90deg,#0066ff,#00ccff);animation:glowBar 3s ease-in-out infinite alternate;}
.power-bar{background:linear-gradient(90deg,#ffdd33,#ff8800);animation:glowBar 3s ease-in-out infinite alternate;}
.enemy-bar{background:linear-gradient(90deg,#ff4444,#990000);animation:glowBar 3s ease-in-out infinite alternate;}
.enemy-mana-bar{background:linear-gradient(90deg,#33ddff,#3399cc);animation:glowBar 3s ease-in-out infinite alternate;}
.xp-bar{background:linear-gradient(90deg,#33ff33,#00cc00);animation:glowBar 3s ease-in-out infinite alternate;}
@keyframes glowBar{0%{filter:brightness(0.8);}50%{filter:brightness(1.3);}100%{filter:brightness(0.8);}}
#log{max-height:350px;overflow:auto;text-align:left;margin:25px auto;width:90%;background:#111;padding:15px;border-radius:10px;box-shadow:0 0 20px #00ffe0 inset,0 0 15px #ff00ff;border:2px solid #00ccff;color:#0ff;}
.log-msg{padding:6px 10px;margin-bottom:6px;border-left:3px solid #0ff;background:rgba(0,255,255,0.05);animation:glow 1.5s infinite alternate;}
@keyframes glow{0%{box-shadow:0 0 5px #0ff;}100%{box-shadow:0 0 15px #0ff;}}
#inventario-container{width:90%;margin:25px auto;text-align:left;background:#111;padding:20px;border-radius:12px;box-shadow:0 0 25px #ff00ff,0 0 15px #00ffe0 inset;border:2px solid #00ffe0;}
#inventario-container table{width:100%;border-collapse:collapse;}
#inventario-container th, #inventario-container td{padding:12px;border:1px solid #333;text-align:center;}
#inventario-container th{background:#222;color:#00ffe0;text-shadow:0 0 6px #00ccff;}
.rar-comum{color:#ccc;}
.rar-raro{color:#00bfff;font-weight:bold;text-shadow:0 0 10px #00bfff;}
.rar-épico{color:#c100ff;font-weight:bold;text-shadow:0 0 14px #c100ff;}
.rar-lendário{color:#ffd700;font-weight:bold;text-shadow:0 0 18px #ffd700;animation:glowLegend 2s infinite alternate;}
@keyframes glowLegend{0%{text-shadow:0 0 12px #ffd700;}50%{text-shadow:0 0 24px #ffd700;}100%{text-shadow:0 0 12px #ffd700;}}
#voltar{display:none;margin-top:15px;padding:12px 20px;background:#3498db;color:#fff;text-decoration:none;border-radius:10px;box-shadow:0 0 10px #00ccff,0 0 18px #ff00ff inset;transition:all 0.3s ease;font-weight:bold;letter-spacing:1px;}
#voltar:hover{background:#00ccff;box-shadow:0 0 18px #00ffea,0 0 25px #ff00ff inset;}
</style>
</head>
<body>

<a id="voltar" href="dashboard.php">⬅️ Voltar</a>
<h1>🗡️ Masmorra - <?= htmlspecialchars($char['Name']) ?></h1>

<?php if ($hpZerado): ?>
<p style="color:red; font-size:1.1em;">💀 Você morreu! Dungeon encerrada.</p>
<?php elseif ($fim): ?>
<p style="color:yellow; font-size:1.1em;">🏁 Parabéns! Todos os inimigos foram derrotados!</p>
<?php endif; ?>

<div class="cards-container">
  <div class="card">
    <h3><?= htmlspecialchars($char['Name']) ?></h3>
    <p>Level: <?= intval($char['Level']) ?> | XP: <?= intval($char['Exp']) ?></p>
    <div class="progress"><div class="bar player-bar" style="width:<?= ($char['MaxHP']>0 ? ($char['HP']/$char['MaxHP']*100) : 0) ?>%"></div></div>
    <p>HP: <span id="player-hp"><?= intval($char['HP']) ?></span> / <?= intval($char['MaxHP']) ?></p>
    <div class="progress"><div class="bar mana-bar" style="width:<?= ($char['MaxMana']>0 ? ($char['Mana']/$char['MaxMana']*100) : 0) ?>%"></div></div>
    <p>Mana: <span id="player-mana"><?= intval($char['Mana']) ?></span> / <?= intval($char['MaxMana']) ?></p>
    <div class="progress"><div class="bar power-bar" style="width:<?= ($char['MaxPower']>0 ? ($char['Power']/$char['MaxPower']*100) : 0) ?>%"></div></div>
    <p>Poder: <span id="player-power"><?= intval($char['Power']) ?></span> / <?= intval($char['MaxPower']) ?></p>
    <div class="progress"><div class="bar xp-bar" style="width:<?= ($char['NextLevelXP']>0 ? ($char['Exp']/$char['NextLevelXP']*100) : 0) ?>%"></div></div>
    <p>XP: <span id="player-xp"><?= intval($char['Exp']) ?></span> / <?= intval($char['NextLevelXP']) ?></p>
  </div>

  <?php if ($enemy): ?>
  <div class="card">
    <h3><?= htmlspecialchars($enemy['Name']) ?></h3>
    <p>Level: <?= intval($enemy['Level']) ?> | XP: <?= intval($enemy['XP']) ?></p>
    <div class="progress"><div class="bar enemy-bar" style="width:<?= ($enemy['MaxHP']>0 ? ($enemy['HP']/$enemy['MaxHP']*100) : 0) ?>%"></div></div>
    <p>HP: <span id="enemy-hp"><?= intval($enemy['HP']) ?></span> / <?= intval($enemy['MaxHP']) ?></p>
    <div class="progress"><div class="bar enemy-mana-bar" style="width:<?= ($enemy['MaxMana']>0 ? ($enemy['Mana']/$enemy['MaxMana']*100) : 0) ?>%"></div></div>
    <p>Mana: <span id="enemy-mana"><?= intval($enemy['Mana']) ?></span> / <?= intval($enemy['MaxMana']) ?></p>
  </div>
  <?php endif; ?>
</div>

<h3>📜 Histórico de Combate</h3>
<div id="log">
<?php
if (empty($log)) {
    echo "<div class='log-msg'><em>Nenhum evento registrado ainda.</em></div>";
} else {
    foreach ($log as $msg) echo logHtml($msg);
}
?>
</div>

<div id="inventario-container">
  <h3>📦 Inventário</h3>
  <table id="inv-table">
    <tr><th>Item</th><th>Quantidade</th><th>Valor</th></tr>
    <?php foreach($inventario as $itemID => $dados): ?>
      <tr class="rar-<?= htmlspecialchars($dados['raridade']) ?>">
        <td><?= htmlspecialchars($dados['nome'] ?? $itemID) ?></td>
        <td id="qtd-<?= $itemID ?>"><?= intval($dados['qtd'] ?? 0) ?></td>
        <td>💰 <?= intval($dados['valor'] ?? 0) ?></td>
      </tr>
    <?php endforeach; ?>
  </table>
</div>

<script>
function safePct(v,m){ return (m>0? Math.max(0,Math.min(1,v/m)):0); }
function atualizarBarras(char,enemy){
    document.querySelector('.player-bar').style.width = (safePct(char.HP,char.MaxHP)*100)+'%';
    document.querySelector('.mana-bar').style.width = (safePct(char.Mana,char.MaxMana)*100)+'%';
    document.querySelector('.power-bar').style.width = (safePct(char.Power,char.MaxPower)*100)+'%';
    document.getElementById('player-hp').textContent=char.HP;
    document.getElementById('player-mana').textContent=char.Mana;
    document.getElementById('player-power').textContent=char.Power;
    const nextXP=char.NextLevelXP??100;
    const exp=char.Exp??0;
    document.querySelector('.xp-bar').style.width=(safePct(exp,nextXP)*100)+'%';
    document.getElementById('player-xp').textContent=exp;
    document.getElementById('player-nextxp').textContent=nextXP;
    if(enemy){
        document.querySelector('.enemy-bar').style.width=(safePct(enemy.HP,enemy.MaxHP)*100)+'%';
        document.querySelector('.enemy-mana-bar').style.width=(safePct(enemy.Mana,enemy.MaxMana)*100)+'%';
        document.getElementById('enemy-hp').textContent=enemy.HP;
        document.getElementById('enemy-mana').textContent=enemy.Mana;
    }
}

function atualizarInventario(inv){
    const table=document.getElementById('inv-table');
    table.innerHTML='<tr><th>Item</th><th>Quantidade</th><th>Valor</th></tr>';
    for(const itemID in inv){
        const d=inv[itemID];
        const tr=document.createElement('tr');
        tr.className='rar-'+(d.raridade||'comum');
        tr.innerHTML=`<td>${d.nome??itemID}</td><td id="qtd-${itemID}">${d.qtd??0}</td><td>💰 ${d.valor??0}</td>`;
        table.appendChild(tr);
    }
}

function atualizarLog(logs){
    const el=document.getElementById('log');
    logs.forEach(msg=>{
        const div=document.createElement('div');
        div.className='log-msg';
        const hora=new Date().toLocaleString('pt-BR',{hour12:false});
        div.innerHTML=`<span style="color:#0ff;">[${hora}]</span> ${Array.isArray(msg)?(msg.msg??JSON.stringify(msg)):msg}`;
        el.appendChild(div);
    });
    el.scrollTop=el.scrollHeight;
}

function atualizarDungeon(){
    fetch('turno.php')
    .then(r=>r.json())
    .then(data=>{
        if(!data)return;
        if(data.char) atualizarBarras(data.char,data.enemy);
        if(data.inventario) atualizarInventario(data.inventario);
        if(data.log) atualizarLog(data.log);
        if(data.fim){
            document.getElementById('voltar').style.display='inline-block';
        }else setTimeout(atualizarDungeon,1200);
    })
    .catch(err=>console.error('Erro ao atualizar dungeon:',err));
}

<?php if (!$hpZerado && !$fim): ?>
atualizarDungeon();
<?php else: ?>
document.getElementById('voltar').style.display='inline-block';
<?php endif; ?>
</script>

</body>
</html>
