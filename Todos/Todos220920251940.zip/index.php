<?php
session_start();
include "db.php";

$mensagem = "";

// --- LOGIN ---
if (isset($_POST['action']) && $_POST['action'] === 'login') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT PlayerID, PasswordHash FROM Players WHERE Username = ?";
    $stmt = sqlsrv_query($conn, $sql, [$username]);

    if ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        if (password_verify($password, $row['PasswordHash'])) {
            $_SESSION['PlayerID'] = $row['PlayerID'];
            header("Location: dashboard.php");
            exit;
        } else {
            $mensagem = "❌ Senha incorreta!";
        }
    } else {
        $mensagem = "❌ Usuário não encontrado!";
    }
}

// --- CADASTRO ---
if (isset($_POST['action']) && $_POST['action'] === 'register') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $hash = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO Players (Username, PasswordHash) VALUES (?, ?)";
    $stmt = sqlsrv_query($conn, $sql, [$username, $hash]);

    if ($stmt) {
        $mensagem = "✅ Usuário cadastrado com sucesso! Agora faça login.";
    } else {
        $mensagem = "❌ Erro no cadastro: " . print_r(sqlsrv_errors(), true);
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Mumu RPG</title>
	
    <!-- Aqui você chama o CSS externo -->
    <link rel="stylesheet" href="style.css">

    <script>
        function mostrarFormulario(tipo) {
            document.getElementById('loginForm').style.display = (tipo === 'login') ? 'block' : 'none';
            document.getElementById('registerForm').style.display = (tipo === 'register') ? 'block' : 'none';
        }
    </script>
</head>
<body>
    <h1>🌟 Bem-vindo ao Mumu RPG 🌟</h1>

    <?php if(isset($_SESSION['PlayerID'])): ?>
        <p>Você já está logado!</p>
        <a href="dashboard.php">Ir para o Painel</a>
        <a href="logout.php">Sair</a>
    <?php else: ?>
        <p>Faça login ou crie sua conta para começar a aventura.</p>
        <button onclick="mostrarFormulario('login')">Entrar</button>
        <button onclick="mostrarFormulario('register')">Cadastrar</button>

        <!-- Formulário de Login -->
        <div id="loginForm" style="display:none;">
            <form method="post">
                <input type="hidden" name="action" value="login">
                <input type="text" name="username" placeholder="Usuário" required><br>
                <input type="password" name="password" placeholder="Senha" required><br>
                <button type="submit">Login</button>
            </form>
        </div>

        <!-- Formulário de Cadastro -->
        <div id="registerForm" style="display:none;">
            <form method="post">
                <input type="hidden" name="action" value="register">
                <input type="text" name="username" placeholder="Usuário" required><br>
                <input type="password" name="password" placeholder="Senha" required><br>
                <button type="submit">Cadastrar</button>
            </form>
        </div>
    <?php endif; ?>

    <p style="color:orange;"><?php echo $mensagem; ?></p>
</body>
</html>
