<?php
// ==========================
// dung.php - Interface completa da Dungeon
// ==========================
session_start();
include "db.php";
include "check_ban.php";

header('Content-Type: text/html; charset=utf-8');

if(!isset($_SESSION['PlayerID'])){
    die("⛔ Acesso negado. Faça login.");
}
$playerID = $_SESSION['PlayerID'];

// ==========================
// Pega personagem atualizado do banco
// ==========================
$stmt = sqlsrv_query($conn, "SELECT TOP 1 * FROM Characters WHERE PlayerID=?", [$playerID]);
$charDB = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

if(!$charDB) die("Você precisa ter pelo menos um personagem. <a href='dashboard.php'>⬅ Voltar</a>");

// Corrige valores
$charDB['NextLevelExp'] = intval($charDB['NextLevelExp'] ?? 100);
$charDB['HP'] = intval($charDB['HP'] ?? $charDB['MaxHP']);
$charDB['Mana'] = intval($charDB['Mana'] ?? $charDB['MaxMana']);
$charDB['Power'] = intval($charDB['Power'] ?? $charDB['MaxPower']);

// ==========================
// Inicializa dungeon na sessão
// ==========================
if(!isset($_SESSION['dungeon']) || ($_SESSION['dungeon']['playerID'] ?? 0) != $playerID){
    // Carrega 3 inimigos aleatórios
    $enemies = [];
    $enemyStmt = sqlsrv_query($conn, "SELECT TOP 3 * FROM Enemies ORDER BY NEWID()");
    while($row = sqlsrv_fetch_array($enemyStmt, SQLSRV_FETCH_ASSOC)){
        $row['HP'] = intval($row['HP'] ?? 0);
        $row['MaxHP'] = intval($row['MaxHP'] ?? $row['HP']);
        $row['Mana'] = intval($row['Mana'] ?? 0);
        $row['MaxMana'] = intval($row['MaxMana'] ?? $row['Mana']);
        $row['Loot'] = !empty($row['Loot']) ? array_map('trim', explode(',', $row['Loot'])) : [];
        $enemies[] = $row;
    }

    $_SESSION['dungeon'] = [
        'playerID'=>$playerID,
        'current'=>0,
        'enemies'=>$enemies,
        'fim'=>false,
        'char'=>$charDB,
        'log'=>[]
    ];
}

// ==========================
// Atualiza char da sessão
// ==========================
$dungeon = &$_SESSION['dungeon'];
$dungeon['char']['HP'] = $charDB['HP'];
$dungeon['char']['Mana'] = $charDB['Mana'];
$dungeon['char']['Power'] = $charDB['Power'];
$char = &$dungeon['char'];

$currentEnemy = $dungeon['enemies'][$dungeon['current']] ?? null;
$log = &$dungeon['log'];
$hpZerado = $char['HP'] <= 0;
$fim = $dungeon['fim'] ?? false;

// Inventário
$inventario = $_SESSION['inventario'] ?? [];

// Função de log colorido
function logHtml($msg){
    if(is_array($msg) && isset($msg['msg'])){
        return "<div class='log-msg'>".$msg['msg']."</div>";
    }
    return "<div class='log-msg'>".htmlspecialchars($msg)."</div>";
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Dungeon - RPGMumu</title>
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;900&display=swap" rel="stylesheet">
<style>
body{font-family:'Orbitron',Arial,sans-serif;background:radial-gradient(circle at top,#0d0d0d 0%,#000 100%);color:#fff;text-align:center;}
.cards-container{display:flex;justify-content:center;flex-wrap:wrap;gap:30px;margin-top:30px;}
.card{background:linear-gradient(145deg,#1a1a1a,#2c2c2c);padding:25px;border-radius:16px;width:300px;position:relative;overflow:hidden;}
.progress{background:#111;border-radius:12px;overflow:hidden;height:22px;margin-bottom:10px;border:1px solid #555;}
.bar{height:100%;border-radius:8px;}
.player-bar{background:linear-gradient(90deg,#ff0055,#ff55aa);}
.mana-bar{background:linear-gradient(90deg,#0066ff,#00ccff);}
.power-bar{background:linear-gradient(90deg,#ffdd33,#ff8800);}
.enemy-bar{background:linear-gradient(90deg,#ff4444,#990000);}
.enemy-mana-bar{background:linear-gradient(90deg,#33ddff,#3399cc);}
.xp-bar{background:linear-gradient(90deg,#33ff33,#00cc00);}
#log{max-height:350px;overflow:auto;text-align:left;margin:25px auto;width:90%;background:#111;padding:15px;border-radius:10px;color:#0ff;}
.log-msg{padding:6px 10px;margin-bottom:6px;border-left:3px solid #0ff;background:rgba(0,255,255,0.05);}
#inventario-container{width:90%;margin:25px auto;text-align:left;background:#111;padding:20px;border-radius:12px;color:#0ff;}
#inventario-container table{width:100%;border-collapse:collapse;}
#inventario-container th, td{padding:12px;border:1px solid #333;text-align:center;}
#voltar{display:none;margin-bottom:20px;color:#ff0;}
</style>
</head>
<body>

<a id="voltar" href="dashboard.php">⬅️ Voltar</a>
<h1>🗡️ Masmorra - <?=htmlspecialchars($char['Name'])?></h1>

<?php if($hpZerado): ?>
<p style="color:red;">💀 Você morreu! Dungeon encerrada.</p>
<?php elseif($fim): ?>
<p style="color:yellow;">🏁 Todos os inimigos foram derrotados!</p>
<?php endif; ?>

<div class="cards-container">
    <div class="card">
        <h3><?=htmlspecialchars($char['Name'])?></h3>
        <p>Level: <?=intval($char['Level'])?> | XP: <?=intval($char['Exp'])?> / <?=intval($char['NextLevelExp'])?></p>

        <div class="progress"><div class="bar player-bar" style="width:<?=($char['MaxHP']>0?($char['HP']/$char['MaxHP']*100):0)?>%"></div></div>
        <p>HP: <span id="player-hp"><?=intval($char['HP'])?></span> / <?=intval($char['MaxHP'])?></p>

        <div class="progress"><div class="bar mana-bar" style="width:<?=($char['MaxMana']>0?($char['Mana']/$char['MaxMana']*100):0)?>%"></div></div>
        <p>Mana: <span id="player-mana"><?=intval($char['Mana'])?></span> / <?=intval($char['MaxMana'])?></p>

        <div class="progress"><div class="bar power-bar" style="width:<?=($char['MaxPower']>0?($char['Power']/$char['MaxPower']*100):0)?>%"></div></div>
        <p>Poder: <span id="player-power"><?=intval($char['Power'])?></span> / <?=intval($char['MaxPower'])?></p>

        <div class="progress"><div class="bar xp-bar" style="width:<?=($char['NextLevelExp']>0?($char['Exp']/$char['NextLevelExp']*100):0)?>%"></div></div>
        <p>XP: <span id="player-xp"><?=intval($char['Exp'])?></span> / <?=intval($char['NextLevelExp'])?></p>
    </div>

    <?php if($currentEnemy): ?>
    <div class="card">
        <h3><?=htmlspecialchars($currentEnemy['Name'])?></h3>
        <p>Level: <?=intval($currentEnemy['Level'])?> | XP: <?=intval($currentEnemy['XP'])?></p>
        <div class="progress"><div class="bar enemy-bar" style="width:<?=($currentEnemy['MaxHP']>0?($currentEnemy['HP']/$currentEnemy['MaxHP']*100):0)?>%"></div></div>
        <p>HP: <span id="enemy-hp"><?=intval($currentEnemy['HP'])?></span> / <?=intval($currentEnemy['MaxHP'])?></p>
        <div class="progress"><div class="bar enemy-mana-bar" style="width:<?=($currentEnemy['MaxMana']>0?($currentEnemy['Mana']/$currentEnemy['MaxMana']*100):0)?>%"></div></div>
        <p>Mana: <span id="enemy-mana"><?=intval($currentEnemy['Mana'])?></span> / <?=intval($currentEnemy['MaxMana'])?></p>
    </div>
    <?php endif; ?>
</div>

<h3>📜 Histórico de Combate</h3>
<div id="log">
<?php
if(empty($log)) echo "<div class='log-msg'><em>Nenhum evento registrado ainda.</em></div>";
else foreach($log as $msg) echo logHtml($msg);
?>
</div>

<div id="inventario-container">
<h3>📦 Inventário</h3>
<table id="inv-table">
<tr><th>Item</th><th>Quantidade</th><th>Valor</th></tr>
<?php foreach($inventario as $itemID=>$d): ?>
<tr>
<td><?=htmlspecialchars($d['nome']??$itemID)?></td>
<td id="qtd-<?=$itemID?>"><?=intval($d['qtd']??0)?></td>
<td>💰 <?=intval($d['valor']??0)?></td>
</tr>
<?php endforeach; ?>
</table>
</div>

<script>
function safePct(v,m){return m>0?Math.max(0,Math.min(1,v/m)):0;}
function atualizarBarras(c,e){
    document.querySelector('.player-bar').style.width = (safePct(c.HP,c.MaxHP)*100)+'%';
    document.querySelector('.mana-bar').style.width = (safePct(c.Mana,c.MaxMana)*100)+'%';
    document.querySelector('.power-bar').style.width = (safePct(c.Power,c.MaxPower)*100)+'%';
    document.getElementById('player-hp').textContent=c.HP;
    document.getElementById('player-mana').textContent=c.Mana;
    document.getElementById('player-power').textContent=c.Power;
    document.querySelector('.xp-bar').style.width=(safePct(c.Exp,c.NextLevelExp)*100)+'%';
    document.getElementById('player-xp').textContent=c.Exp;

    if(e){
        document.querySelector('.enemy-bar').style.width=(safePct(e.HP,e.MaxHP)*100)+'%';
        document.querySelector('.enemy-mana-bar').style.width=(safePct(e.Mana,e.MaxMana)*100)+'%';
        document.getElementById('enemy-hp').textContent=e.HP;
        document.getElementById('enemy-mana').textContent=e.Mana;
    }
}

function atualizarInventario(inv){
    const table=document.getElementById('inv-table');
    table.innerHTML='<tr><th>Item</th><th>Quantidade</th><th>Valor</th></tr>';
    for(const id in inv){
        const d=inv[id];
        const tr=document.createElement('tr');
        tr.innerHTML=`<td>${d.nome??id}</td><td id="qtd-${id}">${d.qtd??0}</td><td>💰 ${d.valor??0}</td>`;
        table.appendChild(tr);
    }
}

function atualizarLog(logs){
    const el=document.getElementById('log');
    logs.forEach(msg=>{
        const div=document.createElement('div');
        div.className='log-msg';
        div.innerHTML=msg.msg ?? msg;
        el.appendChild(div);
    });
    el.scrollTop=el.scrollHeight;
}

function atualizarDungeon(){
    fetch('turno.php').then(r=>r.json()).then(data=>{
        if(!data) return;
        if(data.char) atualizarBarras(data.char,data.enemy);
        if(data.inventario) atualizarInventario(data.inventario);
        if(data.log) atualizarLog(data.log);
        if(data.fim) document.getElementById('voltar').style.display='inline-block';
        else setTimeout(atualizarDungeon,1200);
    }).catch(err=>console.error('Erro dungeon:',err));
}

<?php if(!$hpZerado && !$fim): ?>
atualizarDungeon();
<?php else: ?>
document.getElementById('voltar').style.display='inline-block';
<?php endif; ?>
</script>
</body>
</html>
