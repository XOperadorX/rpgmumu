<?php
session_start();
include "db.php";
include "check_ban.php"; // protege a página

header('Content-Type: application/json');

if(!isset($_SESSION['PlayerID'])){
    echo json_encode([]);
    exit;
}

$playerID = $_SESSION['PlayerID'];

// Seleciona personagens do jogador
$sql = "
SELECT TOP 1000 CharID, Name, Class, Level, Exp, HP, MaxHP, Mana, MaxMana, Power, MaxPower
FROM Characters
WHERE PlayerID = ?";

$stmt = sqlsrv_query($conn, $sql, [$playerID]);

if($stmt === false){
    echo json_encode(['error' => 'Erro ao consultar personagens.']);
    exit;
}

$chars = [];

// Função para determinar a cor da barra
function getBarColor($percent) {
    if ($percent >= 70) return 'green';
    if ($percent >= 30) return 'orange';
    return 'red';
}

while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)){
    // Calcula porcentagens
    $hpPercent    = $row['MaxHP'] > 0 ? round(($row['HP'] / $row['MaxHP']) * 100) : 0;
    $manaPercent  = $row['MaxMana'] > 0 ? round(($row['Mana'] / $row['MaxMana']) * 100) : 0;
    $powerPercent = $row['MaxPower'] > 0 ? round(($row['Power'] / $row['MaxPower']) * 100) : 0;

    $chars[] = [
        'CharID'      => $row['CharID'],
        'Name'        => $row['Name'],
        'Class'       => $row['Class'],
        'Level'       => $row['Level'],
        'Exp'         => $row['Exp'],

        'HP'          => $row['HP'],
        'MaxHP'       => $row['MaxHP'],
        'HPPercent'   => $hpPercent,
        'HPColor'     => getBarColor($hpPercent),

        'Mana'        => $row['Mana'],
        'MaxMana'     => $row['MaxMana'],
        'ManaPercent' => $manaPercent,
        'ManaColor'   => getBarColor($manaPercent),

        'Power'       => $row['Power'],
        'MaxPower'    => $row['MaxPower'],
        'PowerPercent'=> $powerPercent,
        'PowerColor'  => getBarColor($powerPercent),
    ];
}

echo json_encode($chars);
