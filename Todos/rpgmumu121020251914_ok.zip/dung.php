<?php
session_start();
include "db.php";
include "check_ban.php";

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// ==========================
// Carrega personagem
// ==========================
$stmt = sqlsrv_query($conn, "SELECT TOP 1 * FROM dbo.Characters WHERE PlayerID = ?", [$playerID]);
if($stmt === false) die(print_r(sqlsrv_errors(), true));

$char = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
if(!$char){
    die("Você precisa ter pelo menos um personagem. <a href='dashboard.php'>⬅ Voltar</a>");
}

// Inicializa loot
if(!isset($_SESSION['loot'])) $_SESSION['loot'] = [];

// ==========================
// Função para carregar inimigos
// ==========================
function carregarInimigos() {
    global $conn;
    $stmt = sqlsrv_query($conn, "SELECT EnemyID, Name, HP, MaxHP, XP, Loot, Mana, MaxMana, Level FROM dbo.Enemies");
    if($stmt === false) die(print_r(sqlsrv_errors(), true));

    $enemies = [];
    while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)){
        $row['HP'] = $row['HP'] ?? 0;
        $row['MaxHP'] = $row['MaxHP'] ?? $row['HP'];
        $row['Mana'] = $row['Mana'] ?? 0;
        $row['MaxMana'] = $row['MaxMana'] ?? $row['Mana'];
        $row['XP'] = $row['XP'] ?? 0;

        // converte loot de string JSON para array, se aplicável
        if(isset($row['Loot']) && is_string($row['Loot'])){
            $row['Loot'] = json_decode($row['Loot'], true) ?: [];
        } elseif(!isset($row['Loot'])) {
            $row['Loot'] = [];
        }

        $enemies[] = $row;
    }
    return $enemies;
}

// ==========================
// Inicializa dungeon
// ==========================
if(!isset($_SESSION['dungeon']) || !is_array($_SESSION['dungeon']) || ($_SESSION['dungeon']['playerID'] ?? 0) != $playerID){
    $_SESSION['dungeon'] = [
        'playerID' => $playerID,
        'current' => 0,
        'enemies' => carregarInimigos(),
        'fim' => false,
        'char' => $char
    ];
}

$dungeon = &$_SESSION['dungeon'];
$enemy = &$dungeon['enemies'][$dungeon['current']] ?? null;
$hpZerado = ($char['HP'] ?? 0) <= 0;
$fim = $dungeon['fim'] ?? false;

// ==========================
// Carrega inventário do jogador
// ==========================
$stmtItens = sqlsrv_query($conn, "SELECT ItemName, Quantidade FROM dbo.Inventory WHERE PlayerID = ?", [$playerID]);
$itens = [];
if($stmtItens){
    while($rowItem = sqlsrv_fetch_array($stmtItens, SQLSRV_FETCH_ASSOC)){
        $itens[] = $rowItem;
    }
}

// ==========================
// Bônus de loot
// ==========================
$bonusDisplay = [];
$bonusDisplay[] = "Level: +".($char['Level'])."% de chance extra de loot";

if(isset($_SESSION['itens'])){
    foreach($_SESSION['itens'] as $item => $qtd){
        if($qtd > 0) $bonusDisplay[] = "Item ativo: $item";
    }
}

// Eventos ativos
$hoje = date('Y-m-d');
$stmtEventos = sqlsrv_query($conn, "SELECT EventName FROM dbo.LootEvents WHERE ? BETWEEN StartDate AND EndDate", [$hoje]);
if($stmtEventos){
    while($event = sqlsrv_fetch_array($stmtEventos, SQLSRV_FETCH_ASSOC)){
        $bonusDisplay[] = "Evento ativo: {$event['EventName']}";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Dungeon - RPGMumu</title>
<style>
body { font-family: Arial, sans-serif; background:#1c1c1c; color:#fff; text-align:center; }
.cards-container { display:flex; justify-content:center; flex-wrap:wrap; gap:20px; margin-top:20px; }
.card { background:#2c2c2c; padding:15px; border-radius:10px; width:250px; box-shadow:0 0 10px #000; }
.progress { background:#555; border-radius:5px; overflow:hidden; height:20px; margin-bottom:5px; }
.bar { height:100%; transition:width 0.5s, background 0.5s; }
.hp-low { box-shadow:0 0 10px red inset; }
button { cursor:pointer; }
#voltar { display:none; margin-top:20px; padding:10px 15px; background:#3498db; color:#fff; border:none; border-radius:5px; text-decoration:none; }
#voltar.pulsar { animation: pulsar 1s infinite; }
@keyframes pulsar { 0%,100%{transform:scale(1);}50%{transform:scale(1.1);} }
#log { max-height:300px; overflow:auto; text-align:left; margin:20px auto; width:90%; background:#222; padding:10px; border-radius:5px; }
</style>
</head>
<body>

<nav style="display:flex; justify-content:space-between; align-items:center; margin:20px;">
    <form method="post" style="margin:0; display:flex; gap:10px;">
        <button type="submit" class="btn" name="refresh">🔄 Atualizar</button>
    </form>
</nav>

<a id="voltar" href="dashboard.php">⬅️ Voltar</a>
<h1>🗡️ Masmorra - <?= htmlspecialchars($char['Name']) ?></h1>

<?php if($hpZerado): ?>
<p style="color:red; font-size:1.3em;">💀 Você morreu! Dungeon encerrada.</p>
<?php elseif($fim): ?>
<p style="color:yellow; font-size:1.3em;">🏁 Parabéns! Todos os inimigos foram derrotados!</p>
<?php endif; ?>

<div class="cards-container">
<!-- Player -->
<div class="card">
<h3><?= htmlspecialchars($char['Name']) ?></h3>
<p>Level: <?= $char['Level'] ?> | XP: <?= $char['Exp'] ?></p>

<div class="progress"><div class="bar hp player-bar" style="width:<?= ($char['MaxHP']>0?round($char['HP']/$char['MaxHP']*100):0) ?>%"></div></div>
<p>HP: <?= $char['HP'] ?> / <?= $char['MaxHP'] ?></p>

<div class="progress"><div class="bar mp mana-bar" style="width:<?= ($char['MaxMana']>0?round($char['Mana']/$char['MaxMana']*100):0) ?>%"></div></div>
<p>Mana: <?= $char['Mana'] ?> / <?= $char['MaxMana'] ?></p>

<div class="progress"><div class="bar xp-bar" style="width:<?= ($char['Level']*50>0?round($char['Exp']/($char['Level']*50)*100):0) ?>%"></div></div>
<p>XP: <?= $char['Exp'] ?> / <?= $char['Level']*50 ?></p>

<div class="progress"><div class="bar power-bar" style="width:<?= ($char['MaxPower']>0?round($char['Power']/$char['MaxPower']*100):0) ?>%"></div></div>
<p>Poder: <?= $char['Power'] ?> / <?= $char['MaxPower'] ?></p>
</div>

<!-- Enemy -->
<?php if($enemy): ?>
<div class="card">
<h3><?= htmlspecialchars($enemy['Name']) ?></h3>
<p>Level: <?= $enemy['Level'] ?> | XP: <?= $enemy['XP'] ?></p>

<div class="progress"><div class="bar hp enemy-bar" style="width:<?= ($enemy['MaxHP']>0?round($enemy['HP']/$enemy['MaxHP']*100):0) ?>%"></div></div>
<p>HP: <?= $enemy['HP'] ?> / <?= $enemy['MaxHP'] ?></p>

<div class="progress"><div class="bar mp enemy-mana-bar" style="width:<?= ($enemy['MaxMana']>0?round($enemy['Mana']/$enemy['MaxMana']*100):0) ?>%"></div></div>
<p>Mana: <?= $enemy['Mana'] ?> / <?= $enemy['MaxMana'] ?></p>
</div>
<?php endif; ?>
</div>

<h3>📜 Historico de Combate</h3>
<div id="log"></div>

<script>
function getGradient(value, type){
    value = Math.max(0, Math.min(1, value));
    if(type==='hp'){ if(value>0.5) return 'linear-gradient(90deg, #2ecc71, #27ae60)'; if(value>0.25) return 'linear-gradient(90deg, #f1c40f, #e67e22)'; return 'linear-gradient(90deg, #e74c3c, #c0392b)'; }
    if(type==='mana') return 'linear-gradient(90deg, #3498db, #2980b9)';
    if(type==='xp') return 'linear-gradient(90deg, #9b59b6, #8e44ad)';
    if(type==='power') return 'linear-gradient(90deg, #f1c40f, #e67e22)';
    return '#555';
}

function safePercent(value, max){ value = value ?? 0; max = max ?? 1; return max>0 ? (value/max) : 0; }

function atualizarBarras(char, enemy=null){
    const hpBar = document.querySelector(".player-bar");
    const manaBar = document.querySelector(".mana-bar");
    const xpBar = document.querySelector(".xp-bar");
    const powerBar = document.querySelector(".power-bar");

    const hpPercent = safePercent(char.HP, char.MaxHP);
    hpBar.style.width = (hpPercent*100)+'%';
    hpBar.style.background = getGradient(hpPercent,'hp');
    hpBar.classList.toggle('hp-low', hpPercent <= 0.25);

    const manaPercent = safePercent(char.Mana, char.MaxMana);
    manaBar.style.width = (manaPercent*100)+'%';
    manaBar.style.background = getGradient(manaPercent,'mana');

    const xpPercent = safePercent(char.Exp, char.Level*50);
    xpBar.style.width = (xpPercent*100)+'%';
    xpBar.style.background = getGradient(xpPercent,'xp');

    if(powerBar){
        const powerPercent = safePercent(char.Power, char.MaxPower);
        powerBar.style.width = (powerPercent*100)+'%';
        powerBar.style.background = getGradient(powerPercent,'power');
    }

    if(enemy){
        const enemyHPBar = document.querySelector(".enemy-bar");
        const enemyManaBar = document.querySelector(".enemy-mana-bar");

        const enemyHPPercent = safePercent(enemy.HP, enemy.MaxHP);
        if(enemyHPBar){
            enemyHPBar.style.width = (enemyHPPercent*100)+'%';
            enemyHPBar.style.background = getGradient(enemyHPPercent,'hp');
            enemyHPBar.classList.toggle('hp-low', enemyHPPercent <= 0.25);
        }

        const enemyManaPercent = safePercent(enemy.Mana, enemy.MaxMana);
        if(enemyManaBar){
            enemyManaBar.style.width = (enemyManaPercent*100)+'%';
            enemyManaBar.style.background = getGradient(enemyManaPercent,'mana');
        }
    }
}

function atualizarDungeon(){
    fetch('turno.php')
    .then(r => r.json())
    .then(data => {
        if(!data.char) return;

        atualizarBarras(data.char, data.enemy);

        const logDiv = document.getElementById('log');
        if(data.log && Array.isArray(data.log) && data.log.length>0){
            data.log.forEach(msg => {
                const p = document.createElement('div');
                p.innerHTML = msg;
                logDiv.appendChild(p);
            });
            logDiv.scrollTop = logDiv.scrollHeight;
        }

        const btnVoltar = document.getElementById('voltar');
        if(data.fim || data.char.HP <=0){
            btnVoltar.style.display='inline-block';
            btnVoltar.classList.add('pulsar');
        } else {
            setTimeout(atualizarDungeon,1200);
        }
    })
    .catch(err => console.error('Erro ao atualizar dungeon:', err));
}

<?php if(!$hpZerado && !$fim): ?>
atualizarDungeon();
<?php else: ?>
document.getElementById("voltar").style.display="inline-block";
<?php endif; ?>
</script>
</body>
</html>
