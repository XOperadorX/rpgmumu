<?php
session_start();
include "db.php";
include "check_ban.php";

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// Pega personagem
$stmt = @sqlsrv_query($conn, "SELECT TOP 1 * FROM Characters WHERE PlayerID=?", [$playerID]);
$char = $stmt ? sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC) : false;
if(!$char){
    die("Você precisa ter pelo menos um personagem. <a href='dashboard.php'>⬅ Voltar</a>");
}

// Inicializa loot do jogador se não existir
if(!isset($_SESSION['loot'])) $_SESSION['loot'] = [];

// ==========================
// Função para carregar inimigos
// ==========================
function carregarInimigos() {
    global $conn;

    $enemies = [];
    $sql = "SELECT EnemyID, Name, HP, MaxHP, XP, Loot, Mana, MaxMana, Level FROM Enemies";
    $stmt = @sqlsrv_query($conn, $sql);
    if($stmt){
        while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)){
            $row['MaxHP'] = $row['MaxHP'] ?? $row['HP'];
            $row['MaxMana'] = $row['MaxMana'] ?? $row['Mana'] ?? 0;
            $row['XP'] = $row['XP'] ?? 0;
            $enemies[] = $row;
        }
    }
    return $enemies;
}

// ==========================
// Inicializa dungeon
// ==========================
if(!isset($_SESSION['dungeon']) || $_SESSION['dungeon']['playerID'] != $playerID){
    $_SESSION['dungeon'] = [
        'playerID' => $playerID,
        'current' => 0,
        'enemies' => carregarInimigos(),
        'fim' => false
    ];
}

$dungeon = &$_SESSION['dungeon'];
$enemy = &$dungeon['enemies'][$dungeon['current']] ?? null;
$hpZerado = $char['HP'] <= 0;
$fim = $dungeon['fim'] ?? false;

// ==========================
// Inventário do jogador
// ==========================
$itens = [];
$stmtItens = @sqlsrv_query($conn, "SELECT ItemName, Quantidade FROM Inventory WHERE PlayerID = ?", [$playerID]);
if($stmtItens){
    while($rowItem = sqlsrv_fetch_array($stmtItens, SQLSRV_FETCH_ASSOC)){
        $itens[] = $rowItem;
    }
}

// ==========================
// Bônus de loot
// ==========================
$bonusDisplay = [];
$bonusDisplay[] = "Level: +".($char['Level'])."% de chance extra de loot";

if(isset($_SESSION['itens'])){
    foreach($_SESSION['itens'] as $item => $qtd){
        if($qtd > 0) $bonusDisplay[] = "Item ativo: $item";
    }
}

// Eventos ativos
$hoje = date('Y-m-d');
$stmtEventos = @sqlsrv_query($conn, "SELECT EventName FROM LootEvents WHERE ? BETWEEN StartDate AND EndDate", [$hoje]);
if($stmtEventos){
    while($event = sqlsrv_fetch_array($stmtEventos, SQLSRV_FETCH_ASSOC)){
        $bonusDisplay[] = "Evento ativo: {$event['EventName']}";
    }
}

// ==========================
// Função para processar loot de inimigo morto
// ==========================
$lootDrop = [];
if($enemy && $enemy['HP'] <= 0){
    // Pega loot do inimigo
    $stmtLoot = sqlsrv_query($conn, "SELECT ItemName FROM EnemyLoot WHERE EnemyID = ?", [$enemy['EnemyID']]);
    if($stmtLoot){
        while($row = sqlsrv_fetch_array($stmtLoot, SQLSRV_FETCH_ASSOC)){
            $lootDrop[] = $row['ItemName'];
            $_SESSION['loot'][] = $row['ItemName']; // adiciona ao loot do jogador
        }
    }
    // Avança para próximo inimigo
    $dungeon['current']++;
    $enemy = $dungeon['enemies'][$dungeon['current']] ?? null;
    if(!$enemy){
        $dungeon['fim'] = true;
        $fim = true;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Dungeon - RPGMumu</title>
<style>
body { font-family: Arial, sans-serif; background:#1c1c1c; color:#fff; text-align:center; }
.cards-container { display:flex; justify-content:center; flex-wrap:wrap; gap:20px; margin-top:20px; }
.card { background:#2c2c2c; padding:15px; border-radius:10px; width:250px; box-shadow:0 0 10px #000; }
.progress { background:#555; border-radius:5px; overflow:hidden; height:20px; margin-bottom:5px; }
.bar { height:100%; transition:width 0.5s, background 0.5s; }
.hp-low { box-shadow:0 0 10px red inset; }
button { cursor:pointer; }
#voltar { display:none; margin-top:20px; padding:10px 15px; background:#3498db; color:#fff; border:none; border-radius:5px; text-decoration:none; }
#voltar.pulsar { animation: pulsar 1s infinite; }
@keyframes pulsar { 0%,100%{transform:scale(1);}50%{transform:scale(1.1);} }
</style>
</head>
<body>

<a id="voltar" href="dashboard.php">⬅️ Voltar</a>
<h1>🗡️ Masmorra - <?= htmlspecialchars($char['Name']) ?></h1>

<?php if($hpZerado): ?>
<p style="color:red; font-size:1.3em;">💀 Você morreu! Dungeon encerrada.</p>
<?php elseif($fim): ?>
<p style="color:yellow; font-size:1.3em;">🏁 Parabéns! Todos os inimigos foram derrotados!</p>
<?php endif; ?>

<div class="cards-container">
<!-- Player -->
<div class="card">
<h3><?= htmlspecialchars($char['Name']) ?></h3>
<p>Level: <?= $char['Level'] ?> | XP: <?= $char['Exp'] ?></p>

<div class="progress"><div class="bar hp player-bar" style="width:<?= round($char['HP']/$char['MaxHP']*100) ?>%"></div></div>
<p>HP: <?= $char['HP'] ?> / <?= $char['MaxHP'] ?></p>

<div class="progress"><div class="bar mp mana-bar" style="width:<?= round($char['Mana']/$char['MaxMana']*100) ?>%"></div></div>
<p>Mana: <?= $char['Mana'] ?> / <?= $char['MaxMana'] ?></p>

<div class="progress"><div class="bar xp-bar" style="width:<?= round($char['Exp']/($char['Level']*50)*100) ?>%"></div></div>
<p>XP: <?= $char['Exp'] ?> / <?= $char['Level']*50 ?></p>

<div class="progress"><div class="bar power-bar" style="width:<?= round($char['Power']/$char['MaxPower']*100) ?>%"></div></div>
<p>Poder: <?= $char['Power'] ?> / <?= $char['MaxPower'] ?></p>
</div>

<!-- Enemy -->
<?php if($enemy): ?>
<div class="card">
<h3><?= htmlspecialchars($enemy['Name']) ?></h3>
<p>Level: <?= $enemy['Level'] ?> | XP: <?= $enemy['XP'] ?></p>

<div class="progress"><div class="bar hp enemy-bar" style="width:<?= round($enemy['HP']/$enemy['MaxHP']*100) ?>%"></div></div>
<p>HP: <?= $enemy['HP'] ?> / <?= $enemy['MaxHP'] ?></p>

<div class="progress"><div class="bar mp enemy-mana-bar" style="width:<?= round($enemy['Mana']/$enemy['MaxMana']*100) ?>%"></div></div>
<p>Mana: <?= $enemy['Mana'] ?> / <?= $enemy['MaxMana'] ?></p>
</div>
<?php endif; ?>
</div>

<!-- Loot Drop -->
<?php if(!empty($lootDrop)): ?>
<h3>🎁 Loot Recebido</h3>
<ul>
<?php foreach($lootDrop as $item): ?>
<li><?= htmlspecialchars($item) ?></li>
<?php endforeach; ?>
</ul>
<?php endif; ?>

<h3>📦 Inventário</h3>
<?php if(!empty($itens)): ?>
<table border="1" cellpadding="5" style="margin:auto;">
<tr><th>Nome</th><th>Quantidade</th><th>Ação</th></tr>
<?php foreach($itens as $i): ?>
<tr>
<td><?= htmlspecialchars($i['ItemName']) ?></td>
<td><?= $i['Quantidade'] ?></td>
<td>
<form method="post">
<input type="hidden" name="ItemName" value="<?= htmlspecialchars($i['ItemName']) ?>">
<input type="number" name="Quantidade" value="1" min="1" max="<?= $i['Quantidade'] ?>" style="width:50px;">
<button type="submit" name="vender">Vender</button>
</form>
</td>
</tr>
<?php endforeach; ?>
</table>
<?php else: ?>
<p>Você não possui nenhum item.</p>
<?php endif; ?>

<h3>🎁 Bônus de Loot Ativos</h3>
<div id="bonus-log" style="margin-bottom:20px; color:#f1c40f;"></div>

<script>
// Mostra bônus de loot
let bonusLogDiv = document.getElementById("bonus-log");
bonusLogDiv.innerHTML = <?= json_encode(!empty($bonusDisplay) ? implode("<br>", $bonusDisplay) : "Nenhum bônus ativo"); ?>;

// Função gradiente
function getGradient(value, type){
    if(type==='hp'){if(value>0.5) return 'linear-gradient(90deg, #2ecc71, #27ae60)'; if(value>0.25) return 'linear-gradient(90deg, #f1c40f, #e67e22)'; return 'linear-gradient(90deg, #e74c3c, #c0392b)';}
    if(type==='mana') return 'linear-gradient(90deg, #3498db, #2980b9)';
    if(type==='xp') return 'linear-gradient(90deg, #9b59b6, #8e44ad)';
    if(type==='power') return 'linear-gradient(90deg, #f1c40f, #e67e22)';
}

// Atualiza barras
function atualizarBarras(char, enemy=null){
    const hpBar = document.querySelector(".player-bar");
    const manaBar = document.querySelector(".mana-bar");
    const xpBar = document.querySelector(".xp-bar");
    const powerBar = document.querySelector(".power-bar");

    hpBar.style.width = (char.HP/char.MaxHP*100)+'%';
    hpBar.style.background = getGradient(char.HP/char.MaxHP,'hp');
    hpBar.classList.toggle('hp-low', char.HP/char.MaxHP <=0.25);

    manaBar.style.width = (char.Mana/char.MaxMana*100)+'%';
    manaBar.style.background = getGradient(char.Mana/char.MaxMana,'mana');

    xpBar.style.width = (char.Exp/(char.Level*50)*100)+'%';
    xpBar.style.background = getGradient(char.Exp/(char.Level*50),'xp');

    if(powerBar){
        powerBar.style.width = (char.Power/char.MaxPower*100)+'%';
        powerBar.style.background = getGradient(char.Power/char.MaxPower,'power');
    }

    if(enemy){
        const enemyHPBar = document.querySelector(".enemy-bar");
        const enemyManaBar = document.querySelector(".enemy-mana-bar");
        if(enemyHPBar){
            enemyHPBar.style.width = (enemy.HP/enemy.MaxHP*100)+'%';
            enemyHPBar.style.background = getGradient(enemy.HP/enemy.MaxHP,'hp');
            enemyHPBar.classList.toggle('hp-low', enemy.HP/enemy.MaxHP<=0.25);
        }
        if(enemyManaBar){
            enemyManaBar.style.width = (enemy.Mana/enemy.MaxMana*100)+'%';
            enemyManaBar.style.background = getGradient(enemy.Mana/enemy.MaxMana,'mana');
        }
    }
}

// Atualiza dungeon via AJAX
function atualizarDungeon(){
    fetch('turno.php')
    .then(r=>r.json())
    .then(data=>{
        atualizarBarras(data.char, data.enemy);
        const logDiv = document.getElementById('log');
        if(data.log && data.log.length>0){
            logDiv.innerHTML += data.log.map(l=>'<div>'+l+'</div>').join('');
            logDiv.scrollTop = logDiv.scrollHeight;
        }
        if(data.fim){
            const btn = document.getElementById('voltar');
            btn.style.display='inline-block';
            btn.classList.add('pulsar');
        } else if(data.char.HP>0){
            setTimeout(atualizarDungeon,1200);
        }
    })
    .catch(err=>console.error(err));
}

<?php if(!$hpZerado && !$fim): ?>
atualizarDungeon();
<?php else: ?>
document.getElementById("voltar").style.display="inline-block";
<?php endif; ?>
</script>
</body>
</html>
