<?php
if (!isset($conn)) {
    include "db.php"; // Garante que a conexão está disponível
}

if (!isset($_SESSION)) {
    session_start();
}

$playerID = $_SESSION['PlayerID'] ?? null;

if ($playerID) {
    $stmt = sqlsrv_query($conn, "SELECT Banido FROM Players WHERE PlayerID = ?", [$playerID]);
    if ($stmt && $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        if (!empty($row['Banido']) && $row['Banido'] == 1) {
            die("⛔ Você está banido e não pode acessar o jogo.");
        }
    }
}


// ==== BUSCA PERSONAGENS ====
$sql = "SELECT TOP 1000 [CharID], [PlayerID], [Name], [Class], [Level], [Exp], [HP], [Mana], [MaxHP], [MaxMana], [Power]
        FROM [MumuDB].[dbo].[Characters]
        WHERE [PlayerID] = ?";
$stmt = sqlsrv_query($conn, $sql, [$playerID]);

// ==== BUSCA MOEDAS E DATA DE RECARGA ====
$sqlInfo = "SELECT [MoedaMumu], [RecargaExpiraEm] FROM [MumuDB].[dbo].[Players] WHERE [PlayerID] = ?";
$stmtInfo = sqlsrv_query($conn, $sqlInfo, [$playerID]);
$info = sqlsrv_fetch_array($stmtInfo, SQLSRV_FETCH_ASSOC);

$moedas = $info['MoedaMumu'] ?? 0;
$recargaExpira = $info['RecargaExpiraEm'] ?? null;

$recargaAtiva = false;
$expiraTimestamp = 0;

if ($recargaExpira) {
    $agora = new DateTime();

    // Garante compatibilidade: se for objeto, usa direto; se for string, converte
    if ($recargaExpira instanceof DateTime) {
        $expira = $recargaExpira;
    } else {
        $expira = new DateTime($recargaExpira);
    }

    if ($agora < $expira) {
        $recargaAtiva = true;
        $expiraFormatada = $expira->format('d/m/Y H:i');
        $expiraTimestamp = $expira->getTimestamp();
    }
}

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Personagens</title>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
<style>
/* === BODY === */
body {
    background-color: #000; /* fundo escuro */
    color: #fff; 
    font-family: 'Roboto', sans-serif;
    margin: 0;
    padding: 20px;
}

/* === HEADINGS === */
h1, h2 {
    text-align: center;
    color: #ffd700;
    text-shadow: 0 0 8px #ffd700;
}

/* === MOEDAS === */
.moedas {
    font-size: 1.2em;
    color: #ff9900;
    font-weight: bold;
    text-align: center;
    text-shadow: 0 0 5px #ffcc33;
}

/* === RECARGA ATIVA === */
.recarga-ativa {
    background: #00cc66; /* fundo verde */
    color: #000000; /* cor do texto, ajustei para preto para melhor contraste */
    padding: 6px 12px;
    margin: 10px auto;
    border-radius: 6px;
    border: 1px solid #00ffea; /* mantém a borda azul neon */
    display: inline-block;
    font-family: 'Orbitron', sans-serif;
    font-size: 13px;
    text-align: center;
    font-weight: bold;
    text-shadow: 0 0 5px #00ffea, 0 0 10px #00ffea; /* mantém efeito futurista */
    box-shadow: 0 0 10px #00ffea;
    animation: brilho 2s infinite alternate;
}

@keyframes brilho {
    from { box-shadow: 0 0 5px #00ffea; }
    to { box-shadow: 0 0 20px #00ffea; }
}


/* === COUNTDOWN === */
.countdown {
    font-size: 1.1em;
    font-weight: bold;
    color: #000000;
    text-shadow: 0 0 5px #00ffea;
}

/* === CARDS DE PERSONAGEM === */
.cards {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px;
    margin-top: 20px;
}

.card {
    background: #111;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0,255,255,0.2);
    padding: 20px;
    width: 280px;
    transition: transform 0.3s, box-shadow 0.3s;
    color: #fff;
    text-align: center;
    font-family: 'Orbitron', sans-serif;
}
.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 6px 20px rgba(0,255,255,0.4);
}
.card h3 {
    margin-top: 0;
    color: #00ffee;
    text-shadow: 0 0 5px #00ffea;
}

/* === STATS E INVENTÁRIO === */
.stats, .inventory {
    margin-top: 10px;
}
.stats div, .inventory div {
    margin: 5px 0;
}

/* === BARRAS DE STATUS === */
.hp-bar-container, .mana-bar-container, .xp-bar-container, .power-bar-container {
    background: #222;
    border-radius: 10px;
    overflow: hidden;
    height: 20px;
    margin-top: 5px;
    position: relative;
}

.hp-bar, .mana-bar, .xp-bar, .power-bar {
    height: 100%;
    transition: width 0.5s, background 0.5s;
}
.hp-bar { background: #4caf50; }
.hp-bar.warn { background: #ff9800; }
.hp-bar.low { background: #f44336; }

.mana-bar { background: #3498db; }
.mana-bar.low { background: #2980b9; }

.xp-bar { background: purple; }
.power-bar { background: #ff4500; }
.power-bar.low { background: #ff6347; }
.power-bar.medium { background: #ff8c00; }
.power-bar.high { background: #ffd700; }

.stat-text {
    position: absolute;
    width: 100%;
    text-align: center;
    top: 0;
    left: 0;
    font-weight: bold;
    color: #fff;
    font-size: 0.9em;
    line-height: 20px;
    text-shadow: 0 0 3px #00ffea;
}

/* === BOTÕES === */
.btn {
    display: inline-block;
    padding: 10px 20px;
    margin: 10px 5px;
    text-decoration: none;
    color: #fff;
    border-radius: 8px;
    background: #222;
    transition: all 0.3s;
    font-family: 'Orbitron', sans-serif;
}
.btn:hover {
    background: #333;
}
.btn.delete {
    background: #e53935;
    box-shadow: 0 0 8px #ff4444;
}

/* === BOTÃO DE RECARGA FUTURISTA === */
.btn-recarga {
    background: linear-gradient(90deg, #00cc66, #00ff99);
    color: #fff;
    font-weight: bold;
    padding: 6px 14px;
    border-radius: 8px;
    text-decoration: none;
    box-shadow: 0 0 10px #00ff99;
    display: inline-block;
    transition: all 0.25s ease;
    font-size: 14px;
    letter-spacing: 0.5px;
    text-shadow: 0 0 3px #008844;
    border: 1px solid rgba(0, 255, 153, 0.4);
}
.btn-recarga:hover {
    background: linear-gradient(90deg, #00e676, #00ffaa);
    box-shadow: 0 0 15px #00ffaa, 0 0 5px #00cc66 inset;
    transform: scale(1.05);
}
.btn-recarga:active {
    transform: scale(0.97);
    box-shadow: 0 0 5px #00cc66;
}
.status-panel .btn-recarga {
    margin-top: 10px;
    text-align: center;
}

/* === RESPONSIVO === */
@media(max-width:768px) { .card { width: 45%; } }
@media(max-width:480px) { .card { width: 90%; } }


</style>
</head>
<body>

<nav style="text-align:left;">
    <a href="dashboard.php" class="btn">⬅ Voltar</a>
</nav>

<h1>👥 Seus Personagens</h1>
<h2>💰 Moedas Mumu: <span class="moedas"><?= $moedas ?></span></h2>



<div class="cards" id="cards-container">
<?php while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)): ?>
    <div class="card">
        <h3><?= htmlspecialchars($row['Name']) ?> (<?= htmlspecialchars($row['Class']) ?>)</h3>

        <div class="stats">
            <div>Level: <span id="level-<?= $row['CharID'] ?>"><?= $row['Level'] ?></span></div>

            <div>Poder:</div>
            <div class="power-bar-container">
                <div id="power-<?= $row['CharID'] ?>" class="power-bar" style="width:<?= ($row['Power']??0) ?>%"></div>
                <div class="stat-text" id="powertext-<?= $row['CharID'] ?>"><?= $row['Power']??0 ?> / 100</div>
            </div>
        </div>

        <div>HP:</div>
        <div class="hp-bar-container">
            <div id="hp-<?= $row['CharID'] ?>" class="hp-bar" style="width:<?= ($row['MaxHP']>0?round($row['HP']/$row['MaxHP']*100):0) ?>%"></div>
            <div class="stat-text" id="hptext-<?= $row['CharID'] ?>"><?= $row['HP'] ?> / <?= $row['MaxHP'] ?></div>
        </div>

        <div>Mana:</div>
        <div class="mana-bar-container">
            <div id="mana-<?= $row['CharID'] ?>" class="mana-bar" style="width:<?= ($row['MaxMana']>0?round($row['Mana']/$row['MaxMana']*100):0) ?>%"></div>
            <div class="stat-text" id="manatext-<?= $row['CharID'] ?>"><?= $row['Mana'] ?> / <?= $row['MaxMana'] ?></div>
        </div>

        <div>XP:</div>
        <div class="xp-bar-container">
            <div id="xp-<?= $row['CharID'] ?>" class="xp-bar" style="width:<?= ($row['Level']>0 ? min(100, round(($row['Exp']/($row['Level']*50))*100)) : 0) ?>%"></div>
            <div class="stat-text" id="xptext-<?= $row['CharID'] ?>"><?= $row['Exp'] ?> / <?= $row['Level']*50 ?></div>
        </div>

        <div style="text-align:center;margin-top:20px;">
            <a href="del_personagem.php?CharID=<?= $row['CharID'] ?>" class="btn delete">🗑️ Excluir</a>
        </div>
		

		<?php if ($recargaAtiva): ?>
		<div class="recarga-ativa">
			💫 Recarga total ativa até <b><?= $expiraFormatada ?></b><br>
			<span class="countdown" id="contador"></span>
		</div>

    </div>
	


<style>

</style>

<!-- Fonte futurista -->
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500&display=swap" rel="stylesheet">


<?php else: ?>
    <div style="text-align:center;">
<!-- Botão futurista padronizado -->
<a href="ativar_recarga.php" class="btn-recarga">
    ⚡ Ativar Recarga Total (7 Dias)
</a>

<style>

</style>



    </div>
<?php endif; ?>

	
<?php endwhile; ?>
</div>

<script>
// Atualiza HP, Mana, XP, Level e Poder via AJAX
function atualizarStatus() {
    fetch('status_personagem.php')
    .then(res => res.json())
    .then(data => {
        data.forEach(c => {
            let hpPerc = Math.max(0, Math.min(100, Math.round(c.HP / c.MaxHP * 100)));
            let manaPerc = Math.max(0, Math.min(100, Math.round(c.Mana / c.MaxMana * 100)));
            let xpPerc = Math.max(0, Math.min(100, Math.round((c.Exp/(c.Level*50))*100)));
            let powerPerc = Math.max(0, Math.min(100, c.Power));

            let hpElem = document.getElementById('hp-' + c.CharID);
            let manaElem = document.getElementById('mana-' + c.CharID);
            let xpElem = document.getElementById('xp-' + c.CharID);
            let powerElem = document.getElementById('power-' + c.CharID);

            if(hpElem){
                hpElem.style.width = hpPerc + '%';
                hpElem.className = (hpPerc>60?'hp-bar':(hpPerc>30?'hp-bar warn':'hp-bar low'));
                document.getElementById('hptext-' + c.CharID).innerText = c.HP + ' / ' + c.MaxHP;
            }

            if(manaElem){
                manaElem.style.width = manaPerc + '%';
                manaElem.className = (manaPerc>30?'mana-bar':'mana-bar low');
                document.getElementById('manatext-' + c.CharID).innerText = c.Mana + ' / ' + c.MaxMana;
            }

            if(xpElem){
                xpElem.style.width = xpPerc + '%';
                document.getElementById('xptext-' + c.CharID).innerText = c.Exp + ' / ' + (c.Level*50);
            }

            if(powerElem){
                powerElem.style.width = powerPerc + '%';
                if(powerPerc>70) powerElem.className='power-bar high';
                else if(powerPerc>30) powerElem.className='power-bar medium';
                else powerElem.className='power-bar low';
                document.getElementById('powertext-' + c.CharID).innerText = c.Power + ' / 100';
            }

            document.getElementById('level-' + c.CharID).innerText = c.Level;
        });
    })
    .catch(err => console.error(err));
}
setInterval(atualizarStatus, 1500);

// === CONTADOR REGRESSIVO DA RECARGA ===
<?php if ($recargaAtiva): ?>
let expiraEm = <?= $expiraTimestamp ?> * 1000;

function atualizarContador() {
    const agora = new Date().getTime();
    const distancia = expiraEm - agora;

    if (distancia <= 0) {
        document.getElementById('contador').innerText = "⏳ Recarga expirada!";
        clearInterval(contadorInterval);
        return;
    }

    const dias = Math.floor(distancia / (1000 * 60 * 60 * 24));
    const horas = Math.floor((distancia % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutos = Math.floor((distancia % (1000 * 60 * 60)) / (1000 * 60));
    const segundos = Math.floor((distancia % (1000 * 60)) / 1000);

    document.getElementById('contador').innerText =
        `⏱️ ${dias}d ${horas}h ${minutos}m ${segundos}s restantes`;
}

const contadorInterval = setInterval(atualizarContador, 1000);
atualizarContador();
<?php endif; ?>
</script>

</body>
</html>

