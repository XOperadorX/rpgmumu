<?php
session_start();
include "db.php";
include "check_ban.php"; // Protege a página

if (!isset($_SESSION['PlayerID'])) {
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// Dados do jogador
$stmtPlayer = sqlsrv_query($conn, "SELECT TOP 1 * FROM Players WHERE PlayerID=?", [$playerID]);
$player = ($stmtPlayer && $row = sqlsrv_fetch_array($stmtPlayer, SQLSRV_FETCH_ASSOC)) ? $row : [];

// Moedas Mumu
$moeda = $player['MoedaMumu'] ?? 0;

// Personagens
$personagens = [];
$stmtChar = sqlsrv_query($conn, "SELECT TOP 1000 [CharID], [PlayerID], [Name], [Class], [Level], [Exp], [HP], [Mana], [MaxHP], [MaxMana], [Power], [MaxPower] FROM Characters WHERE PlayerID=?", [$playerID]);
if ($stmtChar && sqlsrv_has_rows($stmtChar)) {
    while ($row = sqlsrv_fetch_array($stmtChar, SQLSRV_FETCH_ASSOC)) {
        $personagens[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Dashboard - Mumu RPG</title>
<style>
/* RESET & BODY */
body {
    background-color: black;
    color: white;
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 20px;
}
.container { max-width: 1200px; margin: auto; padding: 20px; }

/* TOP BAR */
.top-bar {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    margin-bottom: 20px;
    gap: 10px;
}
.top-bar a, .top-bar button {
    display: inline-block;
    padding: 10px 20px;
    border-radius: 8px;
    text-decoration: none;
    color: #fff;
    background: #333;
    transition: 0.3s;
    border: none;
    cursor: pointer;
}
.top-bar a:hover, .top-bar button:hover {
    background: #ffcc00;
    color: #000;
}

/* BLOCO JOGADOR */
.jogador-info {
    background: #333;
    color: #ffcc00;
    padding: 15px;
    border-radius: 10px;
    margin-bottom: 20px;
    text-align: center;
    max-width: 800px;
    margin-left: auto;
    margin-right: auto;
}
.jogador-info h1 { margin-top:0; font-size:1.8em; }
.jogador-info p { margin:5px 0; }

/* DASHBOARD PERSONAGENS */
.dashboard-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px;
}
.character-card {
    background: #333;
    border: 2px solid #555;
    border-radius: 10px;
    padding: 15px;
    width: 220px;
    text-align: center;
    transition: border-color 0.3s, box-shadow 0.3s;
    color: #fff;
}
.character-card:hover {
    border-color: #ffcc00;
    box-shadow: 0 0 15px #ffcc00;
}
.character-card h3 { color: #ffcc00; margin-bottom: 5px; }
.character-card p { margin: 5px 0; }

/* BARRAS DE STATUS RPG */
.status-container {
    background: #555;
    width: 100%;
    border-radius: 5px;
    height: 15px;
    margin: 5px 0;
    position: relative;
}
.status-bar {
    height: 100%;
    border-radius: 5px;
    transition: width 0.8s ease, background 0.5s ease, box-shadow 0.5s ease;
}

/* HP */
.hp-bar { background: red; } /* Sempre vermelha */
.hp-bar.warn { background: red; animation: pulse 1s infinite; } /* Pulsando quando médio */
.hp-bar.low { background: red; animation: pulse 0.8s infinite; } /* Pulsando quando baixo */


/* Mana */
.mana-bar { background: #3498db; }
.mana-bar.low { 
background: #3498db; /* Mantém azul mesmo baixo */
animation: pulse 0.8s infinite; /* Pulsando para chamar atenção */
}

/* Power */
.power-bar.high { background: #2ecc71; box-shadow: 0 0 8px #2ecc71; animation: glow 1.2s infinite; } /* Verde brilhante */
.power-bar.medium { background: #27ae60; } /* Verde médio */
.power-bar.low { background: #16a085; animation: pulse 0.8s infinite; } /* Verde escuro pulsante */


/* XP */
.xp-bar { background: purple; }

/* TEXTO DAS BARRAS */
.stat-text {
    position: absolute;
    width: 100%;
    text-align: center;
    top: 0;
    left: 0;
    font-weight: bold;
    color: #fff;
    font-size: 0.9em;
    line-height: 15px;
}

/* ANIMAÇÕES */
@keyframes pulse {
    0% { box-shadow: 0 0 5px rgba(255,255,255,0.5); }
    50% { box-shadow: 0 0 15px rgba(255,255,255,1); }
    100% { box-shadow: 0 0 5px rgba(255,255,255,0.5); }
}
@keyframes glow {
    0% { box-shadow: 0 0 5px gold; }
    50% { box-shadow: 0 0 20px gold; }
    100% { box-shadow: 0 0 5px gold; }
}

/* RESPONSIVO */
@media(max-width:768px){ .character-card{width:45%;} }
@media(max-width:480px){ .character-card{width:90%;} .top-bar{flex-direction:column;align-items:center;} }
</style>
</head>
<body>

<div class="container">
    <!-- Top bar -->
    <nav class="top-bar">
        <form method="POST" action="restaurar.php">
            <button type="submit">💊 Restaurar HP/MP</button>
        </form>
        <a href="logout.php">🚪 Sair</a>
        <a href="personagens.php">👤 Personagens</a>
        <a href="bank.php">🏦 Banco</a>
        <a href="start_dungeon.php">🗡️ Masmorra</a>
        <a href="equipar_item_advanced.php">🎒 Inventário</a>
        <a href="inventario.php">🎒 Inventário2</a>
        <a href="saude.php">🩺 Saúde da Conta</a>
        <a href="mercado.php">🛒 Mercado</a>
        <a href="bolsa.php">📈 Bolsa de Valores</a>
        <a href="del_conta.php" onclick="return confirm('Tem certeza que deseja excluir sua conta?');">🗑️ Excluir Conta</a>
    </nav>

    <!-- Bloco jogador -->
    <div class="jogador-info">
        <p>🏰 Painel Visual do Mumu RPG</p>
        <p>Bem-vindo, <strong><?= htmlspecialchars($player['Username'] ?? 'Jogador') ?></strong>!</p>
        <p>💰 Moedas Mumu: <strong><?= $moeda ?></strong></p>
        <p><strong>Último login:</strong> <?= !empty($player['LastLoginTime']) ? $player['LastLoginTime']->format("d/m/Y H:i") : "Nunca" ?></p>
        <p><strong>IP logado:</strong> <?= !empty($player['LastLoginIP']) ? htmlspecialchars($player['LastLoginIP']) : "Desconhecido" ?></p>
    </div>

    <!-- Cartões de personagens -->
    <div class="dashboard-container">
        <?php if(!empty($personagens)): ?>
            <?php foreach($personagens as $char): ?>
                <?php
                    $power = $char['Power'] ?? 100;
                    $maxPower = $char['MaxPower'] ?? 100;
                    $hp = $char['HP'] ?? 100;
                    $maxHP = $char['MaxHP'] ?? 100;
                    $mana = $char['Mana'] ?? 0;
                    $maxMana = $char['MaxMana'] ?? 100;
                    $xp = $char['Exp'] ?? 0;
                    $level = $char['Level'] ?? 1;

                    $percentPower = max(0, min(100, round($power / $maxPower * 100)));
                    $percentHP = max(0, min(100, round($hp / $maxHP * 100)));
                    $percentMana = max(0, min(100, round($mana / $maxMana * 100)));
                    $percentXP = max(0, min(100, round($xp / ($level * 50) * 100)));
                ?>
                <div class="character-card">
                    <h3><?= htmlspecialchars($char['Name']) ?> (<?= htmlspecialchars($char['Class']) ?>)</h3>
                    <div>Level: <span id="level-<?= $char['CharID'] ?>"><?= $level ?></span></div>

                    <!-- Power -->
                    <div class="status-container">
                        <div id="power-<?= $char['CharID'] ?>" class="status-bar <?= $percentPower>70?'high':($percentPower>30?'medium':'low') ?>" style="width:<?= $percentPower ?>%"></div>
                        <div class="stat-text" id="powertext-<?= $char['CharID'] ?>"><?= $power ?> / <?= $maxPower ?></div>
                    </div>

                    <!-- HP -->
                    <div class="status-container">
                        <div id="hp-<?= $char['CharID'] ?>" class="hp-bar <?= $percentHP>60?'':($percentHP>30?'warn':'low') ?>" style="width:<?= $percentHP ?>%"></div>
                        <div class="stat-text" id="hptext-<?= $char['CharID'] ?>"><?= $hp ?> / <?= $maxHP ?></div>
                    </div>

                    <!-- Mana -->
                    <div class="status-container">
                        <div id="mana-<?= $char['CharID'] ?>" class="mana-bar <?= $percentMana>30?'':'low' ?>" style="width:<?= $percentMana ?>%"></div>
                        <div class="stat-text" id="manatext-<?= $char['CharID'] ?>"><?= $mana ?> / <?= $maxMana ?></div>
                    </div>

                    <!-- XP -->
                    <div class="status-container">
                        <div id="xp-<?= $char['CharID'] ?>" class="xp-bar" style="width:<?= $percentXP ?>%"></div>
                        <div class="stat-text" id="xptext-<?= $char['CharID'] ?>"><?= $xp ?> / <?= $level*50 ?></div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Nenhum personagem encontrado. <a href="criar_personagem.php">Crie um agora!</a></p>
        <?php endif; ?>
    </div>
</div>

<script>
// Atualiza status via AJAX
function atualizarStatus() {
    fetch('status_personagem.php')
    .then(res => res.json())
    .then(data => {
        data.forEach(c => {
            // HP
            let hpPerc = Math.max(0, Math.min(100, Math.round(c.HP / c.MaxHP * 100)));
            let hpElem = document.getElementById('hp-' + c.CharID);
            hpElem.style.width = hpPerc + '%';
            hpElem.className = 'hp-bar ' + (hpPerc>60?'':'warn');
            if(hpPerc <= 30) hpElem.className = 'hp-bar low';
            document.getElementById('hptext-' + c.CharID).innerText = c.HP + ' / ' + c.MaxHP;

            // Mana
            let manaPerc = Math.max(0, Math.min(100, Math.round(c.Mana / c.MaxMana * 100)));
            let manaElem = document.getElementById('mana-' + c.CharID);
            manaElem.style.width = manaPerc + '%';
            manaElem.className = 'mana-bar ' + (manaPerc>30?'':'low');
            document.getElementById('manatext-' + c.CharID).innerText = c.Mana + ' / ' + c.MaxMana;

            // XP
            let xpPerc = Math.max(0, Math.min(100, Math.round(c.Exp/(c.Level*50)*100)));
            let xpElem = document.getElementById('xp-' + c.CharID);
            xpElem.style.width = xpPerc + '%';
            document.getElementById('xptext-' + c.CharID).innerText = c.Exp + ' / ' + (c.Level*50);

            // Level
            document.getElementById('level-' + c.CharID).innerText = c.Level;

            // Power
            let powerPerc = Math.max(0, Math.min(100, Math.round(c.Power / c.MaxPower * 100)));
            let powerElem = document.getElementById('power-' + c.CharID);
            powerElem.style.width = powerPerc + '%';
            powerElem.className = 'status-bar ' + (powerPerc>70?'high':(powerPerc>30?'medium':'low'));
            document.getElementById('powertext-' + c.CharID).innerText = c.Power + ' / ' + c.MaxPower;
        });
    })
    .catch(err => console.error(err));
}
setInterval(atualizarStatus, 1500);
</script>

</body>
</html>
