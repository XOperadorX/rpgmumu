-- Itens que podem aparecer no jogo
INSERT INTO Itens (Nome) VALUES
('Esmeralda'),
('Cristal'),
('Bronze'),
('Prata'),
('Ouro'),
('Po��o de Vida'),
('Po��o de Mana'),
('Espada Antiga'),
('Escudo M�gico'),
('Elmo de A�o');
