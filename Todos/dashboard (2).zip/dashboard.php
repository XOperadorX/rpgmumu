<?php
session_start();
include "db.php";
include "check_ban.php"; // Protege a página

if (!isset($_SESSION['PlayerID'])) {
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// Dados do jogador
$stmtPlayer = sqlsrv_query($conn, "SELECT TOP 1 * FROM Players WHERE PlayerID=?", [$playerID]);
$player = ($stmtPlayer && $row = sqlsrv_fetch_array($stmtPlayer, SQLSRV_FETCH_ASSOC)) ? $row : [];
$moedas = $player['MoedaMumu'] ?? 0;

// Personagens
$personagens = [];
$sql = "SELECT TOP 1000 [CharID],[PlayerID],[Name],[Class],[Level],[Exp],[HP],[Mana],[MaxHP],[MaxMana],[Power]
        FROM Characters WHERE PlayerID=?";
$stmtChar = sqlsrv_query($conn, $sql, [$playerID]);
if ($stmtChar && sqlsrv_has_rows($stmtChar)) {
    while ($row = sqlsrv_fetch_array($stmtChar, SQLSRV_FETCH_ASSOC)) {
        $personagens[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Dashboard - Mumu RPG Futurista</title>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&family=Orbitron:wght@500&display=swap" rel="stylesheet">
<style>
body { background:black; color:white; font-family:'Roboto','Orbitron',sans-serif; margin:0; padding:20px; }
.container { max-width:1200px; margin:auto; padding:20px; }

/* TOP BAR */
.top-bar { display:flex; flex-wrap:wrap; justify-content:center; gap:10px; margin-bottom:20px; }
.top-bar a, .top-bar button {
    padding:10px 20px; border-radius:8px; text-decoration:none;
    color:#fff; background:#333; transition:0.3s; border:none; cursor:pointer;
}
.top-bar a:hover, .top-bar button:hover { background:#ffcc00; color:#000; }

/* BLOCO JOGADOR */
.jogador-info {
    background:#222; color:#ffcc00;
    padding:15px; border-radius:10px;
    margin:0 auto 20px auto; text-align:center; max-width:800px;
}
.jogador-info h1{margin-top:0; font-size:1.8em;}
.jogador-info p{margin:5px 0;}

/* PAINEL FUTURISTA */
.status-panel {
    background: linear-gradient(135deg, #111, #222);
    border-radius: 20px;
    box-shadow: 0 0 30px #0ff;
    padding: 25px;
    margin-bottom:20px;
}
.status-bar { display: flex; align-items: center; margin: 15px 0; }
.bar-container { flex: 1; height: 25px; background: #333; border-radius: 12px; margin: 0 10px; overflow: hidden; }
.bar { height: 100%; width: 0%; border-radius: 12px; transition: width 1s ease-in-out; }
.hp { background: linear-gradient(90deg, #f00, #ff5555); }
.mana { background: linear-gradient(90deg, #00f, #55f); }
.power { background: linear-gradient(90deg, #0f0, #5f5); }
.btn-futurista {
    margin-top: 10px; padding: 12px 25px;
    background: linear-gradient(135deg, #0ff, #00f);
    border: none; border-radius: 15px; font-weight: bold;
    color: #000; cursor: pointer; box-shadow: 0 0 25px #0ff;
    transition: transform 0.2s, box-shadow 0.2s;
}
.btn-futurista:hover { transform: scale(1.05); box-shadow: 0 0 35px #0ff; }

.popup-msg {
    position: fixed; top: 20px; right: 20px; padding: 15px 25px;
    border-radius: 15px; font-weight: bold; color: #fff;
    background: linear-gradient(135deg, #00f, #0ff);
    box-shadow: 0 0 25px rgba(0,255,255,0.6); z-index: 9999;
    animation: fadeInOut 3s forwards; display: none;
}
@keyframes fadeInOut {
    0% { opacity:0; transform:translateY(-20px); }
    10%, 90% { opacity:1; transform:translateY(0); }
    100% { opacity:0; transform:translateY(-20px); }
}

/* RESPONSIVO */
@media(max-width:768px){ .status-panel{width:90%; margin:auto;} }


.stat-text {
    position: absolute;
    width: 100%;
    text-align: center;
    top: 0;
    left: 0;
    font-weight: bold;
    color: #fff;
    font-size: 0.9em;
    line-height: 20px;
    text-shadow: 0 0 3px #00ffea;
}


</style>
</head>
<body>
<div class="container">

    <!-- MENU -->
    <nav class="top-bar">
        <!-- <form method="POST" action="restaurar.php"><button type="submit">💊 Restaurar HP/MP</button></form> -->
        <a href="logout.php">🚪 Sair</a>
        <a href="personagens.php">👤 Personagens</a>
        <a href="bank.php">🏦 Banco</a>
        <a href="start_dungeon.php">🗡️ Masmorra</a>
        <a href="inventario.php">🎒 Inventário</a>
        <a href="saude.php">🩺 Saúde</a>
        <a href="mercado.php">🛒 Mercado</a>
        <a href="bolsa.php">📈 Bolsa</a>
        <a href="del_conta.php" onclick="return confirm('Tem certeza?');">🗑️ Bloquear Conta</a>
    </nav>

    <!-- INFO JOGADOR -->
    <div class="jogador-info">
        <p>🏰 Painel Visual do Mumu RPG Futurista</p>
        <p>Bem-vindo, <strong><?= htmlspecialchars($player['Username'] ?? 'Jogador') ?></strong>!</p>
        <p>💰 Moedas Mumu: <strong><?= $moedas ?></strong></p>
        <p><strong>Último login:</strong> <?= !empty($player['LastLoginTime']) ? $player['LastLoginTime']->format("d/m/Y H:i") : "Nunca" ?></p>
        <p><strong>IP logado:</strong> <?= !empty($player['LastLoginIP']) ? htmlspecialchars($player['LastLoginIP']) : "Desconhecido" ?></p>
    </div>

<!-- PERSONAGENS -->
<h2 style="text-align:center; color:#0ff; margin-bottom:10px;">⚡ Status dos Personagens</h2>

	<?php if ($personagens): ?> 
    <div style="display:flex; flex-wrap:wrap; justify-content:center; gap:15px;">
    <?php foreach ($personagens as $p): 
        $hpPerc = $p['MaxHP']>0 ? round($p['HP']/$p['MaxHP']*100) : 0;
        $manaPerc = $p['MaxMana']>0 ? round($p['Mana']/$p['MaxMana']*100) : 0;
        $powerPerc = $p['Power'];
    ?>
<div class="status-panel" style="width:280px; padding:15px; border-radius:15px; box-shadow:0 0 20px #0ff; background:linear-gradient(145deg, #0a0a0a, #1a1a1a); font-family: 'Segoe UI', sans-serif; color:#fff;">

    <!-- Classe -->
    <div class="status-bar" style="margin-bottom:10px;">
        <span style="font-weight:bold;">Classe:</span>&nbsp;&nbsp;<?= htmlspecialchars($p['Class']) ?>
    </div>

    <!-- HP -->
    <div class="status-bar" style="margin-bottom:10px;">
        <span style="font-weight:bold;">HP:</span>
        <div class="bar-container" style="position:relative; background:#111; border-radius:15px; height:25px; overflow:hidden; box-shadow: inset 0 0 5px #0ff;">
            <div id="hp-<?= $p['CharID'] ?>" class="bar hp" style="width:<?= ($p['HP']/$p['MaxHP'])*100 ?>%; height:100%; background:linear-gradient(90deg, #ff0000, #ff5555); border-radius:15px; transition: width 1s;"></div>
            <span style="position:absolute; width:100%; text-align:center; font-weight:bold; line-height:25px; color:#fff;" id="hpVal-<?= $p['CharID'] ?>"><?= $p['HP'] ?> / <?= $p['MaxHP'] ?></span>
        </div>
    </div>

    <!-- Mana -->
    <div class="status-bar" style="margin-bottom:10px;">
        <span style="font-weight:bold;">Mana:</span>
        <div class="bar-container" style="position:relative; background:#111; border-radius:15px; height:25px; overflow:hidden; box-shadow: inset 0 0 5px #0ff;">
            <div id="mana-<?= $p['CharID'] ?>" class="bar mana" style="width:<?= ($p['Mana']/$p['MaxMana'])*100 ?>%; height:100%; background:linear-gradient(90deg, #0000ff, #5555ff); border-radius:15px; transition: width 1s;"></div>
            <span style="position:absolute; width:100%; text-align:center; font-weight:bold; line-height:25px; color:#fff;" id="manaVal-<?= $p['CharID'] ?>"><?= $p['Mana'] ?> / <?= $p['MaxMana'] ?></span>
        </div>
    </div>

    <!-- Power -->
    <div class="status-bar" style="margin-bottom:10px;">
        <span style="font-weight:bold;">Power:</span>
        <div class="bar-container" style="position:relative; background:#111; border-radius:15px; height:25px; overflow:hidden; box-shadow: inset 0 0 5px #0ff;">
            <div id="power-<?= $p['CharID'] ?>" class="bar power" style="width:<?= ($p['Power']/100)*100 ?>%; height:100%; background:linear-gradient(90deg, #00ff00, #55ff55); border-radius:15px; transition: width 1s;"></div>
            <span style="position:absolute; width:100%; text-align:center; font-weight:bold; line-height:25px; color:#fff;" id="powerVal-<?= $p['CharID'] ?>"><?= $p['Power'] ?> / 100</span>
        </div>
    </div>
	

    <!-- Power -->

	<div>
		<button class="btn-futurista" onclick="restaurarPersonagem(<?= $p['CharID'] ?>)" style="width:100%; margin-top:10px; padding:10px; font-weight:bold; background:linear-gradient(90deg,#0ff,#0aa); border:none; border-radius:10px; cursor:pointer; color:#000; box-shadow:0 0 10px #0ff;">Restaurar (500 MoedaMumu)</button>
	</div>
</div>



<script>
    // Função para animar as barras ao carregar
    document.addEventListener("DOMContentLoaded", function() {
        const hp = document.getElementById("hp-<?= $p['CharID'] ?>");
        const mana = document.getElementById("mana-<?= $p['CharID'] ?>");
        const power = document.getElementById("power-<?= $p['CharID'] ?>");

        hp.style.width = "<?= $hpPerc ?>%";
        mana.style.width = "<?= $manaPerc ?>%";
        power.style.width = "<?= $powerPerc ?>%";
    });
</script>


    <?php endforeach; ?>
    </div>
	
	
<?php else: ?>
    <p style="text-align:center;">Nenhum personagem encontrado. <a href="criar_personagem.php">Crie um agora!</a></p>
<?php endif; ?>



</div>

<div id="popupMsg" class="popup-msg"></div>

<script>
// Atualiza barras de status
function atualizarBar(charID, HP, MaxHP, Mana, MaxMana, Power, MoedaMumu){
    document.getElementById('hp-'+charID).style.width = (HP/MaxHP*100)+'%';
    document.getElementById('hpVal-'+charID).innerText = HP;

    document.getElementById('mana-'+charID).style.width = (Mana/MaxMana*100)+'%';
    document.getElementById('manaVal-'+charID).innerText = Mana;

    document.getElementById('power-'+charID).style.width = Power+'%';
    document.getElementById('powerVal-'+charID).innerText = Power;

    document.getElementById('moedaVal-'+charID).innerText = MoedaMumu;
}

// Restaurar via AJAX
function restaurarPersonagem(charID){
    fetch('ajax_restaurar.php', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ CharID: charID })
    })
    .then(res => res.json())
    .then(data => {
        const popup = document.getElementById('popupMsg');
        popup.innerText = data.message;
        popup.style.display = 'block';
        setTimeout(() => { popup.style.display = 'none'; }, 3000);

        if(data.success){
            atualizarBar(charID, data.HP, data.MaxHP, data.Mana, data.MaxMana, data.Power, data.MoedaMumu);
        }
    })
//.catch(err => alert("Erro de conexão!"));
}
</script>

</body>
</html>
