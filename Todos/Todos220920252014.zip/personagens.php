<?php
session_start();
include "db.php";

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];


$sql = "SELECT c.CharID, c.Name, c.Class, c.Level, c.Exp, c.HP, pc.MoedaMumu
        FROM Characters c
        JOIN Players pc ON c.PlayerID = pc.PlayerID
        WHERE c.PlayerID = ?";

$params = array($playerID);
$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt === false) {
    die(print_r(sqlsrv_errors(), true));
}

echo "<table border='1' cellspacing='0' cellpadding='8' style='margin:20px auto; border-collapse:collapse; text-align:center;'>";
echo "<tr style='background:#333; color:#fff;'>
        <th>Personagem</th>
        <th>Classe</th>
        <th>Level</th>
        <th>Exp</th>
        <th>HP</th>
        <th>💰 Moedas</th>
      </tr>";

while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    echo "<tr>
            <td>{$row['Name']}</td>
            <td>{$row['Class']}</td>
            <td>{$row['Level']}</td>
            <td>{$row['Exp']}</td>
            <td>{$row['HP']}</td>
            <td>{$row['MoedaMumu']}</td>
          </tr>";
}

echo "</table>";



?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Personagens</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<h2>👥 Seus Personagens</h2>
<?php
$sql = "SELECT * FROM Characters WHERE PlayerID=?";
$stmt = sqlsrv_query($conn, $sql, [$playerID]);
if($stmt && sqlsrv_has_rows($stmt)){
    while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)){
        echo "<p>Nome: {$row['Name']} | Classe: {$row['Class']} | Level: {$row['Level']}</p>";
        echo "<p>Inventário: Arma | Escudo | Capacete | Armadura | Gluva | Calça | Asa | Pet | Anel1 | Pingente | Anel2 | Colar</p>";
    }
} else {
    echo "<p>Nenhum personagem encontrado.</p>";
}
?>
<a href="dashboard.php">⬅️ Voltar</a>
</body>
</html>



