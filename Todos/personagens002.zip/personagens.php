<?php
session_start();
include "db.php";

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];


$sql = "SELECT c.CharID, c.Name, c.Class, c.Level, c.Exp, c.HP, pc.MoedaMumu
        FROM Characters c
        JOIN Players pc ON c.PlayerID = pc.PlayerID
        WHERE c.PlayerID = ?";

$params = array($playerID);
$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt === false) {
    die(print_r(sqlsrv_errors(), true));
}




?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Personagens</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<h2>👥 Seus Personagens</h2>
<?php

echo "<table border='1' cellspacing='0' cellpadding='8' style='margin:20px auto; border-collapse:collapse; text-align:center;'>";
echo "<tr style='background:#333; color:#fff;'>
        <th>Personagem</th>
        <th>Classe</th>
        <th>Level</th>
        <th>Experiência</th>
        <th>HP</th>
        <th>💰 Moedas</th>
      </tr>";

while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    echo "<tr>
            <td>{$row['Name']}</td>
            <td>{$row['Class']}</td>
            <td>{$row['Level']}</td>
            <td>{$row['Exp']}</td>
            <td>{$row['HP']}</td>
            <td>{$row['MoedaMumu']}</td>
          </tr>";
}

echo "</table>";








?>
<?php
echo "<table border='1' cellspacing='0' cellpadding='8' style='margin:20px auto; border-collapse:collapse; text-align:center;'>";
echo "<tr style='background:#333; color:#fff;'>
        <th>Arma</th>
        <th>Escudo</th>
        <th>Capacete</th>
        <th>Armadura</th>
        <th>Luva</th>
        <th>Calça</th>
      </tr>";

while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    echo "<tr>
            <td>{$row['Arma']}</td>
            <td>{$row['Escudo']}</td>
            <td>{$row['Capacete']}</td>
            <td>{$row['Armadura']}</td>
            <td>{$row['Luva']}</td>
            <td>{$row['Calça']}</td>
          </tr>";
}

echo "</table>";


?>


<!-- XP -->
<p id="charStatus">Level: <?= $_SESSION['dungeon']['char']['Level'] ?> | XP: <?= $_SESSION['dungeon']['char']['Exp'] ?></p>
<div class="progress"><div id="xpBar" class="bar xp" style="width:<?= ($_SESSION['dungeon']['char']['Exp'] % 100) ?>%;"></div></div>




<table border="1" cellpadding="8" cellspacing="0" style="border-collapse: collapse; width: 60%; margin:20px auto; text-align:center;">
    <tr style="background:#333; color:#fff;">
        <th>Nome</th>
        <th>Classe</th>
        <th>Nível</th>
        <th>Experiência</th>
        <th>Força</th>
        <th>Agilidade</th>
        <th>Vitalidade</th>
        <th>Energia</th>
        <th>HP</th>
        <th>MoedaMumu</th>
    </tr>
    <tr>
        <td><?= $_SESSION['dungeon']['char']['Name'] ?? '-' ?></td>
        <td><?= $_SESSION['dungeon']['char']['Class'] ?? '-' ?></td>
        <td><?= $_SESSION['dungeon']['char']['Level'] ?? '-' ?></td>
        <td><?= $_SESSION['dungeon']['char']['Exp'] ?? '-' ?></td>
        <td><?= $_SESSION['dungeon']['char']['Strength'] ?? '-' ?></td>
        <td><?= $_SESSION['dungeon']['char']['Dexterity'] ?? '-' ?></td>
        <td><?= $_SESSION['dungeon']['char']['Vitality'] ?? '-' ?></td>
        <td><?= $_SESSION['dungeon']['char']['Energy'] ?? '-' ?></td>
        <td><?= $_SESSION['dungeon']['char']['HP'] ?? '-' ?></td>
        <td><?= $_SESSION['dungeon']['char']['MoedaMumu'] ?? '-' ?></td>

    </tr>
</table>





	<a href="dashboard.php" class="btn voltar">⬅️ Voltar</a>

</body>
</html>



