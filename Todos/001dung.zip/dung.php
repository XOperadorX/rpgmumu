<?php
session_start();
include "db.php";

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// pega personagem do player
$stmt = sqlsrv_query($conn, "SELECT TOP 1 * FROM Characters WHERE PlayerID = ?", [$playerID]);
$dbChar = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
if(!$dbChar){
    die("<p>Você precisa ter pelo menos um personagem para entrar na dungeon.</p><a href='dashboard.php'>⬅️ Voltar</a>");
}

// monta sessão personagem
$charSession = [
    'CharID' => $dbChar['CharID'],
    'Name'   => $dbChar['Name'],
    'HP'     => (int)$dbChar['HP'],
    'MaxHP'  => (int)$dbChar['MaxHP'],
    'Mana'   => (int)$dbChar['Mana'],
    'MaxMana'=> (int)$dbChar['MaxMana'],
    'Level'  => (int)$dbChar['Level'],
    'Exp'    => (int)$dbChar['Exp']
];

// inimigos
$inimigos = [
    ['Name'=>'Goblin','Level'=>1,'XP'=>10,'HP'=>30,'MaxHP'=>30,'Mana'=>10,'MaxMana'=>10,'Loot'=>['Potion','Herb']],
    ['Name'=>'Orc','Level'=>2,'XP'=>20,'HP'=>50,'MaxHP'=>50,'Mana'=>20,'MaxMana'=>20,'Loot'=>['Gold','Shield']],
    ['Name'=>'Dragão','Level'=>5,'XP'=>50,'HP'=>100,'MaxHP'=>100,'Mana'=>50,'MaxMana'=>50,'Loot'=>['Sword','Dragon Scale']]
];

// inicializa sessão da dungeon
if(!isset($_SESSION['dungeon']) || $_SESSION['dungeon']['playerID'] != $playerID){
    $_SESSION['dungeon'] = [
        'playerID' => $playerID,
        'char' => $charSession,
        'enemies' => $inimigos,
        'current' => 0,
        'log' => []
    ];
}

// inventário
$stmtItems = sqlsrv_query($conn, "SELECT * FROM Items WHERE CharID = ?", [$charSession['CharID']]);
$itens = [];
while($row = sqlsrv_fetch_array($stmtItems, SQLSRV_FETCH_ASSOC)){
    $itens[] = $row;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8" />
<title>Dungeon - Loot e Inventário</title>
<style>
body{background:#222;color:#fff;font-family:Arial,sans-serif;text-align:center;margin:0;padding:20px;}
.cards-container{display:flex;justify-content:center;gap:40px;flex-wrap:wrap;margin-top:20px;}
.card{background:#111;border:3px solid gold;border-radius:15px;width:260px;padding:10px;box-shadow:0 0 20px rgba(255,255,255,0.4);transition:transform 0.3s;}
.card:hover{transform:scale(1.05);}
.card h3{margin:0 0 10px;font-size:1.3em;text-shadow:1px 1px 3px black;}
.progress{width:100%;background:#555;border-radius:5px;margin:5px 0;}
.bar{height:18px;border-radius:5px;transition:width 0.5s;}
.player-bar{background:limegreen;}
.enemy-bar{background:red;}
.mana-bar{background:#3498db;}
.xp-bar{background:purple;}
.log{background:#333;padding:10px;margin:20px auto;width:540px;height:200px;overflow-y:auto;border-radius:5px;text-align:left;}
#voltar{display:none;margin-top:20px;padding:10px 20px;background:#444;color:#fff;text-decoration:none;border-radius:5px;}
#voltar:hover{background:#ffcc00;color:#000;}
.inventory-container{display:flex;flex-wrap:wrap;justify-content:center;gap:10px;margin-top:15px;}
.item{background:#444;padding:6px 10px;border-radius:6px;border:1px solid #888;}
</style>
</head>
<body>

<h1>🗡️ Dungeon - <?= htmlspecialchars($charSession['Name']) ?></h1>

<div class="cards-container">
    <!-- Player -->
    <div class="card">
        <h3 id="charName"><?= htmlspecialchars($charSession['Name']) ?></h3>
        <p id="charStatus">Level: <?= $charSession['Level'] ?> | XP: <?= $charSession['Exp'] ?></p>

        <div class="progress"><div id="playerBar" class="bar player-bar" style="width:<?= round($charSession['HP']/$charSession['MaxHP']*100) ?>%"></div></div>
        <p>HP: <span id="charHP"><?= $charSession['HP'] ?></span> / <?= $charSession['MaxHP'] ?></p>

        <div class="progress"><div id="playerMana" class="bar mana-bar" style="width:<?= round($charSession['Mana']/$charSession['MaxMana']*100) ?>%"></div></div>
        <p>Mana: <span id="charMana"><?= $charSession['Mana'] ?></span> / <?= $charSession['MaxMana'] ?></p>

        <!-- XP -->
        <div class="progress"><div id="charXPBar" class="bar xp-bar" style="width:<?= round(($charSession['Exp']/($charSession['Level']*50))*100) ?>%"></div></div>
        <p id="charXP">XP: <?= $charSession['Exp'] ?> / <?= $charSession['Level']*50 ?></p>
    </div>

    <!-- Enemy -->
    <div class="card">
        <h3 id="enemyName">?</h3>
        <p id="enemyStatus">Level: ? | XP: ?</p>
        <div class="progress"><div id="enemyBar" class="bar enemy-bar" style="width:100%"></div></div>
        <p id="enemyHP">HP: ?</p>
        <div class="progress"><div id="enemyMana" class="bar mana-bar" style="width:100%"></div></div>
        <p id="enemyManaVal">Mana: ?</p>
    </div>
</div>

<h2>🎒 Inventário</h2>
<div class="inventory-container" id="inventory">
    <?php foreach($itens as $item): ?>
        <div class="item"><?= htmlspecialchars($item['Name']) ?></div>
    <?php endforeach; ?>
</div>

<div class="log" id="log"></div>
<a id="voltar" href="dashboard.php"></a>

<script>
function atualizarDungeon(){
    fetch("turno.php")
    .then(r=>r.json())
    .then(data=>{
        // Player
        document.getElementById("charHP").innerText = data.char.HP;
        document.getElementById("playerBar").style.width = (data.char.MaxHP>0 ? (data.char.HP/data.char.MaxHP*100) : 0) + "%";
        document.getElementById("charMana").innerText = data.char.Mana;
        document.getElementById("playerMana").style.width = (data.char.MaxMana>0 ? (data.char.Mana/data.char.MaxMana*100) : 0) + "%";
        document.getElementById("charStatus").innerText = "Level: " + data.char.Level + " | XP: " + data.char.Exp;

        // XP do player
        let xpMax = data.char.Level * 50;
        document.getElementById("charXP").innerText = "XP: " + data.char.Exp + " / " + xpMax;
        document.getElementById("charXPBar").style.width = (xpMax>0 ? (data.char.Exp/xpMax*100) : 0) + "%";

        // Enemy
        if(data.enemy){
            document.getElementById("enemyName").innerText = data.enemy.Name;
            document.getElementById("enemyStatus").innerText = "Level: " + data.enemy.Level + " | XP: " + data.enemy.XP;
            document.getElementById("enemyHP").innerText = "HP: " + data.enemy.HP + " / " + data.enemy.MaxHP;
            document.getElementById("enemyBar").style.width = (data.enemy.MaxHP>0 ? (data.enemy.HP/data.enemy.MaxHP*100) : 0) + "%";
            document.getElementById("enemyManaVal").innerText = "Mana: " + data.enemy.Mana + " / " + data.enemy.MaxMana;
            document.getElementById("enemyMana").style.width = (data.enemy.MaxMana>0 ? (data.enemy.Mana/data.enemy.MaxMana*100) : 0) + "%";
        }

        // Log
        let logDiv = document.getElementById("log");
        logDiv.innerHTML += data.log.map(l => "<div>"+l+"</div>").join("");
        logDiv.scrollTop = logDiv.scrollHeight;

        // Loot
        if(data.loot && data.loot.length>0){
            let invDiv = document.getElementById("inventory");
            data.loot.forEach(it=>{
                let div = document.createElement('div');
                div.className='item';
                div.innerText = it;
                invDiv.appendChild(div);
            });
        }

        // Fim da dungeon
        if(!data.fim){
            setTimeout(atualizarDungeon, 1200);
        } else {
            let voltarBtn = document.getElementById("voltar");
            if(data.char.HP <=0){
                logDiv.innerHTML += "<div style='color:red'>☠️ Você foi derrotado!</div>";
                voltarBtn.innerText = "☠️ Voltar";
            } else {
                logDiv.innerHTML += "<div style='color:yellow'>🏆 Todos inimigos derrotados!</div>";
                voltarBtn.innerText = "🏆 Voltar";
            }
            voltarBtn.style.display = "inline-block";
        }
    }).catch(err=>{
        console.error(err);
        document.getElementById("log").innerHTML += "<div style='color:orange'>Erro de comunicação com turno.php</div>";
    });
}
atualizarDungeon();
</script>
</body>
</html>
