
<?php
session_start();
include "db.php";

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// Pega personagem principal
$stmt = sqlsrv_query($conn, "SELECT TOP 1 CharID, Name, Class, Level, Exp, HP, Mana, MaxMana FROM Characters WHERE PlayerID=?", [$playerID]);
if(!$stmt || !sqlsrv_has_rows($stmt)){
    die("Você precisa ter pelo menos um personagem.<br><a href='dashboard.php'>⬅️ Voltar</a>");
}
$char = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>📜 Status do Personagem</title>
<style>
body { font-family: Arial, sans-serif; background:#1c1c1c; color:#fff; text-align:center; padding:20px; }
h1 { margin-bottom:10px; }
.stat { margin:10px 0; }
.bar { width:300px; height:25px; background:#555; border-radius:12px; margin:0 auto; overflow:hidden; }
.fill { height:100%; line-height:25px; color:#fff; text-align:center; font-weight:bold; }
.hp-fill { background:#e74c3c; }
.mana-fill { background:#3498db; }
</style>
</head>
<body>

<h1>🎮 <?= htmlspecialchars($char['Name']) ?> | Classe: <?= htmlspecialchars($char['Class']) ?></h1>
<p class="stat">Level: <?= $char['Level'] ?> | Exp: <?= $char['Exp'] ?></p>

<div class="stat">HP: <?= $char['HP'] ?></div>
<div class="bar"><div class="fill hp-fill" style="width:<?= min(100, ($char['HP'] / 100) * 100) ?>%"><?= $char['HP'] ?></div></div>

<div class="stat">Mana: <?= $char['Mana'] ?> / <?= $char['MaxMana'] ?></div>
<div class="bar"><div class="fill mana-fill" style="width:<?= min(100, ($char['Mana'] / $char['MaxMana']) * 100) ?>%"><?= $char['Mana'] ?></div></div>

<a href="dashboard.php" style="color:#ffcc00; display:inline-block; margin-top:20px;">⬅️ Voltar</a>

</body>
</html>
