<?php
session_start();
include "db.php";

// Aqui você pode restringir apenas para administradores
// if ($_SESSION['Role'] != 'admin') { die("Acesso negado."); }

// ✅ Bloquear ou desbloquear via GET
if (isset($_GET['action']) && isset($_GET['id'])) {
    $playerID = intval($_GET['id']);
    $action = $_GET['action'];

    if ($action === "block") {
        $sql = "UPDATE Players SET IsBanned = 1 WHERE PlayerID = ?";
        sqlsrv_query($conn, $sql, [$playerID]);
    } elseif ($action === "unblock") {
        $sql = "UPDATE Players SET IsBanned = 0 WHERE PlayerID = ?";
        sqlsrv_query($conn, $sql, [$playerID]);
    }

    header("Location: admin_users.php");
    exit;
}

// ✅ Pegar todos os jogadores
$sql = "SELECT PlayerID, Username, IsBanned, LastLoginTime, LastLoginIP FROM Players ORDER BY PlayerID DESC";
$stmt = sqlsrv_query($conn, $sql);
if ($stmt === false) {
    die(print_r(sqlsrv_errors(), true));
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Admin - Usuários</title>
<style>
body { font-family: Arial, sans-serif; background:#1c1c1c; color:#fff; }
h1 { text-align:center; margin:20px 0; }
table { border-collapse: collapse; width: 90%; margin:auto; background:#333; color:#fff; }
th, td { padding:10px; border:1px solid #555; text-align:center; }
a.btn { padding:5px 10px; border-radius:5px; text-decoration:none; font-weight:bold; }
.block { background:#ff3333; color:#fff; }
.unblock { background:#33cc33; color:#fff; }
.block:hover { background:#ff0000; }
.unblock:hover { background:#009900; }
</style>
</head>
<body>
<h1>👑 Administração de Usuários</h1>
<table>
    <tr>
        <th>ID</th>
        <th>Usuário</th>
        <th>Status</th>
        <th>Último Login</th>
        <th>Último IP</th>
        <th>Ação</th>
    </tr>
    <?php while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)): ?>
        <tr>
            <td><?= $row['PlayerID'] ?></td>
            <td><?= htmlspecialchars($row['Username']) ?></td>
            <td>
                <?= ($row['IsBanned'] == 1) ? "🚫 Bloqueado" : "✅ Ativo" ?>
            </td>
            <td>
                <?= ($row['LastLoginTime']) ? $row['LastLoginTime']->format('d/m/Y H:i') : "-" ?>
            </td>
            <td><?= $row['LastLoginIP'] ?? "-" ?></td>
            <td>
                <?php if ($row['IsBanned'] == 1): ?>
                    <a class="btn unblock" href="?action=unblock&id=<?= $row['PlayerID'] ?>">Desbloquear</a>
                <?php else: ?>
                    <a class="btn block" href="?action=block&id=<?= $row['PlayerID'] ?>">Bloquear</a>
                <?php endif; ?>
            </td>
        </tr>
    <?php endwhile; ?>
</table>
</body>
</html>
