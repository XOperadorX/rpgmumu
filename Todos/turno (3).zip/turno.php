<?php
session_start();
include "db.php";
include "check_ban.php";

header('Content-Type: application/json');

$response = [
    'char' => null,
    'enemy' => null,
    'log' => [],
    'fim' => false
];

if(!isset($_SESSION['PlayerID']) || !isset($_SESSION['dungeon'])){
    echo json_encode($response);
    exit;
}

$playerID = $_SESSION['PlayerID'];
$dungeon = &$_SESSION['dungeon'];
$enemy = &$dungeon['enemies'][$dungeon['current']] ?? null;

// Pega personagem atualizado do banco
$stmtChar = sqlsrv_query($conn, "SELECT TOP 1 * FROM Characters WHERE PlayerID = ?", [$playerID]);
$char = $stmtChar ? sqlsrv_fetch_array($stmtChar, SQLSRV_FETCH_ASSOC) : null;

if(!$char){
    echo json_encode($response);
    exit;
}

// ======================
// Simulação de ataque
// ======================
// Por simplicidade, cada turno o jogador tira 10 de HP do inimigo
$log = [];
if($enemy && $char['HP']>0){
    $damage = 10; // exemplo fixo
    $enemy['HP'] -= $damage;
    if($enemy['HP'] < 0) $enemy['HP'] = 0;
    $log[] = "Você causou $damage de dano em {$enemy['Name']}.";

    // Inimigo contra-ataca
    if($enemy['HP'] > 0){
        $enemyDamage = 5; // exemplo fixo
        $char['HP'] -= $enemyDamage;
        if($char['HP'] < 0) $char['HP'] = 0;
        $log[] = "{$enemy['Name']} causou $enemyDamage de dano em você.";
    }
}

// ======================
// Loot se inimigo morreu
// ======================
$lootDrop = [];
if($enemy && $enemy['HP'] <= 0){
    $stmtLoot = sqlsrv_query($conn, "SELECT ItemName FROM EnemyLoot WHERE EnemyID = ?", [$enemy['EnemyID']]);
    if($stmtLoot){
        while($row = sqlsrv_fetch_array($stmtLoot, SQLSRV_FETCH_ASSOC)){
            $lootDrop[] = $row['ItemName'];
            $_SESSION['loot'][] = $row['ItemName'];
        }
    }
    if(!empty($lootDrop)){
        foreach($lootDrop as $item){
            $log[] = "🎁 Você recebeu: $item";
        }
    } else {
        $log[] = "ℹ️ {$enemy['Name']} não dropou nenhum item.";
    }

    // Avança para próximo inimigo
    $dungeon['current']++;
    $enemy = $dungeon['enemies'][$dungeon['current']] ?? null;
    if(!$enemy){
        $dungeon['fim'] = true;
    }
}

// Atualiza resposta
$response['char'] = [
    'HP' => $char['HP'],
    'MaxHP' => $char['MaxHP'],
    'Mana' => $char['Mana'],
    'MaxMana' => $char['MaxMana'],
    'Exp' => $char['Exp'],
    'Level' => $char['Level'],
    'Power' => $char['Power'],
    'MaxPower' => $char['MaxPower']
];
$response['enemy'] = $enemy ? [
    'HP' => $enemy['HP'],
    'MaxHP' => $enemy['MaxHP'],
    'Mana' => $enemy['Mana'],
    'MaxMana' => $enemy['MaxMana'],
    'XP' => $enemy['XP'],
    'Level' => $enemy['Level'],
    'Name' => $enemy['Name']
] : null;

$response['log'] = $log;
$response['fim'] = $dungeon['fim'] ?? false;

echo json_encode($response);
