<?php
session_start();
include "db.php";

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// pega um personagem do player
$stmt = sqlsrv_query($conn, "SELECT TOP 1 * FROM Characters WHERE PlayerID = ?", [$playerID]);
if($stmt === false){
    die("Erro SQL: " . print_r(sqlsrv_errors(), true));
}
$dbChar = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
if(!$dbChar){
    die("<p>Você precisa ter pelo menos um personagem para entrar na dungeon.</p><a href='dashboard.php'>⬅️ Voltar</a>");
}

// Função utilitária para detectar colunas
function find_key($row, $candidates){
    $keys = array_keys($row);
    $lowMap = [];
    foreach($keys as $k) $lowMap[strtolower($k)] = $k;
    foreach($candidates as $cand){
        $lc = strtolower($cand);
        if(isset($lowMap[$lc])) return $lowMap[$lc];
    }
    return null;
}

// detecta colunas importantes
$charIdKey = find_key($dbChar, ['CharID','CharacterID','ID','Id']);
$nameKey   = find_key($dbChar, ['Name','CharacterName','CharName']);
$hpKey     = find_key($dbChar, ['HP','Life','CurrentHP','CurLife','hp','life']);
$maxHpKey  = find_key($dbChar, ['MaxHP','MaxLife','Max_HP','Max_Life','maxhp','maxlife']);
$levelKey  = find_key($dbChar, ['Level','cLevel','level']);
$expKey    = find_key($dbChar, ['Exp','Experience','experience','exp']);

// fallback
if(!$charIdKey) $charIdKey = 'CharID';
if(!$nameKey) $nameKey = 'Name';
if(!$hpKey) $hpKey = $hpKey ?? null;
if(!$maxHpKey) $maxHpKey = $maxHpKey ?? null;
if(!$levelKey) $levelKey = $levelKey ?? 'Level';
if(!$expKey) $expKey = $expKey ?? 'Exp';

// dados do personagem
$charSession = [
    'CharID' => $dbChar[$charIdKey] ?? null,
    'Name'   => $dbChar[$nameKey] ?? 'SemNome',
    'HP'     => isset($dbChar[$hpKey]) ? (int)$dbChar[$hpKey] : 100,
    'MaxHP'  => isset($dbChar[$maxHpKey]) ? (int)$dbChar[$maxHpKey] : (isset($dbChar[$hpKey]) ? (int)$dbChar[$hpKey] : 100),
    'Level'  => isset($dbChar[$levelKey]) ? (int)$dbChar[$levelKey] : 1,
    'Exp'    => isset($dbChar[$expKey]) ? (int)$dbChar[$expKey] : 0
];

// inimigos
$inimigos = [
    ['Name'=>'Goblin','HP'=>30,'MaxHP'=>30,'XP'=>10,'Loot'=>'Potion'],
    ['Name'=>'Orc','HP'=>50,'MaxHP'=>50,'XP'=>20,'Loot'=>'Gold'],
    ['Name'=>'Boss Dragão','HP'=>100,'MaxHP'=>100,'XP'=>50,'Loot'=>'Sword']
];

// inicializa sessão dungeon
if(!isset($_SESSION['dungeon']) || $_SESSION['dungeon']['playerID'] != $playerID){
    $_SESSION['dungeon'] = [
        'playerID' => $playerID,
        'char' => $charSession,
        'enemies' => $inimigos,
        'current' => 0,
        'log' => [],
        'cols' => [
            'charId' => $charIdKey,
            'name'   => $nameKey,
            'hp'     => $hpKey,
            'maxhp'  => $maxHpKey,
            'level'  => $levelKey,
            'exp'    => $expKey
        ]
    ];
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8" />
<title>Dungeon - Cards estilo Yu-Gi-Oh!</title>
<style>
body{
    background:#222;
    color:#fff;
    font-family:Arial,sans-serif;
    text-align:center;
    margin:0;
    padding:20px;
}
.cards-container{
    display:flex;
    justify-content:center;
    gap:40px;
    flex-wrap:wrap;
    margin-top:20px;
}
.card{
    background:#111;
    border:3px solid gold;
    border-radius:15px;
    width:250px;
    padding:10px;
    box-shadow:0 0 20px rgba(255,255,255,0.4);
    transition: transform 0.3s;
    position:relative;
}
.card::before{
    content:'';
    position:absolute;
    top:-3px; left:-3px; right:-3px; bottom:-3px;
    border-radius:18px;
    border:2px solid rgba(255,255,255,0.2);
    pointer-events:none;
}
.card:hover{
    transform:scale(1.05);
}
.card h3{
    margin-top:0;
    margin-bottom:10px;
    font-size:1.3em;
    text-shadow:1px 1px 3px black;
}
.progress{width:100%;background:#555;border-radius:5px;margin:5px 0;}
.bar{height:20px;border-radius:5px;transition:width 0.5s;}
.player-bar{background:limegreen;}
.enemy-bar{background:red;}
.xp-bar{background:#3498db;}
.log{
    background:#333;
    padding:10px;
    margin:20px auto;
    width:540px;
    height:200px;
    overflow-y:auto;
    border-radius:5px;
    text-align:left;
}
#voltar{display:none;margin-top:20px;padding:10px 20px;background:#444;color:#fff;text-decoration:none;border-radius:5px;}
#voltar:hover{background:#ffcc00;color:#000;}
</style>
</head>
<body>

<h1>🗡️ Dungeon - Cards estilo Yu-Gi-Oh!</h1>

<div class="cards-container">
    <!-- Card do Player -->
    <div class="card" id="playerCard">
        <h3 id="charName"><?= htmlspecialchars($_SESSION['dungeon']['char']['Name']) ?></h3>
        <p id="charStatus">Level: <?= $_SESSION['dungeon']['char']['Level'] ?> | XP: <?= $_SESSION['dungeon']['char']['Exp'] ?></p>
        <div class="progress"><div id="playerBar" class="bar player-bar" style="width:<?= round($_SESSION['dungeon']['char']['HP'] / max(1,$_SESSION['dungeon']['char']['MaxHP']) * 100) ?>%"></div></div>
        <p>HP: <span id="charHP"><?= $_SESSION['dungeon']['char']['HP'] ?></span> / <?= $_SESSION['dungeon']['char']['MaxHP'] ?></p>
    </div>

    <!-- Card do Inimigo -->
    <div class="card" id="enemyCard">
        <h3 id="enemyName">?</h3>
        <div class="progress"><div id="enemyBar" class="bar enemy-bar" style="width:100%"></div></div>
        <p id="enemyHP">HP: ?</p>
    </div>
</div>

<div class="log" id="log"></div>
<a id="voltar" href="dashboard.php"></a>

<script>
function atualizarLuta(){
    fetch("turno.php")
    .then(r=>r.json())
    .then(data=>{
        // Player
        document.getElementById("charHP").innerText = data.char.HP;
        document.getElementById("playerBar").style.width = (data.char.MaxHP>0 ? (data.char.HP/data.char.MaxHP*100) : 0) + "%";
        document.getElementById("charStatus").innerText = "Level: " + data.char.Level + " | XP: " + data.char.Exp;

        // Enemy
        document.getElementById("enemyName").innerText = data.enemy.Name;
        document.getElementById("enemyHP").innerText = "HP: " + data.enemy.HP + " / " + data.enemy.MaxHP;
        document.getElementById("enemyBar").style.width = (data.enemy.MaxHP>0 ? (data.enemy.HP/data.enemy.MaxHP*100) : 0) + "%";

        // log
        let logDiv = document.getElementById("log");
        logDiv.innerHTML = data.log.map(l => "<div>"+l+"</div>").join("");
        logDiv.scrollTop = logDiv.scrollHeight;

        if(!data.fim){
            setTimeout(atualizarLuta, 1200);
        } else {
            let voltarBtn = document.getElementById("voltar");
            if(data.char.HP <= 0){
                logDiv.innerHTML += "<div style='color:red'>☠️ Você foi derrotado!</div>";
                voltarBtn.innerText = "☠️ Voltar";
            } else {
                logDiv.innerHTML += "<div style='color:yellow'>🏆 Todos inimigos derrotados!</div>";
                voltarBtn.innerText = "🏆 Voltar";
            }
            voltarBtn.style.display = "inline-block";
        }
    })
    .catch(err=>{
        console.error(err);
        document.getElementById("log").innerHTML += "<div style='color:orange'>Erro de comunicação com turno.php</div>";
    });
}
atualizarLuta();
</script>
</body>
</html>
