<?php
session_start();
include "db.php";
header('Content-Type: application/json; charset=utf-8');

$playerID = $_SESSION['PlayerID'] ?? null;
$itemID   = intval($_POST['itemID'] ?? 0);

if(!$playerID || $itemID <= 0){
    echo json_encode(['sucesso'=>false, 'mensagem'=>'Dados inválidos.']);
    exit;
}

$sqlItem = "SELECT Quantidade, Valor, Nome FROM dbo.Items WHERE ItemID=? AND PlayerID=?";
$stmt = sqlsrv_query($conn, $sqlItem, [$itemID, $playerID]);

if(!$stmt || !($item = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC))){
    echo json_encode(['sucesso'=>false, 'mensagem'=>'Item não encontrado no inventário.']);
    exit;
}

$qtdAtual   = intval($item['Quantidade']);
$valorItem  = intval($item['Valor']);
$nomeItem   = $item['Nome'];

if($qtdAtual <= 0){
    echo json_encode(['sucesso'=>false, 'mensagem'=>'Quantidade insuficiente.']);
    exit;
}

$novaQtd = $qtdAtual - 1;

if($novaQtd > 0){
    sqlsrv_query($conn, "UPDATE dbo.Items SET Quantidade=? WHERE ItemID=? AND PlayerID=?", [$novaQtd, $itemID, $playerID]);
} else {
    sqlsrv_query($conn, "DELETE FROM dbo.Items WHERE ItemID=? AND PlayerID=?", [$itemID, $playerID]);
}

$stmtSaldo = sqlsrv_query($conn, "SELECT MoedaMumu FROM dbo.Players WHERE PlayerID=?", [$playerID]);
$player = sqlsrv_fetch_array($stmtSaldo, SQLSRV_FETCH_ASSOC);

$saldoAtual = intval($player['MoedaMumu'] ?? 0);
$novoSaldo = $saldoAtual + $valorItem;

sqlsrv_query($conn, "UPDATE dbo.Players SET MoedaMumu=? WHERE PlayerID=?", [$novoSaldo, $playerID]);

echo json_encode([
    'sucesso'     => true,
    'mensagem'    => "Você vendeu 1x {$nomeItem} por {$valorItem} MoedaMumu.",
    'itemID'      => $itemID,
    'nome'        => $nomeItem,
    'valor'       => $valorItem,
    'moedas'      => $valorItem, // ✅ campo adicionado
    'nova_qtd'    => $novaQtd,
    'novo_saldo'  => $novoSaldo
]);
