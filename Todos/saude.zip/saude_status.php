<?php
session_start();
include "db.php";

header('Content-Type: application/json');

if(!isset($_SESSION['PlayerID'])){
    echo json_encode(['error'=>'Não logado']);
    exit;
}

$playerID = $_SESSION['PlayerID'];

// Pega dados do jogador
$sql = "SELECT Username, MoedaMumu, ContaSaude, CreatedAt FROM Players WHERE PlayerID=?";
$stmt = sqlsrv_query($conn, $sql, [$playerID]);
$dados = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

if(!$dados){
    echo json_encode(['error'=>'Jogador não encontrado']);
    exit;
}

$health = (int)($dados['ContaSaude'] ?? 0);

// Últimos 10 logins
$sqlLogins = "SELECT TOP 10 LoginTime, LoginIP FROM LoginHistory WHERE PlayerID=? ORDER BY LoginTime DESC";
$stmtLogins = sqlsrv_query($conn, $sqlLogins, [$playerID]);
$logins = [];
if ($stmtLogins !== false) {
    while($row = sqlsrv_fetch_array($stmtLogins, SQLSRV_FETCH_ASSOC)){
        $logins[] = [
            'LoginTime'=>!empty($row['LoginTime']) ? date('d/m/Y H:i', strtotime($row['LoginTime'])) : '-',
            'LoginIP'=>$row['LoginIP'] ?? '-'
        ];
    }
}

echo json_encode([
    'username'=>$dados['Username'] ?? 'Desconhecido',
    'moeda'=>(int)($dados['MoedaMumu'] ?? 0),
    'health'=>$health,
    'logins'=>$logins
]);
