<?php
session_start();
include "db.php";

if(!isset($_SESSION['PlayerID'])) exit('⛔ Acesso negado');

$adminID = $_SESSION['PlayerID'];
$stmt = sqlsrv_query($conn,"SELECT Role FROM Players WHERE PlayerID=?",[$adminID]);
$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
if(!$row || $row['Role']!=='admin') exit('⛔ Acesso negado');

$sqlUsers = "SELECT PlayerID, Username, Email, MoedaMumu, LastLoginTime, IsBanned FROM Players ORDER BY PlayerID ASC";
$stmtUsers = sqlsrv_query($conn, $sqlUsers);

echo '<table>
<tr>
<th>ID</th>
<th>Usuário</th>
<th>Email</th>
<th>MoedaMumu</th>
<th>Último Login</th>
<th>Status</th>
<th>Ações</th>
</tr>';

if($stmtUsers){
    while($user = sqlsrv_fetch_array($stmtUsers, SQLSRV_FETCH_ASSOC)){
        $lastLogin = ($user['LastLoginTime'] instanceof DateTime) ? $user['LastLoginTime']->format("d/m/Y H:i:s") : '—';
        $status = $user['IsBanned'] ? '<span class="status-block">🚫 Bloqueado</span>' : '<span class="status-ok">✅ Ativo</span>';
        $btnText = $user['IsBanned'] ? '🔓 Desbloquear' : '🔒 Bloquear';
        echo '<tr>
        <td>'.$user['PlayerID'].'</td>
        <td>'.htmlspecialchars($user['Username']).'</td>
        <td>'.htmlspecialchars($user['Email']).'</td>
        <td><input type="number" class="edit-coins" data-playerid="'.$user['PlayerID'].'" value="'.number_format($user['MoedaMumu'],2,'.','').'"></td>
        <td>'.$lastLogin.'</td>
        <td>'.$status.'</td>
        <td><button class="btn-toggle" data-playerid="'.$user['PlayerID'].'">'.$btnText.'</button></td>
        </tr>';
    }
}else{
    echo '<tr><td colspan="7">❌ Nenhum jogador encontrado.</td></tr>';
}
echo '</table>';
