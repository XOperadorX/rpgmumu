<?php
session_start();
include "db.php";

$playerID = $_SESSION['PlayerID'] ?? null;
if(!$playerID){ die(json_encode(['error'=>"⛔ Faça login para acessar."])); }

// Exemplo de tabela HistoricoTransacoes:
// ID, PlayerID, Acao, Item, Qtd, PrecoUnitario, Total, DataHora
$query = "SELECT TOP 10 DataHora, Acao, Item, Qtd, PrecoUnitario, Total 
          FROM HistoricoTransacoes 
          WHERE PlayerID = ? 
          ORDER BY DataHora DESC";

$stmt = sqlsrv_query($conn, $query, [$playerID]);
$result = [];

while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)){
    $result[] = [
        'datahora' => $row['DataHora']->format('d/m/Y H:i:s'),
        'acao' => $row['Acao'],
        'item' => $row['Item'],
        'qtd' => $row['Qtd'],
        'preco_unit' => $row['PrecoUnitario'],
        'total' => $row['Total']
    ];
}

echo json_encode($result);
