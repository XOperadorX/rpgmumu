<nav>
<a href="admin_dashboard.php">⬅ Voltar ao Painel</a>
<a href="logout.php">🚪 Sair</a>
</nav>
<?php
session_start();
include "../db.php"; // Ajuste o caminho conforme sua pasta

// Verifica se está logado e se é admin
if (!isset($_SESSION['PlayerID'])) die("⛔ Faça login.");
$stmt = sqlsrv_query($conn, "SELECT Role FROM Players WHERE PlayerID = ?", [$_SESSION['PlayerID']]);
$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
if ($row['Role'] !== 'admin') die("⛔ Acesso negado. Apenas admins.");

// Atualização via AJAX
if(isset($_POST['action']) && $_POST['action'] === 'update'){
    $sql = "UPDATE Characters SET 
                Name=?, Class=?, Level=?, Exp=?, HP=?, Mana=?, MaxHP=?, MaxMana=? 
            WHERE CharID=?";
    $params = [
        $_POST['Name'], $_POST['Class'], $_POST['Level'], $_POST['Exp'],
        $_POST['HP'], $_POST['Mana'], $_POST['MaxHP'], $_POST['MaxMana'], $_POST['CharID']
    ];
    sqlsrv_query($conn, $sql, $params);
    echo "success";
    exit;
}

// Carregar personagens
$sql = "SELECT * FROM Characters";
$result = sqlsrv_query($conn, $sql);

while($char = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)){
    $hpPercent = ($char['HP']/$char['MaxHP'])*100;
    $manaPercent = ($char['Mana']/$char['MaxMana'])*100;

    echo "<div class='char-card' data-id='{$char['CharID']}'>
            <form class='char-form'>
                <input type='hidden' name='CharID' value='{$char['CharID']}'>
                Nome: <input type='text' name='Name' value='{$char['Name']}'>
                Classe: <input type='text' name='Class' value='{$char['Class']}'>
                Level: <input type='number' name='Level' value='{$char['Level']}'>
                Exp: <input type='number' name='Exp' value='{$char['Exp']}'>
                HP: <input type='number' name='HP' value='{$char['HP']}'>
                MaxHP: <input type='number' name='MaxHP' value='{$char['MaxHP']}'>
                Mana: <input type='number' name='Mana' value='{$char['Mana']}'>
                MaxMana: <input type='number' name='MaxMana' value='{$char['MaxMana']}'>
                
                <div class='bar'><div class='hp-bar' style='width:{$hpPercent}%;'>HP: {$char['HP']}/{$char['MaxHP']}</div></div>
                <div class='bar'><div class='mana-bar' style='width:{$manaPercent}%;'>Mana: {$char['Mana']}/{$char['MaxMana']}</div></div>
                
                <button type='submit'>Atualizar</button>
            </form>
          </div>";
}
?>

<script>
window.addEventListener('DOMContentLoaded', () => {
    attachForms();

    function attachForms(){
        document.querySelectorAll('.char-form').forEach(form => {
            form.addEventListener('submit', e => {
                e.preventDefault();
                let data = new FormData(form);
                data.append('action','update');
                fetch('admin_Characters_Edit.php',{method:'POST',body:data})
                    .then(res=>res.text())
                    .then(resp=>{
                        if(resp==='success'){
                            // Recarrega os personagens sem refresh da página
                            fetch('admin_Characters_Edit.php')
                                .then(res=>res.text())
                                .then(html=>{
                                    document.getElementById('characters-list').innerHTML = html;
                                    attachForms(); // Reanexa os eventos
                                });
                        }
                    });
            });
        });
    }
});

</script>
<style>
body { font-family: Arial,sans-serif; background:#f4f6f7; margin:0; padding:0; }
.container { max-width:1200px; margin:auto; padding:20px; }
.char-card { background:#fff; padding:15px; margin-bottom:15px; border-radius:10px; box-shadow:0 2px 5px rgba(0,0,0,0.1);}
.char-card form input { margin:5px; padding:5px; }
.bar { background:#ddd; border-radius:5px; margin:5px 0; height:20px; overflow:hidden;}
.hp-bar { background:red; height:100%; text-align:center; color:#fff; transition: width 0.5s;}
.mana-bar { background:blue; height:100%; text-align:center; color:#fff; transition: width 0.5s;}
button { padding:5px 10px; cursor:pointer; border:none; border-radius:5px; background:#2ecc71; color:#fff;}
@media(max-width:768px){
    .char-card form input { width:100%; display:block; }
    .bar { font-size:12px; }
}


</style>

