<?php
session_start();
include "db.php";
if(!isset($_SESSION['PlayerID'])) header("Location: login.php");

$stmt = sqlsrv_query($conn, "SELECT Username, Role FROM Players WHERE PlayerID=?", [$_SESSION['PlayerID']]);
$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
if(!$row || $row['Role'] !== 'admin') die("⛔ Acesso negado.");
$username = $row['Username'];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Painel Admin - Mumu RPG</title>
<style>
body { margin:0; font-family:Arial; background:#1c1c1c; color:#fff; }
header { background:#cc0000; padding:20px; text-align:center; }
main { padding:40px; display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:20px; }
.card { background:#2a2a2a; padding:20px; border-radius:12px; text-align:center; transition:0.3s; }
.card:hover { background:#3a3a3a; transform:translateY(-5px); }
.card a { color:#fff; text-decoration:none; font-size:18px; font-weight:bold; display:block; }
.logout { text-align:center; margin-top:30px; }
.logout a { background:#ff3333; color:#fff; padding:12px 25px; border-radius:8px; text-decoration:none; font-weight:bold; }
.logout a:hover { background:#ff0000; }
</style>
</head>
<body>
<header>
<h1>⚔️ Painel Administrativo</h1>
<p>Bem-vindo, <?= htmlspecialchars($username) ?>!</p>
</header>
<main>
<div class="card"><a href="admin_settings.php">⚙️ Configurações</a></div>
<div class="card"><a href="bank/admin_bank.php">🏦 Banco</a></div>
<div class="card"><a href="admin_logs.php">📜 Logs</a></div>
<div class="card"><a href="personagens/admin_users.php">👥 Jogadores</a></div>
<div class="card"><a href="players/admin_users.php">👥 admin_users</a></div>
<div class="card"><a href="admin_dashboard.php">👥 admin_dashboard</a></div>

<div class="card"><a href="admin_logs.php">📜 Logs</a></div>


</main>
<div class="logout"><a href="logout.php">🚪 Sair</a></div>
</body>
</html>
