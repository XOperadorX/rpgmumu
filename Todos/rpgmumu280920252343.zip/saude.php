<?php
session_start();
include "db.php";

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado.");
}
$playerID = $_SESSION['PlayerID'];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>🩺 Saúde da Conta - Estilo RPG</title>
<style>
body{
    background:#222;
    color:#fff;
    font-family:Arial,sans-serif;
    text-align:center;
    padding:20px;
}
.container{
    max-width:600px;
    margin:auto;
}
.card{
    background:#111;
    border:2px solid #fff;
    border-radius:15px;
    padding:20px;
    margin-bottom:20px;
    box-shadow:0 0 15px rgba(255,255,255,0.2);
}
h1{
    margin-top:0;
    margin-bottom:10px;
    font-size:1.8em;
    text-shadow:1px 1px 2px #000;
}
.progress-bar{
    width:100%;
    background:#555;
    border-radius:10px;
    overflow:hidden;
    height:30px;
    margin:10px 0;
    position:relative;
}
.progress-fill{
    height:100%;
    width:0%;
    text-align:center;
    color:#fff;
    line-height:30px;
    font-weight:bold;
    border-radius:10px;
    transition:width 0.5s;
}
button{
    padding:10px 15px;
    font-size:1em;
    border:none;
    border-radius:5px;
    cursor:pointer;
    margin-top:10px;
    background:#3498db;
    color:#fff;
    transition:0.3s;
}
button:hover{
    background:#2980b9;
}
.info{
    text-align:left;
    margin-top:10px;
}
</style>
</head>
<body>
<nav style="background:#2c3e50; padding:10px; text-align:left;">
    <a href="dashboard.php" style="
        color:#fff;
        text-decoration:none;
        font-weight:bold;
        padding:8px 15px;
        background:#3498db;
        border-radius:5px;
        transition:0.3s;
    " onmouseover="this.style.background='#2980b9';" onmouseout="this.style.background='#3498db';">
        ⬅ Voltar
    </a>
</nav>
<div class="container">
    <div class="card">
        <h1>🩺 Saúde da Conta</h1>
        <p><strong>Usuário:</strong> <span id="username">Carregando...</span></p>
        <p><strong>MoedaMumu:</strong> <span id="moeda">0</span></p>
        <div class="progress-bar">
            <div id="barraSaude" class="progress-fill">0 dias restantes</div>
        </div>
        <div class="info">
            <p><strong>Conta criada:</strong> <span id="createdAt">--/--/----</span></p>
            <p><strong>Último login:</strong> <span id="lastLogin">--/--/----</span> (<span id="lastLoginIP">---</span>)</p>
            <p><strong>Status:</strong> <span id="isBanned">---</span></p>
        </div>
        <div style="margin-top:10px;">
            <input type="number" id="qtdDias" min="1" value="1" style="width:60px;">
            <button id="comprarDias">💰 Comprar dias</button>
        </div>
    </div>
</div>

<script>
// Atualiza barra e infos via AJAX
function atualizarSaude(){
    fetch('saude_status.php')
    .then(res => res.json())
    .then(data=>{
        if(data.error) return;

        document.getElementById('username').textContent = data.username;
        document.getElementById('moeda').textContent = data.moeda;
        document.getElementById('createdAt').textContent = data.createdAt;
        document.getElementById('lastLogin').textContent = data.lastLogin;
        document.getElementById('lastLoginIP').textContent = data.lastLoginIP;
        document.getElementById('isBanned').textContent = data.isBanned ? '❌ Bloqueada' : '✅ Ativa';

        let barra = document.getElementById('barraSaude');
        barra.style.width = data.healthPercent + '%';
        barra.textContent = data.remainingDays + ' dia(s) restantes';

        // cores da barra
        if(data.remainingDays >= 2) barra.style.background = '#2ecc71';
        else if(data.remainingDays == 1) barra.style.background = '#f1c40f';
        else barra.style.background = '#e74c3c';
    })
    .catch(err=>console.error(err));
}

// Compra dias
document.getElementById('comprarDias').addEventListener('click', ()=>{
    let qtd = parseInt(document.getElementById('qtdDias').value);
    if(isNaN(qtd) || qtd<1) qtd = 1;

    let formData = new FormData();
    formData.append('days', qtd);

    fetch('saude_comprar.php',{method:'POST', body:formData})
    .then(res=>res.json())
    .then(data=>{
        alert(data.msg);
        atualizarSaude();
    })
    .catch(err=>console.error(err));
});

atualizarSaude();
setInterval(atualizarSaude, 5000);
</script>

</body>
</html>
