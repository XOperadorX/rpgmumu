<?php
session_start();
include "db.php";

// Verifica se está logado
if (!isset($_SESSION['PlayerID'])) {
    header("Location: login.php");
    exit;
}

// Puxa dados do jogador
$sql = "SELECT Username, Role FROM Players WHERE PlayerID = ?";
$stmt = sqlsrv_query($conn, $sql, [$_SESSION['PlayerID']]);
$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

if (!$row || $row['Role'] !== 'admin') {
    die("⛔ Acesso negado. Apenas administradores podem acessar.");
}

$username = $row['Username'];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Painel Administrativo - Mumu RPG</title>
<style>
body { background:#1c1c1c; color:#fff; font-family:Arial, sans-serif; margin:0; }
header { background:#cc0000; padding:20px; text-align:center; }
header h1 { margin:0; color:#fff; }
nav { background:#222; padding:15px; text-align:center; }
nav a { margin:0 10px; padding:12px 20px; border-radius:5px; background:#444; color:#fff; text-decoration:none; font-weight:bold; display:inline-block; transition:0.3s; }
nav a:hover { background:#666; }
main { padding:30px; text-align:center; }
.card { background:#333; display:inline-block; margin:15px; padding:20px; border-radius:10px; width:220px; }
.card h2 { margin:10px 0; }
.card a { display:block; margin-top:10px; padding:10px; border-radius:5px; background:#cc0000; color:#fff; text-decoration:none; font-weight:bold; }
.card a:hover { background:#ff0000; }
</style>
</head>
<body>
<header>
    <h1>👑 Painel Administrativo - Bem-vindo <?= htmlspecialchars($username) ?> 👑</h1>
</header>
<nav>
    <a href="dashboard.php">🏠 Voltar ao Dashboard</a>
    <a href="logout.php">🚪 Sair</a>
</nav>
<main>
    <h2>📂 Opções de Administração</h2>
    <div class="card">
        <h2>Usuários</h2>
        <p>Gerenciar bloqueio/desbloqueio de jogadores.</p>
        <a href="admin_users.php">👥 Gerenciar Usuários</a>
    </div>

    <div class="card">
        <h2>Logs</h2>
        <p>Visualizar histórico de login, transações e exclusões.</p>
        <a href="admin_logs.php">📜 Ver Logs</a>
    </div>

    <div class="card">
        <h2>Banco</h2>
        <p>Consultar movimentações e contas.</p>
        <a href="admin_bank.php">🏦 Controle do Banco</a>
    </div>

    <div class="card">
        <h2>Configurações</h2>
        <p>Ajustar permissões e funções administrativas.</p>
        <a href="admin_settings.php">⚙️ Configurações</a>
    </div>
</main>
</body>
</html>
