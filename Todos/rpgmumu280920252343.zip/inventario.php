<?php
session_start();
include "db.php";

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// Pega personagem principal do player
$stmtChar = sqlsrv_query($conn, "SELECT * FROM Characters WHERE PlayerID=?", [$playerID]);
if(!$stmtChar || !sqlsrv_has_rows($stmtChar)){
    die("Você precisa ter pelo menos um personagem.<br><a href='dashboard.php'>⬅️ Voltar</a>");
}
$char = sqlsrv_fetch_array($stmtChar, SQLSRV_FETCH_ASSOC);

// Pega itens do personagem
$stmtItems = sqlsrv_query($conn, "SELECT * FROM Items WHERE CharID=?", [$char['CharID']]);
$itens = [];
while($row = sqlsrv_fetch_array($stmtItems, SQLSRV_FETCH_ASSOC)){
    $itens[$row['Slot']] = $row; // Organiza os itens pelo slot
}

// Pega saldo de moedas do player
$stmtMoedas = sqlsrv_query($conn, "SELECT MoedaMumu FROM Players WHERE PlayerID=?", [$playerID]);
$moedaRow = sqlsrv_fetch_array($stmtMoedas, SQLSRV_FETCH_ASSOC);
$moedas = $moedaRow['MoedaMumu'] ?? 0;

// Slots padrão do inventário
$slots = ['Arma','Escudo','Capacete','Armadura','Luva','Calça','Asa','Pet','Anel1','Pingente','Anel2','Colar'];
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Inventário do Personagem</title>
<style>
body{
    background:#222;
    color:#fff;
    font-family:Arial, sans-serif;
    text-align:center;
    margin:0;
    padding:20px;
}
.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:20px;
}
.header a{
    padding:10px 15px;
    background:#444;
    color:#fff;
    text-decoration:none;
    border-radius:5px;
}
.header a:hover{
    background:#ffcc00;
    color:#000;
}
.cards-container{
    display:flex;
    flex-wrap:wrap;
    justify-content:center;
    gap:20px;
}
.card{
    background:#111;
    border:2px solid #fff;
    border-radius:15px;
    width:180px;
    padding:15px;
    box-shadow:0 0 15px rgba(255,255,255,0.2);
    transition: transform 0.3s;
}
.card:hover{
    transform:scale(1.05);
}
.card h3{
    margin:0 0 10px 0;
    font-size:1.1em;
    text-shadow:1px 1px 2px #000;
}
.card p{
    margin:5px 0;
    font-size:0.9em;
}
</style>
</head>
<body>

<div class="header">
    <h1><?= htmlspecialchars($char['Name']) ?> | Moedas: <?= $moedas ?></h1>
    <a href="dashboard.php">⬅️ Voltar</a>
</div>

<div class="cards-container">
    <?php foreach($slots as $slot): ?>
        <div class="card">
            <h3><?= $slot ?></h3>
            <p><?= isset($itens[$slot]) ? htmlspecialchars($itens[$slot]['Name']) : 'Nenhum item' ?></p>
            <?php if(isset($itens[$slot])): ?>
                <p>Level: <?= $itens[$slot]['Level'] ?? '-' ?></p>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

</body>
</html>
