<?php
session_start();
include "db.php";
header('Content-Type: application/json');

if(!isset($_SESSION['PlayerID'])){
    http_response_code(403);
    echo json_encode(['error'=>'Não autorizado']);
    exit;
}

$playerID = $_SESSION['PlayerID'];

// Puxa ou cria conta
$sqlBank = "
IF EXISTS(SELECT 1 FROM BankAccounts WHERE PlayerID = ?)
    SELECT Corrente, Poupanca, Pix, Real, LastUpdate FROM BankAccounts WHERE PlayerID = ?
ELSE
BEGIN
    INSERT INTO BankAccounts (PlayerID, Corrente, Poupanca, Pix, Real, LastUpdate)
    VALUES (?, 0,0,0,0, GETDATE());
    SELECT Corrente=0, Poupanca=0, Pix=0, Real=0, LastUpdate=GETDATE();
END
";
$stmtBank = sqlsrv_query($conn, $sqlBank, [$playerID,$playerID,$playerID]);
$rowBank = sqlsrv_fetch_array($stmtBank, SQLSRV_FETCH_ASSOC);

// Juros
$juros=0;
if(isset($rowBank['LastUpdate']) && $rowBank['LastUpdate'] instanceof DateTime){
    $last = $rowBank['LastUpdate'];
    $now = new DateTime();
    $diffMinutes = floor(($now->getTimestamp() - $last->getTimestamp()) / 60);
    if($diffMinutes>=1){
        $juros=$diffMinutes;
        sqlsrv_query($conn,"UPDATE Players SET MoedaMumu=MoedaMumu+? WHERE PlayerID=?",[$juros,$playerID]);
        sqlsrv_query($conn,"UPDATE BankAccounts SET LastUpdate=GETDATE() WHERE PlayerID=?",[$playerID]);
        sqlsrv_query($conn,"INSERT INTO BankHistory (PlayerID, Tipo, Valor, Data) VALUES (?, ?, ?, GETDATE())",[$playerID,'Juros da Poupança',$juros]);
    }
}

// Saldo
$sqlPlayer = "SELECT MoedaMumu FROM Players WHERE PlayerID=?";
$stmtPlayer = sqlsrv_query($conn, $sqlPlayer, [$playerID]);
$rowPlayer = sqlsrv_fetch_array($stmtPlayer, SQLSRV_FETCH_ASSOC);

echo json_encode([
    'saldo'=>$rowPlayer['MoedaMumu'] ?? 0,
    'corrente'=>$rowBank['Corrente'],
    'poupanca'=>$rowBank['Poupanca'],
    'pix'=>$rowBank['Pix'],
    'real'=>$rowBank['Real'],
    'juros'=>$juros
]);
