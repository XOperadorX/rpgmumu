<?php
session_start();
include "db.php";

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];
$mensagem = "";

if($_POST && isset($_POST['action']) && $_POST['action'] === "createChar"){
    $name = $_POST['name'];
    $class = $_POST['class'];

    $sql = "INSERT INTO Characters (PlayerID, Name, Class) VALUES (?, ?, ?)";
    $stmt = sqlsrv_query($conn, $sql, [$playerID, $name, $class]);

    $mensagem = $stmt ? "✅ Personagem criado com sucesso!" : "❌ Erro: ".print_r(sqlsrv_errors(),true);
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Criar Personagem</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<h2>✨ Criar Personagem</h2>
<form method="post">
<input type="hidden" name="action" value="createChar">
<input type="text" name="name" placeholder="Nome do Personagem" required><br>
<select name="class" required>
<option value="">Selecione a Classe</option>
<option value="Knight">⚔️ Knight</option>
<option value="Wizard">🪄 Wizard</option>
<option value="Elf">🏹 Elf</option>
</select><br>
<button type="submit">Criar</button>
</form>
<p><?= $mensagem ?></p>
<a href="dashboard.php">⬅️ Voltar</a>
</body>
</html>
