<?php
session_start();
include "db.php";

// 🔒 Verifica login
if (!isset($_SESSION['PlayerID'])) {
    echo json_encode(['success' => false, 'message' => "⛔ Faça login primeiro."]);
    exit;
}

$playerID = $_SESSION['PlayerID'];
$frutaID = $_POST['frutaID'] ?? null;

// ⚠️ Valida entrada
if (!$frutaID) {
    echo json_encode(['success' => false, 'message' => "⚠️ Selecione uma semente para comprar."]);
    exit;
}

// 🏷️ Busca preço da semente
$sqlPreco = "SELECT PrecoSemente, Nome FROM dbo.Frutas WHERE FrutaID = ?";
$stmtPreco = sqlsrv_query($conn, $sqlPreco, [$frutaID]);

if ($stmtPreco === false || !($rowPreco = sqlsrv_fetch_array($stmtPreco, SQLSRV_FETCH_ASSOC))) {
    echo json_encode(['success' => false, 'message' => "❌ Fruta não encontrada."]);
    exit;
}

$preco = (int)$rowPreco['PrecoSemente'];
$nomeFruta = $rowPreco['Nome'];

// 💰 Busca saldo da Poupança do jogador
$sqlPoupanca = "SELECT Poupanca FROM dbo.BankAccounts WHERE PlayerID = ?";
$stmtPoupanca = sqlsrv_query($conn, $sqlPoupanca, [$playerID]);

if ($stmtPoupanca === false || !($rowPoupanca = sqlsrv_fetch_array($stmtPoupanca, SQLSRV_FETCH_ASSOC))) {
    echo json_encode(['success' => false, 'message' => "❌ Erro ao consultar saldo da Poupança."]);
    exit;
}

$poupancaAtual = (int)$rowPoupanca['Poupanca'];

// 💸 Verifica saldo suficiente
if ($poupancaAtual < $preco) {
    echo json_encode(['success' => false, 'message' => "💰 Saldo insuficiente na Poupança para comprar a semente de $nomeFruta."]);
    exit;
}

// 🔄 Inicia transação
sqlsrv_begin_transaction($conn);

try {
    // 💵 Deduz o valor da Poupança
    $updatePoupanca = "UPDATE dbo.BankAccounts SET Poupanca = Poupanca - ? WHERE PlayerID = ?";
    if (!sqlsrv_query($conn, $updatePoupanca, [$preco, $playerID])) {
        throw new Exception("Erro ao deduzir saldo da Poupança.");
    }

    // 🌱 Adiciona ou atualiza a semente no inventário
    $updateSemente = "
        IF EXISTS (SELECT 1 FROM dbo.Sementes WHERE PlayerID = ? AND FrutaID = ?)
            UPDATE dbo.Sementes SET Quantidade = Quantidade + 1 WHERE PlayerID = ? AND FrutaID = ?
        ELSE
            INSERT INTO dbo.Sementes (PlayerID, FrutaID, Quantidade) VALUES (?, ?, 1)
    ";

    if (!sqlsrv_query($conn, $updateSemente, [$playerID, $frutaID, $playerID, $frutaID, $playerID, $frutaID])) {
        throw new Exception("Erro ao atualizar inventário de sementes.");
    }

    // ✅ Confirma transação
    sqlsrv_commit($conn);
    echo json_encode(['success' => true, 'message' => "✅ Semente de {$nomeFruta} comprada com sucesso usando Poupança!"]);

} catch (Exception $e) {
    // ❌ Erro → desfaz transação
    sqlsrv_rollback($conn);
    echo json_encode(['success' => false, 'message' => "❌ Erro: " . $e->getMessage()]);
}
?>
