<?php
session_start();
include "db.php";
include "check_ban.php"; // protege a página

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// Inicializa loot do jogador se não existir
if(!isset($_SESSION['loot'])) $_SESSION['loot'] = [];

// Verifica se há dungeon ativa
if(!isset($_SESSION['dungeon'])){
    die("Nenhuma dungeon ativa.");
}

// Referência ao inimigo atual na dungeon
$enemy = &$_SESSION['dungeon']['currentEnemy'];

if(!$enemy){
    die("Nenhum inimigo encontrado na dungeon.");
}

// Só dropa se o inimigo morreu (HP <= 0)
if($enemy['HP'] <= 0){

    // Pega loot do inimigo
    $loot = [];
    $stmtLoot = sqlsrv_query($conn, "SELECT ItemName FROM EnemyLoot WHERE EnemyID = ?", [$enemy['EnemyID']]);
    if($stmtLoot === false){
        die("Erro ao buscar loot: " . print_r(sqlsrv_errors(), true));
    }

    while($row = sqlsrv_fetch_array($stmtLoot, SQLSRV_FETCH_ASSOC)){
        $loot[] = $row['ItemName'];
    }

    // Se dropou algo, adiciona ao inventário do jogador
    if(!empty($loot)){
        foreach($loot as $item){
            $_SESSION['loot'][] = $item;
        }

        echo "<h3>Você derrotou {$enemy['Name']} e recebeu:</h3><ul>";
        foreach($loot as $item){
            echo "<li>$item</li>";
        }
        echo "</ul>";
    } else {
        echo "<p>{$enemy['Name']} não dropou nenhum item.</p>";
    }

    // Limpa inimigo da dungeon após o drop
    $_SESSION['dungeon']['currentEnemy'] = null;
}
