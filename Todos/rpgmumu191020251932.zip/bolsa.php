<?php
if (!isset($conn)) { include "db.php"; }
if (!isset($_SESSION)) { session_start(); }

// Verifica login
$playerID = $_SESSION['PlayerID'] ?? null;
if(!$playerID){ die("⛔ Faça login para acessar."); }

// Verifica banimento
$stmt = sqlsrv_query($conn,"SELECT Banido FROM Players WHERE PlayerID=?",[$playerID]);
if($stmt && $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)){
    if(!empty($row['Banido']) && $row['Banido']==1){ die("⛔ Você está banido."); }
}

// Saldo e carteira
$stmt = sqlsrv_query($conn,"SELECT MoedaMumu, CarteiraJSON FROM Players WHERE PlayerID=?",[$playerID]);
$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
$moeda = $row['MoedaMumu'] ?? 500;
$carteira = !empty($row['CarteiraJSON']) ? json_decode($row['CarteiraJSON'],true) : ['Ouro'=>0,'Prata'=>0,'Bronze'=>0,'Cristal'=>0,'Esmeralda'=>0];

// Ativos iniciais
$ativos = [
    ['Nome'=>'Bronze = 10','Preco'=>10],
    ['Nome'=>'Prata = 30','Preco'=>30],
    ['Nome'=>'Ouro = 50','Preco'=>50],
    ['Nome'=>'Cristal = 100','Preco'=>100],
    ['Nome'=>'Esmeralda = 150','Preco'=>150],
];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>📈 Bolsa RPG Futurista</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
body{background:#0a0a0a;color:#fff;font-family:'Orbitron',sans-serif;padding:2em;}
h1{text-align:center;color:#ffd700;text-shadow:0 0 10px #ff0;margin-bottom:1em;}
.moedas{text-align:center;font-size:1.5em;color:#ff9900;font-weight:bold;margin-bottom:1em;transition: all 0.3s ease;}
.ativos{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:1.5em;}
.ativo{background:#111;border:2px solid rgba(255,215,0,0.3);border-radius:1em;padding:1.5em;text-align:center;position:relative;overflow:hidden;transition: transform 0.2s, box-shadow 0.3s;}
.ativo:hover{transform:translateY(-0.3em);box-shadow:0 0 1.25em rgba(255,215,0,0.4);}
.ativo h3{color:#ffd700;margin:0.5em 0;font-size:1.5em;}
input[type=number]{width:4em;text-align:center;border-radius:0.5em;padding:0.4em;border:1px solid #555;margin:0.5em 0;}
button{padding:0.6em 1em;margin:0.25em;border:none;border-radius:0.5em;cursor:pointer;font-weight:bold;transition:0.3s;}
.buy{background:linear-gradient(45deg,#28a745,#34d058);color:white;box-shadow:0 0 0.5em rgba(40,167,69,0.6);}
.buy:hover{box-shadow:0 0 1em rgba(40,167,69,0.9);}
.sell{background:linear-gradient(45deg,#dc3545,#ff4b5c);color:white;box-shadow:0 0 0.5em rgba(220,53,69,0.6);}
.sell:hover{box-shadow:0 0 1em rgba(220,53,69,0.9);}
.msg-ativo{font-size:1em;font-weight:bold;position:absolute;top:0.5em;left:50%;transform:translateX(-50%);opacity:0;transition: opacity 0.5s ease;}
.seta{position:absolute;top:10px;right:10px;font-size:1.5em;opacity:0;pointer-events:none;}
@keyframes piscaSeta{0%{opacity:0;transform:translateY(0);}25%{opacity:1;transform:translateY(-5px);}50%{opacity:1;transform:translateY(-10px);}75%{opacity:1;transform:translateY(-5px);}100%{opacity:0;transform:translateY(0);}}
.seta.up{color:#4caf50;animation:piscaSeta 1s ease forwards;}
.seta.down{color:#ff4b5c;animation:piscaSeta 1s ease forwards;}
.moeda-flutua{position:absolute;font-size:1.2em;animation:moedaAnim 1s ease forwards;pointer-events:none;}
@keyframes moedaAnim{0%{transform:translateY(0);opacity:1;}50%{transform:translateY(-30px);opacity:0.8;}100%{transform:translateY(-60px);opacity:0;}}
table{border-collapse:collapse;width:100%;max-width:800px;margin:1em auto;color:#fff;}
th,td{padding:8px;text-align:center;}
th{background:#222;}
td.compra{color:#4caf50;font-weight:bold;}
td.venda{color:#ff4b5c;font-weight:bold;}


/* Navegação futurista */
.nav-futurista {
    text-align: left;
    margin: 20px;
}

/* Botão futurista */
.btn-futurista {
    display: inline-block;
    padding: 10px 20px;
    background: linear-gradient(90deg, #0ff, #08f);
    color: #000;
    font-weight: bold;
    font-family: 'Orbitron', sans-serif;
    border: none;
    border-radius: 8px;
    text-decoration: none;
    box-shadow: 0 0 15px #0ff, 0 0 30px #08f inset;
    transition: 0.3s;
}

.btn-futurista:hover {
    background: linear-gradient(90deg, #08f, #0ff);
    color: #fff;
    box-shadow: 0 0 25px #0ff, 0 0 50px #08f inset;
}


</style>
</head>
<body>
<nav class="nav-futurista">
    <a href="dashboard.php" class="btn-futurista">⬅ Voltar</a>
</nav>
<h1>📈 Bolsa RPG Futurista</h1>
<p class="moedas">💰 Saldo: <span id="saldo"><?= $moeda ?></span> moedas</p>

<div class="ativos">
<?php foreach($ativos as $a):
$qtd = $carteira[$a['Nome']] ?? 0;
?>
<div class="ativo" data-nome="<?= $a['Nome'] ?>">
    <h3><?= $a['Nome'] ?></h3>
    <p>Preço: <span class="preco"><?= $a['Preco'] ?></span> moedas</p>
    <p>Você possui: <span class="qtd"><?= $qtd ?></span></p>
    <input type="number" class="quantidade" value="1" min="1">
    <br>
    <button class="buy">Comprar</button>
    <button class="sell">Vender</button>
    <canvas class="grafico" width="220" height="100"></canvas>
    <div class="msg-ativo"></div>
    <div class="seta"></div>
</div>
<?php endforeach; ?>
</div>

<h2 style="text-align:center;margin-top:2em;color:#ffd700;">📝 Últimas 10 Transações</h2>
<table id="historico-table">
<thead>
<tr>
<th>Data/Hora</th>
<th>Ação</th>
<th>Ativo</th>
<th>Qtd</th>
<th>Preço Unitário</th>
<th>Total</th>
</tr>
</thead>
<tbody></tbody>
</table>

<script>
const charts={};
document.querySelectorAll('.ativo').forEach(div=>{
    const nome=div.dataset.nome;
    const ctx=div.querySelector('.grafico').getContext('2d');
    charts[nome]=new Chart(ctx,{
        type:'line',
        data:{labels:[],datasets:[{label:nome,data:[],borderColor:'#ffd700',backgroundColor:'rgba(255,215,0,0.2)',tension:0.3,pointRadius:0}]},
        options:{responsive:false,plugins:{legend:{display:false}},scales:{x:{display:false},y:{beginAtZero:true}}}
    });
});

// Funções
function flutuarMoeda(el,sinal,qtd){
    for(let i=0;i<Math.min(qtd,10);i++){
        const m=document.createElement('span'); m.className='moeda-flutua'; m.innerText=sinal+'💰';
        document.body.appendChild(m);
        const r=el.getBoundingClientRect();
        m.style.left=r.left+r.width/2+'px'; m.style.top=r.top+'px';
        setTimeout(()=>m.remove(),1000);
    }
}

function mostrarSeta(div,variacao){
    const s=div.querySelector('.seta');
    if(variacao>0){ s.innerText='⬆️'; s.className='seta up'; }
    else if(variacao<0){ s.innerText='⬇️'; s.className='seta down'; }
    else{s.innerText=''; s.className='seta';}
}

function atualizarHistorico(){
    fetch('historico_bolsa.php').then(r=>r.json()).then(data=>{
        if(data.error){ console.warn(data.error); return; }
        const tbody=document.querySelector('#historico-table tbody');
        tbody.innerHTML='';
        data.forEach(h=>{
            const tr=document.createElement('tr');
            const cls=h.acao.toLowerCase()==='compra'?'compra':'venda';
            tr.innerHTML=`<td>${h.datahora}</td><td class="${cls}">${h.acao}</td><td>${h.item}</td><td>${h.qtd}</td><td>${h.preco_unit}</td><td>${h.total}</td>`;
            tbody.appendChild(tr);
        });
    });
}

function transacao(acao,ativo,quantidade){
    quantidade=Math.max(1,parseInt(quantidade));
    fetch('bolsa_ajax.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({acao,ativo,quantidade})})
    .then(r=>r.json()).then(data=>{
        if(data.error){ alert(data.error); return; }
        document.getElementById('saldo').innerText=data.novo_saldo;
        const div=document.querySelector(`[data-nome="${ativo}"]`);
        div.querySelector('.qtd').innerText=data.nova_qtd;
        div.querySelector('.preco').innerText=data.novo_preco;
        charts[ativo].data.labels.push(charts[ativo].data.labels.length+1);
        charts[ativo].data.datasets[0].data.push(data.novo_preco);
        if(charts[ativo].data.labels.length>20){ charts[ativo].data.labels.shift(); charts[ativo].data.datasets[0].data.shift(); }
        charts[ativo].update();
        div.querySelector('.msg-ativo').innerText=data.msg;
        div.querySelector('.msg-ativo').style.color=data.variacao>0?'#4caf50':(data.variacao<0?'#ff4b5c':'#ffd700');
        div.querySelector('.msg-ativo').style.opacity=1;
        setTimeout(()=>{div.querySelector('.msg-ativo').style.opacity=0;},2000);
        mostrarSeta(div,data.variacao);
        flutuarMoeda(div,data.variacao>0?'+':'-',quantidade);
        atualizarHistorico();
    });
}

document.querySelectorAll('.ativo').forEach(div=>{
    const nome=div.dataset.nome;
    const input=div.querySelector('.quantidade');
    div.querySelector('.buy').addEventListener('click',()=>transacao('comprar',nome,input.value));
    div.querySelector('.sell').addEventListener('click',()=>transacao('vender',nome,input.value));
});

// Atualizações automáticas
setInterval(atualizarHistorico,15000);
setInterval(()=>{
    // Atualiza preços aleatórios para gráficos automáticos
    document.querySelectorAll('.ativo').forEach(div=>{
        const nome=div.dataset.nome;
        let preco=parseInt(div.querySelector('.preco').innerText);
        let variacao=Math.floor(Math.random()*11-5); // -5 a +5
        let novo_preco=Math.max(1,preco+variacao);
        div.querySelector('.preco').innerText=novo_preco;
        charts[nome].data.labels.push(charts[nome].data.labels.length+1);
        charts[nome].data.datasets[0].data.push(novo_preco);
        if(charts[nome].data.labels.length>20){ charts[nome].data.labels.shift(); charts[nome].data.datasets[0].data.shift(); }
        charts[nome].update();
        mostrarSeta(div,variacao);
    });
},5000);

atualizarHistorico();
</script>
</body>
</html>
