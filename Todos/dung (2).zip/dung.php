<?php
// dung.php
session_start();
include "db.php";
include "check_ban.php";

// ==========================
// Checa login
// ==========================
if (!isset($_SESSION['PlayerID'])) {
    die("⛔ Acesso negado. Faça login.");
}
$playerID = $_SESSION['PlayerID'];

// ==========================
// Funções auxiliares
// ==========================

// Carrega inventário do banco
function carregarInventario($playerID) {
    global $conn;
    $inventario = [];
    $stmt = sqlsrv_query($conn, "
        SELECT ItemID, Nome, Quantidade, Raridade, Valor, Categoria, PodeUsar, PodeMarcarLixo, PodeEnviarArmazem, PodeSoltar
        FROM dbo.Items
        WHERE PlayerID = ?
    ", [$playerID]);

    if ($stmt) {
        while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            $inventario[$row['ItemID']] = [
                'nome'          => $row['Nome'],
                'qtd'           => intval($row['Quantidade']),
                'raridade'      => $row['Raridade'] ?? 'comum',
                'valor'         => intval($row['Valor'] ?? 0),
                'categoria'     => $row['Categoria'] ?? 'outros',
                'podeUsar'      => (bool)($row['PodeUsar'] ?? true),
                'marcarLixo'    => (bool)($row['PodeMarcarLixo'] ?? true),
                'enviarArmazem' => (bool)($row['PodeEnviarArmazem'] ?? true),
                'soltar'        => (bool)($row['PodeSoltar'] ?? true)
            ];
        }
    }
    return $inventario;
}

// Carrega inimigos
function carregarInimigos() {
    global $conn;
    $stmt = sqlsrv_query($conn, "
        SELECT EnemyID, Name, HP, MaxHP, XP, Loot, Mana, MaxMana, Level
        FROM dbo.Enemies
    ");
    if ($stmt === false) die("❌ Erro ao carregar inimigos: " . print_r(sqlsrv_errors(), true));

    $enemies = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $row['HP'] = $row['HP'] ?? 0;
        $row['MaxHP'] = $row['MaxHP'] ?? $row['HP'];
        $row['Mana'] = $row['Mana'] ?? 0;
        $row['MaxMana'] = $row['MaxMana'] ?? $row['Mana'];
        $row['XP'] = $row['XP'] ?? 0;

        if (!empty($row['Loot'])) {
            $lootParsed = json_decode($row['Loot'], true);
            $row['Loot'] = (json_last_error() === JSON_ERROR_NONE && is_array($lootParsed)) 
                ? $lootParsed 
                : array_map('trim', explode(',', $row['Loot']));
        } else {
            $row['Loot'] = [];
        }

        $enemies[] = $row;
    }
    return $enemies;
}

// Carrega personagem
$stmtChar = sqlsrv_query($conn, "SELECT TOP 1 * FROM dbo.Characters WHERE PlayerID = ?", [$playerID]);
if ($stmtChar === false) die("Erro ao consultar personagem: " . print_r(sqlsrv_errors(), true));
$char = sqlsrv_fetch_array($stmtChar, SQLSRV_FETCH_ASSOC);
if (!$char) die("Você precisa ter pelo menos um personagem. <a href='dashboard.php'>⬅ Voltar</a>");
$char['NextLevelXP'] = intval($char['Level']) * 100;

// ==========================
// Carrega inventário e mescla com sessão
// ==========================
$inventarioDB = carregarInventario($playerID);
foreach ($_SESSION['inventario'] ?? [] as $id => $item) {
    if (isset($inventarioDB[$id])) {
        $inventarioDB[$id]['qtd'] += intval($item['qtd'] ?? 0);
    } else {
        $inventarioDB[$id] = $item;
    }
}
$_SESSION['inventario'] = $inventarioDB;
$inventario = $inventarioDB;

// ==========================
// Inicializa dungeon se necessário
// ==========================
if (!isset($_SESSION['dungeon']) || !is_array($_SESSION['dungeon']) || ($_SESSION['dungeon']['playerID'] ?? 0) != $playerID) {
    $_SESSION['dungeon'] = [
        'playerID' => $playerID,
        'current'  => 0,
        'enemies'  => carregarInimigos(),
        'fim'      => false,
        'char'     => $char
    ];
}
$dungeon = &$_SESSION['dungeon'];
$enemy = &$dungeon['enemies'][$dungeon['current']] ?? null;
$hpZerado = ($char['HP'] ?? 0) <= 0;
$fim = $dungeon['fim'] ?? false;

// ==========================
// Carrega log da sessão
// ==========================
$log = $_SESSION['log'] ?? [];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Dungeon - RPGMumu</title>
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;900&display=swap" rel="stylesheet">
<style>
body {
    font-family: 'Orbitron', Arial, sans-serif;
    background: radial-gradient(circle at top, #0d0d0d 0%, #000000 100%);
    color:#fff;
    text-align:center;
}
.cards-container { display:flex; justify-content:center; flex-wrap:wrap; gap:30px; margin-top:30px; }
.card { background: linear-gradient(145deg, #1a1a1a, #2c2c2c); padding:25px; border-radius:16px; width:300px; box-shadow: 0 0 15px #00ffe0, 0 0 25px #ff00ff inset; border:2px solid #00ffe0; position: relative; overflow: hidden; }
.card:hover { transform: translateY(-8px) scale(1.03); box-shadow: 0 0 30px #00ffe0, 0 0 40px #ff00ff inset; }
.progress { background:#111; border-radius:12px; overflow:hidden; height:22px; margin-bottom:10px; border:1px solid #555; }
.bar { height:100%; transition: width .6s ease-in-out; border-radius:8px; }
.player-bar { background: linear-gradient(90deg,#ff0055,#ff55aa); animation: glowBar 3s infinite alternate; }
.mana-bar { background: linear-gradient(90deg,#0066ff,#00ccff); animation: glowBar 3s infinite alternate; }
.power-bar { background: linear-gradient(90deg,#ffdd33,#ff8800); animation: glowBar 3s infinite alternate; }
.enemy-bar { background: linear-gradient(90deg,#ff4444,#990000); animation: glowBar 3s infinite alternate; }
.enemy-mana-bar { background: linear-gradient(90deg,#33ddff,#3399cc); animation: glowBar 3s infinite alternate; }
.xp-bar { background: linear-gradient(90deg,#33ff33,#00cc00); animation: glowBar 3s infinite alternate; }
@keyframes glowBar { 0% { filter: brightness(0.8); } 50% { filter: brightness(1.3); } 100% { filter: brightness(0.8); } }
#inventario-container { width:90%; margin:25px auto; text-align:left; background:#111; padding:20px; border-radius:12px; box-shadow:0 0 25px #ff00ff, 0 0 15px #00ffe0 inset; border:2px solid #00ffe0; }
#inventario-container table { width:100%; border-collapse:collapse; }
#inventario-container th, #inventario-container td { padding:12px; border:1px solid #333; text-align:center; }
.rar-comum { color:#ccc; }
.rar-raro { color:#00bfff; font-weight:bold; text-shadow:0 0 10px #00bfff; }
.rar-épico { color:#c100ff; font-weight:bold; text-shadow:0 0 14px #c100ff; }
.rar-lendário { color:#ffd700; font-weight:bold; text-shadow:0 0 18px #ffd700; animation: glowLegend 2s infinite alternate; }
@keyframes glowLegend { 0% { text-shadow:0 0 12px #ffd700; } 50% { text-shadow:0 0 24px #ffd700; } 100% { text-shadow:0 0 12px #ffd700; } }
#log { max-height:300px; overflow:auto; text-align:left; margin:25px auto; width:90%; background:#111; padding:15px; border-radius:10px; box-shadow:0 0 15px #00ffe0 inset; border:1px solid #00ffe0; }
#voltar { display:none; color:#00ffe0; text-decoration:none; font-size:1.3em; margin-top:20px; display:inline-block; }
</style>
</head>
<body>
<a id="voltar" href="dashboard.php">⬅️ Voltar</a>
<h1>🗡️ Masmorra - <?= htmlspecialchars($char['Name']) ?></h1>

<?php if ($hpZerado): ?>
<p style="color:red; font-size:1.2em;">💀 Você morreu! Dungeon encerrada.</p>
<?php elseif ($fim): ?>
<p style="color:yellow; font-size:1.2em;">🏁 Parabéns! Todos os inimigos foram derrotados!</p>
<?php endif; ?>

<div class="cards-container">
  <div class="card" id="player-card">
    <h3><?= htmlspecialchars($char['Name']) ?></h3>
    <p>Level: <?= intval($char['Level']) ?> | XP: <?= intval($char['Exp']) ?></p>
    <div class="progress"><div class="bar player-bar" style="width:<?= ($char['MaxHP']>0?($char['HP']/$char['MaxHP']*100):0) ?>%"></div></div>
    <p>HP: <span id="player-hp"><?= intval($char['HP']) ?></span> / <span id="player-maxhp"><?= intval($char['MaxHP']) ?></span></p>
    <div class="progress"><div class="bar mana-bar" style="width:<?= ($char['MaxMana']>0?($char['Mana']/$char['MaxMana']*100):0) ?>%"></div></div>
    <p>Mana: <span id="player-mana"><?= intval($char['Mana']) ?></span> / <span id="player-maxmana"><?= intval($char['MaxMana']) ?></span></p>
    <div class="progress"><div class="bar power-bar" style="width:<?= ($char['MaxPower']>0?($char['Power']/$char['MaxPower']*100):0) ?>%"></div></div>
    <p>Poder: <span id="player-power"><?= intval($char['Power']) ?></span> / <span id="player-maxpower"><?= intval($char['MaxPower']) ?></span></p>
    <div class="progress"><div class="bar xp-bar" style="width:<?= ($char['NextLevelXP']>0?($char['Exp']/$char['NextLevelXP']*100):0) ?>%"></div></div>
    <p>XP: <span id="player-xp"><?= intval($char['Exp']) ?></span> / <span id="player-nextxp"><?= intval($char['NextLevelXP']) ?></span></p>
  </div>

  <?php if ($enemy): ?>
  <div class="card" id="enemy-card">
    <h3><?= htmlspecialchars($enemy['Name']) ?></h3>
    <p>Level: <?= intval($enemy['Level']) ?> | XP: <?= intval($enemy['XP']) ?></p>
    <div class="progress"><div class="bar enemy-bar" style="width:<?= ($enemy['MaxHP']>0?($enemy['HP']/$enemy['MaxHP']*100):0) ?>%"></div></div>
    <p>HP: <span id="enemy-hp"><?= intval($enemy['HP']) ?></span> / <span id="enemy-maxhp"><?= intval($enemy['MaxHP']) ?></span></p>
    <div class="progress"><div class="bar enemy-mana-bar" style="width:<?= ($enemy['MaxMana']>0?($enemy['Mana']/$enemy['MaxMana']*100):0) ?>%"></div></div>
    <p>Mana: <span id="enemy-mana"><?= intval($enemy['Mana']) ?></span> / <span id="enemy-maxmana"><?= intval($enemy['MaxMana']) ?></span></p>
  </div>
  <?php endif; ?>
</div>



<h3>📜 Histórico de Combate</h3>
<div id="log">
<?php foreach ($log as $msg): ?>
<div><?= $msg ?></div>
<?php endforeach; ?>
</div>


<div id="inventario-container">
<h3>📦 Inventário</h3>
<table id="inv-table">
<tr><th>Item</th><th>Quantidade</th><th>Valor</th></tr>
<?php foreach($inventario as $itemID => $dados): ?>
<tr class="rar-<?= htmlspecialchars($dados['raridade']) ?>">
<td><?= htmlspecialchars($dados['nome'] ?? $itemID) ?></td>
<td id="qtd-<?= $itemID ?>"><?= intval($dados['qtd'] ?? 0) ?></td>
<td>💰 <?= intval($dados['valor'] ?? 0) ?></td>
</tr>
<?php endforeach; ?>
</table>
</div>


<script>
// ==========================
// Funções de atualização dinâmica
// ==========================
function safePct(v,m){ return (m>0? Math.max(0, Math.min(1, v/m)) : 0); }

function atualizarBarras(char, enemy){
    document.querySelector('.player-bar').style.width = (safePct(char.HP,char.MaxHP)*100) + '%';
    document.querySelector('.mana-bar').style.width = (safePct(char.Mana,char.MaxMana)*100) + '%';
    document.querySelector('.power-bar').style.width = (safePct(char.Power,char.MaxPower)*100) + '%';
    document.getElementById('player-hp').textContent = char.HP;
    document.getElementById('player-mana').textContent = char.Mana;
    document.getElementById('player-power').textContent = char.Power;

    const nextXP = char.NextLevelXP ?? 100;
    const exp = char.Exp ?? 0;
    document.querySelector('.xp-bar').style.width = (safePct(exp, nextXP)*100) + '%';
    document.getElementById('player-xp').textContent = exp;
    document.getElementById('player-nextxp').textContent = nextXP;

    if(enemy){
        document.querySelector('.enemy-bar').style.width = (safePct(enemy.HP,enemy.MaxHP)*100) + '%';
        document.querySelector('.enemy-mana-bar').style.width = (safePct(enemy.Mana,enemy.MaxMana)*100) + '%';
        document.getElementById('enemy-hp').textContent = enemy.HP;
        document.getElementById('enemy-mana').textContent = enemy.Mana;
    }
}

function atualizarInventario(inv){
    const table = document.getElementById('inv-table');
    table.innerHTML = '<tr><th>Item</th><th>Quantidade</th><th>Valor</th></tr>';
    for(const itemID in inv){
        const d = inv[itemID];
        const tr = document.createElement('tr');
        tr.className = 'rar-' + (d.raridade || 'comum');
        tr.innerHTML = `<td>${d.nome ?? itemID}</td><td id="qtd-${itemID}">${d.qtd ?? 0}</td><td>💰 ${d.valor ?? 0}</td>`;
        table.appendChild(tr);
    }
}

function atualizarLog(logs){
    const el = document.getElementById('log');
    logs.forEach(msg=>{
        const div = document.createElement('div');
        div.innerHTML = msg;
        el.appendChild(div);
    });
    el.scrollTop = el.scrollHeight;
}

function atualizarDungeon(){
    fetch('turno.php')
        .then(r => r.json())
        .then(data => {
            if(!data) return;
            if(data.char) atualizarBarras(data.char, data.enemy);
            if(data.inventario) atualizarInventario(data.inventario);
            if(data.log) atualizarLog(data.log);
            if(data.fim){
                document.getElementById('voltar').style.display = 'inline-block';
            } else {
                setTimeout(atualizarDungeon, 1200);
            }
        })
        .catch(err => console.error('Erro ao atualizar dungeon:', err));
}

<?php if (!$hpZerado && !$fim): ?>
atualizarDungeon();
<?php else: ?>
document.getElementById('voltar').style.display = 'inline-block';
<?php endif; ?>
</script>
</body>
</html>
