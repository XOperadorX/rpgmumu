<?php
session_start();
include "db.php";
include "check_ban.php";

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// Atualiza HP e Mana do personagem
$sql = "UPDATE Characters SET HP = MaxHP, Mana = MaxMana WHERE PlayerID = ?";
$stmt = sqlsrv_query($conn, $sql, [$playerID]);

// Atualiza também na sessão se você estiver usando dados da sessão
if(isset($_SESSION['char'])){
    $_SESSION['char']['HP'] = $_SESSION['char']['MaxHP'];
    $_SESSION['char']['Mana'] = $_SESSION['char']['MaxMana'];
}

// Redireciona de volta para a dungeon
header("Location: dashboard.php");
exit;
