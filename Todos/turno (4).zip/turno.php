<?php
session_start();
include "db.php";
include "check_ban.php";

header('Content-Type: application/json');

$response = ['char'=>null,'enemy'=>null,'log'=>[],'fim'=>false];

if(!isset($_SESSION['PlayerID']) || !isset($_SESSION['dungeon'])){
    echo json_encode($response); exit;
}

$playerID = $_SESSION['PlayerID'];
$dungeon = &$_SESSION['dungeon'];
$enemy = &$dungeon['enemies'][$dungeon['current']] ?? null;

// Pega personagem atualizado
$stmtChar = sqlsrv_query($conn, "SELECT TOP 1 * FROM Characters WHERE PlayerID = ?", [$playerID]);
$char = $stmtChar ? sqlsrv_fetch_array($stmtChar, SQLSRV_FETCH_ASSOC) : null;
if(!$char){ echo json_encode($response); exit; }

$log = [];

// ======================
// Simulação de turno
// ======================
if($enemy && $char['HP']>0){
    $damage = 10; // dano do jogador
    $enemy['HP'] -= $damage;
    if($enemy['HP']<0) $enemy['HP']=0;
    $log[] = "Você causou $damage de dano em {$enemy['Name']}.";

    if($enemy['HP']>0){
        $enemyDamage = 5;
        $char['HP'] -= $enemyDamage;
        if($char['HP']<0) $char['HP']=0;
        $log[] = "{$enemy['Name']} causou $enemyDamage de dano em você.";
    }
}

// ======================
// Loot
// ======================
$lootDrop = [];
if($enemy && $enemy['HP']<=0){
    $stmtLoot = sqlsrv_query($conn, "SELECT ItemName FROM EnemyLoot WHERE EnemyID = ?", [$enemy['EnemyID']]);
    if($stmtLoot){
        while($row = sqlsrv_fetch_array($stmtLoot, SQLSRV_FETCH_ASSOC)){
            $lootDrop[] = $row['ItemName'];
            $_SESSION['loot'][] = $row['ItemName'];
        }
    }
    foreach($lootDrop as $item) $log[] = "🎁 Você recebeu: $item";
    if(empty($lootDrop)) $log[] = "ℹ️ {$enemy['Name']} não dropou nenhum item.";

    // Próximo inimigo
    $dungeon['current']++;
    $enemy = $dungeon['enemies'][$dungeon['current']] ?? null;
    if(!$enemy) $dungeon['fim'] = true;
}

// ======================
// Resposta
// ======================
$response['char'] = [
    'HP'=>$char['HP'],'MaxHP'=>$char['MaxHP'],
    'Mana'=>$char['Mana'],'MaxMana'=>$char['MaxMana'],
    'Exp'=>$char['Exp'],'Level'=>$char['Level'],
    'Power'=>$char['Power'],'MaxPower'=>$char['MaxPower']
];
$response['enemy'] = $enemy ? [
    'HP'=>$enemy['HP'],'MaxHP'=>$enemy['MaxHP'],
    'Mana'=>$enemy['Mana'],'MaxMana'=>$enemy['MaxMana'],
    'XP'=>$enemy['XP'],'Level'=>$enemy['Level'],
    'Name'=>$enemy['Name']
] : null;

$response['log'] = $log;
$response['fim'] = $dungeon['fim'] ?? false;

echo json_encode($response);
