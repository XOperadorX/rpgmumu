<?php
session_start();
include "db.php";
include "check_ban.php";

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// ==========================
// Nome do personagem (Characters)
// ==========================
$stmtChar = sqlsrv_query($conn, "SELECT Name FROM dbo.Characters WHERE PlayerID = ?", [$playerID]);
if($stmtChar === false) die("Erro ao buscar personagem: " . print_r(sqlsrv_errors(), true));
$char = sqlsrv_fetch_array($stmtChar, SQLSRV_FETCH_ASSOC);
$nomeJogador = htmlspecialchars($char['Name'] ?? 'Desconhecido');

// ==========================
// Saldo de moedas (Players)
// ==========================
$stmtMoedas = sqlsrv_query($conn, "SELECT MoedaMumu FROM dbo.Players WHERE PlayerID = ?", [$playerID]);
if($stmtMoedas === false) die("Erro ao buscar saldo: " . print_r(sqlsrv_errors(), true));
$player = sqlsrv_fetch_array($stmtMoedas, SQLSRV_FETCH_ASSOC);
$saldo = intval($player['MoedaMumu'] ?? 0);




// ==========================
// Puxa inventário do banco
// ==========================
$stmtItens = sqlsrv_query($conn, "SELECT ItemID, Nome, Quantidade, Raridade, Valor, Tipo FROM dbo.Items WHERE PlayerID = ?", [$playerID]);
$inventario = [];
if($stmtItens){
    while($row = sqlsrv_fetch_array($stmtItens, SQLSRV_FETCH_ASSOC)){
        $inventario[$row['ItemID']] = [
            'nome' => $row['Nome'],
            'qtd' => intval($row['Quantidade']),
            'raridade' => strtolower($row['Raridade'] ?? 'comum'),
            'valor' => intval($row['Valor'] ?? 10),
            'tipo' => $row['Tipo']
        ];
    }
}

// ==========================
// Mescla com inventário da sessão (drops recentes)
// ==========================
if(isset($_SESSION['inventario'])){
    foreach($_SESSION['inventario'] as $nome => $qtd){
        $encontrado = false;
        foreach($inventario as $id => &$item){
            if($item['nome'] === $nome){
                $item['qtd'] += $qtd;
                $encontrado = true;
                break;
            }
        }
        if(!$encontrado){
            $tempID = -(count($inventario) + 1);
            $inventario[$tempID] = [
                'nome' => $nome,
                'qtd' => $qtd,
                'raridade' => 'comum',
                'valor' => 50,
                'tipo' => 'outro'
            ];
        }
    }
}

// ==========================
// Cores por raridade
// ==========================
$cores = [
    'comum' => 'gray',
    'incomum' => 'green',
    'raro' => 'blue',
    'épico' => 'purple',
    'lendário' => 'orange'
];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Inventário - RPGMumu</title>
<!-- Fonte futurista -->
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&display=swap" rel="stylesheet">

<style>
body { 
    font-family: 'Orbitron', Arial, sans-serif; 
    background:#1c1c1c; 
    color:#fff; 
    text-align:center; 
    margin:0; 
    padding:20px;
}

/* Container do inventário */
#inventario-container { 
    width:90%; 
    margin:20px auto; 
    text-align:left; 
    background:#111; 
    padding:15px; 
    border-radius:10px; 
    box-shadow: 0 0 20px #0ff, 0 0 40px #0ff inset;
    transition: all 0.3s ease-in-out;
}
#inventario-container:hover {
    box-shadow: 0 0 25px #0ff, 0 0 50px #0ff inset;
}

/* Tabela do inventário */
#inventario-container table { 
    width:100%; 
    border-collapse:collapse; 
}
#inventario-container th, #inventario-container td { 
    padding:10px; 
    border:1px solid #333; 
    text-align:center; 
    transition: all 0.2s ease-in-out;
}
#inventario-container th { 
    background: linear-gradient(90deg, #ff00ff, #00ffff); 
    color:#fff; 
    text-transform: uppercase;
}

/* Itens */
.item-box { 
    cursor:pointer; 
    transition: all 0.2s ease-in-out;
}
.item-box:hover { 
    box-shadow: 0 0 15px #ff0, 0 0 30px #f0f inset; 
    transform: scale(1.05);
}

/* Botões vender */
button.vender-btn { 
    background: #e74c3c; 
    color:#fff; 
    border:none; 
    padding:8px 15px; 
    border-radius:5px; 
    cursor:pointer; 
    transition: all 0.2s ease-in-out;
}
button.vender-btn:hover { 
    background: #c0392b; 
    transform: scale(1.05);
}

/* Mensagens */
#mensagem { 
    margin-top:15px; 
    font-weight:bold; 
    color:#0ff; 
    text-shadow: 0 0 5px #0ff;
}

/* Links estilo botão */
a.botao { 
    color:#fff; 
    text-decoration:none; 
    background: linear-gradient(90deg, #3498db, #9b59b6); 
    padding:10px 15px; 
    border-radius:5px; 
    margin:5px; 
    display:inline-block; 
    transition: all 0.2s ease-in-out;
}
a.botao:hover { 
    background: linear-gradient(90deg, #2980b9, #8e44ad); 
    transform: scale(1.05);
}
.info { margin-bottom:20px; font-size:18px; }
.saldo { color:#00ff88; font-weight:bold; }
a.botao, button.botao {
    color:#fff; text-decoration:none; background:#3498db;
    padding:10px 15px; border-radius:5px; margin:5px;
    display:inline-block; border:none; cursor:pointer; font-size:15px;
}


</style>

</head>
<body>

<!-- BOTÕES DE NAVEGAÇÃO -->

<nav>
    <div style="margin-top:25px;">
	
    <form method="post" style="display:flex; gap:10px; align-items:center;">
        <button type="submit" name="refresh" class="botao">🔄 Atualizar</button>
    </form>	
	    <a href="dashboard.php" class="botao">⬅ 🏰 Inicio</a>
		<a href="histvend.php" class="botao">📜 Histórico</a>
        <a href="inventario.php" class="botao">⬅ 🎒 Inventário</a>
        <a href="dung.php" class="botao">🗡️ Masmorra</a>


	
    </div>
</nav>


    <div class="info">
        Jogador: <strong><?= $nomeJogador ?></strong><br>
        Saldo atual: <span id="saldo" class="saldo"><?= $saldo ?> 💰 MoedasMumu</span>
    </div>
	

	
<h1>📦 Inventário de Itens</h1>

<div id="inventario-container">
<table>
<tr><th>Item</th><th>Quantidade</th><th>Valor</th><th>Ação</th></tr>
<?php foreach($inventario as $itemID => $dados): 
    $cor = $cores[$dados['raridade']] ?? 'white';
?>
<tr style="border-left:5px solid <?=$cor?>">
<td class="item-box" title="<?=$dados['nome']?> (<?=ucfirst($dados['raridade'])?>)" onclick="equiparItem(<?=$itemID?>)">
    <?=htmlspecialchars($dados['nome'])?>
</td>
<td id="qtd-<?= $itemID ?>"><?= $dados['qtd'] ?></td>
<td>💰 <?= $dados['valor'] ?></td>
<td><button class="vender-btn" onclick="venderItem(<?= $itemID ?>)">Vender</button></td>
</tr>
<?php endforeach; ?>
</table>
</div>

<div id="mensagem"></div>



<script>
function venderItem(itemID){
    fetch('vender_item.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'itemID=' + itemID
    })
    .then(r => r.json())
    .then(res => {
        const msg = document.getElementById('mensagem');
        if(res.sucesso){
            const qtdEl = document.getElementById('qtd-' + itemID);
            if(res.nova_qtd <= 0){
                qtdEl.parentElement.remove();
            } else {
                qtdEl.innerText = res.nova_qtd;
            }
            msg.style.color = '#0f0';
            msg.innerText = 'Item vendido! +' + res.moedas + ' moedas';
        } else {
            msg.style.color = '#f00';
            msg.innerText = res.mensagem;
        }
    })
    .catch(() => {
        document.getElementById('mensagem').innerText = 'Erro na venda.';
    });
}

function equiparItem(itemID){
    fetch('equipamento.php', {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'ItemID=' + itemID
    })
    .then(res => res.json())
    .then(data => {
        const msg = document.getElementById('mensagem');
        if(data.success){
            msg.style.color = '#0f0';
            msg.innerText = 'Item equipado!';
            atualizarEquipamentos();
        } else {
            msg.style.color = '#f00';
            msg.innerText = 'Erro: '+data.error;
        }
    });
}

// Atualiza equipamentos do personagem sem recarregar a página
function atualizarEquipamentos(){
    fetch('mostrar_equipamentos.php')
    .then(res => res.text())
    .then(html => {
        document.getElementById('equipamentos').innerHTML = html;
    });
}

// Carrega equipamentos ao abrir
atualizarEquipamentos();

document.getElementById('saldo').innerText = res.novo_saldo + " 💰 MoedasMumu";

</script>

<!-- Equipamentos -->
<div id="equipamentos" style="margin-top:20px;"></div>
</body>
</html>
