<?php
session_start();
include "db.php";
include "check_ban.php"; // protege a página

if(!isset($_SESSION['PlayerID'])){
    die("Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// ===== 1️⃣ Processar venda =====
if(isset($_POST['vender'])){
    $itemID = intval($_POST['ItemID']);
    $quantidade = intval($_POST['Quantidade']);
    $precoUnitario = intval($_POST['PrecoUnitario']); // preço aleatório enviado pelo form

    // Pegar item do inventário (valida se pertence ao jogador)
    $sql = "SELECT Nome, Quantidade FROM Items WHERE PlayerID=? AND ItemID=?";
    $stmt = sqlsrv_query($conn, $sql, [$playerID, $itemID]);

    if($stmt && ($item = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC))){
        if($quantidade > 0 && $quantidade <= $item['Quantidade']){
            $total = $precoUnitario * $quantidade;

            // Atualiza saldo
            sqlsrv_query($conn, "UPDATE Players SET MoedaMumu = MoedaMumu + ? WHERE PlayerID=?", [$total, $playerID]);

            // Atualiza inventário
            $novaQuant = $item['Quantidade'] - $quantidade;
            if($novaQuant <= 0){
                sqlsrv_query($conn, "DELETE FROM Items WHERE ItemID=? AND PlayerID=?", [$itemID, $playerID]);
            } else {
                sqlsrv_query($conn, "UPDATE Items SET Quantidade=? WHERE ItemID=? AND PlayerID=?", [$novaQuant, $itemID, $playerID]);
            }

            echo "<script>alert('Item vendido com sucesso por $total moedas!');window.location='inventario.php';</script>";
            exit;
        } else {
            echo "<script>alert('Quantidade inválida');window.location='inventario.php';</script>";
            exit;
        }
    } else {
        echo "<script>alert('Item não encontrado');window.location='inventario.php';</script>";
        exit;
    }
}

// ===== 2️⃣ Pegar saldo atual =====
$stmtP = sqlsrv_query($conn, "SELECT MoedaMumu FROM Players WHERE PlayerID=?", [$playerID]);
$moeda = 0;
if($stmtP){
    $player = sqlsrv_fetch_array($stmtP, SQLSRV_FETCH_ASSOC);
    $moeda = $player['MoedaMumu'] ?? 0;
}

// ===== 3️⃣ Pegar inventário com preço aleatório =====
$itens = [];
$stmtI = sqlsrv_query($conn, "SELECT * FROM Items WHERE PlayerID=?", [$playerID]);
if($stmtI){
    while($row = sqlsrv_fetch_array($stmtI, SQLSRV_FETCH_ASSOC)){
        $row['PrecoUnitario'] = rand(10, 150); // preço aleatório entre 10 e 150
        $itens[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Mercado RPG Mumu</title>
<style>
body { background-color: black; color: white; font-family: 'Roboto', sans-serif; margin:0; padding:20px; }
h1,h2,h3 { text-align:center; color:#ffd700; }
.moedas { font-size:1.2em; color:#ff9900; font-weight:bold; text-align:center; }
table { width:80%; margin:20px auto; border-collapse:collapse; background:#1a1a1a; border-radius:10px; overflow:hidden; box-shadow:0 0 10px rgba(255,255,255,0.2); }
th, td { padding:12px; text-align:center; border-bottom:1px solid #333; }
th { background:#333; color:#ffd700; }
tr:hover { background: rgba(255,255,255,0.05); }
button { padding:6px 12px; border:none; border-radius:6px; cursor:pointer; color:white; background:#333; transition:0.3s; }
button:hover { background:#555; }
a { display:block; text-align:center; margin-top:20px; text-decoration:none; color:#00bfff; font-weight:bold; }
a:hover { text-decoration:underline; }
nav { position:fixed; top:20px; left:20px; z-index:1000; }
nav a { display:inline-block; padding:0.5em 1em; background: rgba(0,191,255,0.15); border-radius:0.5em; color:#00bfff; text-decoration:none; font-weight:bold; font-size:1.1em; box-shadow:0 0 10px rgba(0,191,255,0.3); transition:0.3s; }
nav a:hover { color:#1ec8ff; background: rgba(0,191,255,0.25); box-shadow:0 0 15px rgba(0,191,255,0.5); }
@media (max-width:480px){
    nav { top:10px; left:10px; }
    nav a { padding:0.4em 0.8em; font-size:1em; }
}
</style>
</head>
<body>

<nav><a href="dashboard.php">⬅️ Voltar</a></nav>

<h2>💰 Saldo: <?= $moeda ?> moedas</h2>

<h3>📦 Vender Itens do Inventário</h3>
<table border="1" cellpadding="5">
<tr><th>Nome</th><th>Quantidade</th><th>Preço unitário</th><th>Ação</th></tr>
<?php foreach($itens as $i): ?>
<tr>
<td><?= htmlspecialchars($i['Nome']) ?></td>
<td><?= $i['Quantidade'] ?></td>
<td><?= $i['PrecoUnitario'] ?> moedas</td>
<td>
<form method="post" action="inventario.php">
    <input type="hidden" name="ItemID" value="<?= $i['ItemID'] ?>">
    <input type="number" name="Quantidade" value="1" min="1" max="<?= $i['Quantidade'] ?>" style="width:50px;">
    <input type="hidden" name="PrecoUnitario" value="<?= $i['PrecoUnitario'] ?>">
    <button type="submit" name="vender">Vender</button>
</form>
</td>
</tr>
<?php endforeach; ?>
</table>

</body>
</html>
