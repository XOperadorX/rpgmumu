<?php
session_start();
include "db.php";
include "check_ban.php"; // protege a página

header('Content-Type: application/json');

if(!isset($_SESSION['dungeon'])){
    echo json_encode(['fim'=>true, 'msg'=>'A dungeon não está ativa.']);
    exit;
}

$dungeon = &$_SESSION['dungeon'];
$char = &$dungeon['char'];
$currentEnemy = &$dungeon['enemies'][$dungeon['current']] ?? null;
$log = [];

// Se HP do jogador <= 0, termina dungeon
if($char['HP'] <= 0){
    $dungeon['fim'] = true;
    $log[] = "💀 Você morreu! Dungeon encerrada.";
    echo json_encode(['char'=>$char, 'enemy'=>$currentEnemy, 'log'=>$log, 'fim'=>true]);
    exit;
}

// Se não há inimigo, dungeon terminou
if(!$currentEnemy){
    $dungeon['fim'] = true;
    $log[] = "🏁 Todos os inimigos derrotados!";
    echo json_encode(['char'=>$char, 'enemy'=>null, 'log'=>$log, 'fim'=>true]);
    exit;
}

// Ataque do jogador
$damage = rand(5,10) + $char['Level'];
$currentEnemy['HP'] -= $damage;
$currentEnemy['HP'] = max(0, $currentEnemy['HP']);
$log[] = "Você causou $damage de dano no {$currentEnemy['Name']}.";

// Ataque do inimigo se vivo
if($currentEnemy['HP'] > 0){
    $damageEnemy = rand(3,8) + $currentEnemy['Level'];
    $char['HP'] -= $damageEnemy;
    $char['HP'] = max(0, $char['HP']);
    $log[] = "{$currentEnemy['Name']} causou $damageEnemy de dano em você!";
} else {
    $log[] = "✅ Você derrotou {$currentEnemy['Name']}!";
    $char['Exp'] += $currentEnemy['XP'];

    // Loot
    foreach($currentEnemy['Loot'] as $item){
        $dungeon['loot'][] = $item;
        sqlsrv_query($conn, "INSERT INTO Items (PlayerID, CharID, Nome, Quantidade) VALUES (?,?,?,?)",
            [$dungeon['playerID'], $char['CharID'], $item, 1]);
        sqlsrv_query($conn, "INSERT INTO Historico (PlayerID, CharID, Acao, Item) VALUES (?,?,?,?)",
            [$dungeon['playerID'], $char['CharID'], 'Loot', $item]);
        $log[] = "Você pegou: $item";
    }

    // Próximo inimigo
    $dungeon['current']++;
    if(!isset($dungeon['enemies'][$dungeon['current']])){
        $dungeon['fim'] = true;
    }
}

// Level up automático
while($char['Exp'] >= $char['Level']*50){
    $char['Exp'] -= $char['Level']*50;
    $char['Level']++;
    $char['MaxHP'] += 10;
    $char['HP'] = $char['MaxHP'];
    $char['MaxMana'] += 5;
    $char['Mana'] = $char['MaxMana'];
    $log[] = "🎉 Parabéns! Você subiu para o nível {$char['Level']}!";
}

// Atualiza banco
sqlsrv_query($conn, "UPDATE Characters SET HP=?, Mana=?, Exp=?, Level=?, MaxHP=?, MaxMana=? WHERE CharID=?",
    [$char['HP'], $char['Mana'], $char['Exp'], $char['Level'], $char['MaxHP'], $char['MaxMana'], $char['CharID']]);

// Retorna JSON
echo json_encode([
    'char'=>$char,
    'enemy'=>$dungeon['enemies'][$dungeon['current']] ?? null,
    'log'=>$log,
    'fim'=>$dungeon['fim']
]);
