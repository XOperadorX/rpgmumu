<?php
session_start();
include "db.php";

if (!isset($_SESSION['PlayerID'])) {
    die("❌ Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// ===== Carrega saldo e carteira do banco =====
$query = "SELECT MoedaMumu, CarteiraJSON FROM Players WHERE PlayerID = ?";
$stmt = sqlsrv_query($conn, $query, [$playerID]);
if($stmt === false) die(print_r(sqlsrv_errors(), true));

$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
$moeda = $row['MoedaMumu'] ?? 500;
$carteira = !empty($row['CarteiraJSON']) ? json_decode($row['CarteiraJSON'], true) : [
    'Ouro'=>0,'Prata'=>0,'Bronze'=>0,'Cristal'=>0,'Esmeralda'=>0
];

// Ativos disponíveis
$ativos = [
    ['Nome'=>'Ouro','Preco'=>50],
    ['Nome'=>'Prata','Preco'=>30],
    ['Nome'=>'Bronze','Preco'=>10],
    ['Nome'=>'Cristal','Preco'=>100],
    ['Nome'=>'Esmeralda','Preco'=>150],
];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>📈 Bolsa RPG - Animada</title>
<style>
body { background: radial-gradient(circle at top, #111 0%, #000 100%); color: #fff; font-family: 'Roboto', sans-serif; padding:2em; }
h1 { text-align:center; color:#ffd700; text-shadow: 0 0 8px rgba(255,215,0,0.8); margin-bottom:1em; }
.moedas { text-align:center; font-size:1.5em; color:#ff9900; font-weight:bold; margin-bottom:1em; transition: all 0.3s ease; }
.top-bar { display:flex; justify-content:space-between; background:#1a1a1a; padding:1em 2em; border-radius:1em; margin-bottom:1em; }
.top-bar a { color:#00bfff; text-decoration:none; font-weight:bold; }
.top-bar a:hover { color:#1ec8ff; text-decoration:underline; }
.ativos { display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:1.5em; }
.ativo { background:#111; border:2px solid rgba(255,215,0,0.3); border-radius:1em; padding:1.5em; text-align:center; box-shadow:0 0 0.75em rgba(255,215,0,0.15); position:relative; overflow:hidden; transition: transform 0.2s, box-shadow 0.3s; }
.ativo:hover { transform:translateY(-0.3em); box-shadow:0 0 1.25em rgba(255,215,0,0.4); }
.ativo h3 { color:#ffd700; margin:0.5em 0; font-size:1.5em; }
.ativo p { margin:0.5em 0; }
input[type=number] { width:4em; text-align:center; border-radius:0.5em; padding:0.4em; border:1px solid #555; margin:0.5em 0; }
button { padding:0.6em 1em; margin:0.25em; border:none; border-radius:0.5em; cursor:pointer; font-weight:bold; transition:0.3s; }
.buy { background:linear-gradient(45deg,#28a745,#34d058); color:white; box-shadow:0 0 0.5em rgba(40,167,69,0.6); }
.buy:hover { box-shadow:0 0 1em rgba(40,167,69,0.9); }
.sell { background:linear-gradient(45deg,#dc3545,#ff4b5c); color:white; box-shadow:0 0 0.5em rgba(220,53,69,0.6); }
.sell:hover { box-shadow:0 0 1em rgba(220,53,69,0.9); }
.msg { text-align:center; font-weight:bold; margin:1em 0; font-size:1.2em; transition: all 0.3s ease; }
@keyframes moedaAnim { 0% {transform: translateY(0); opacity:1;} 50% {transform: translateY(-30px); opacity:0.8;} 100% {transform: translateY(-60px); opacity:0;} }
.moeda-flutua { position:absolute; font-size:1.2em; animation:moedaAnim 1s ease forwards; pointer-events:none; }
</style>
</head>
<body>

<div class="container">
    <nav class="top-bar">
        <a href="dashboard.php">🏠 Dashboard</a>
        <a href="logout.php">🚪 Sair</a>
    </nav>

    <h1>📈 Bolsa de Valores RPG</h1>
    <p class="moedas">💰 Saldo: <span id="saldo"><?= $moeda ?></span> moedas</p>
    <p class="msg" id="msg"></p>

    <div class="ativos">
    <?php foreach($ativos as $a): 
        $qtd = $carteira[$a['Nome']] ?? 0;
    ?>
        <div class="ativo" data-nome="<?= $a['Nome'] ?>">
            <h3><?= $a['Nome'] ?></h3>
            <p>Preço: <?= $a['Preco'] ?> moedas</p>
            <p>Você possui: <span class="qtd"><?= $qtd ?></span></p>
            <input type="number" class="quantidade" value="1" min="1">
            <br>
            <button class="buy">Comprar</button>
            <button class="sell">Vender</button>
        </div>
    <?php endforeach; ?>
    </div>
</div>

<script>
document.querySelectorAll('.ativo').forEach(div => {
    const nome = div.dataset.nome;
    const input = div.querySelector('.quantidade');
    const qtdSpan = div.querySelector('.qtd');

    div.querySelector('.buy').addEventListener('click', () => {
        ajax(nome, input.value, 'comprar', qtdSpan, '+');
    });

    div.querySelector('.sell').addEventListener('click', () => {
        ajax(nome, input.value, 'vender', qtdSpan, '-');
    });
});

function ajax(ativo, quantidade, acao, qtdSpan, sinal){
    fetch('bolsa_ajax.php', {
        method:'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body:`ativo=${ativo}&quantidade=${quantidade}&acao=${acao}`
    })
    .then(res=>res.json())
    .then(res=>{
        const msgDiv = document.getElementById('msg');
        if(res.status==='ok'){
            document.getElementById('saldo').innerText = res.moeda;
            qtdSpan.innerText = res.carteira[ativo];
            msgDiv.innerText = res.msg;
            msgDiv.style.color = '#4caf50';
            flutuarMoeda(qtdSpan, sinal, quantidade);
        } else {
            msgDiv.innerText = res.msg;
            msgDiv.style.color = '#ff4b5c';
        }
    });
}

// ===== Animação de moedas =====
function flutuarMoeda(element, sinal, quantidade){
    for(let i=0;i<Math.min(quantidade,10);i++){
        const moeda = document.createElement('span');
        moeda.className = 'moeda-flutua';
        moeda.innerText = sinal + '💰';
        document.body.appendChild(moeda);
        const rect = element.getBoundingClientRect();
        moeda.style.left = rect.left + rect.width/2 + 'px';
        moeda.style.top = rect.top + 'px';
        setTimeout(()=>moeda.remove(),1000);
    }
}
</script>

</body>
</html>
