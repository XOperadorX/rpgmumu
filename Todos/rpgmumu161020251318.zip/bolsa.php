<?php
session_start();
include "db.php";

if (!isset($_SESSION['PlayerID'])) {
    die("❌ Acesso negado. Faça login.");
}

$playerID = $_SESSION['PlayerID'];

// ===== Carrega saldo e carteira =====
$query = "SELECT MoedaMumu, CarteiraJSON FROM Players WHERE PlayerID = ?";
$stmt = sqlsrv_query($conn, $query, [$playerID]);
$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

$moeda = $row['MoedaMumu'] ?? 500;
$carteira = !empty($row['CarteiraJSON']) ? json_decode($row['CarteiraJSON'], true) : [
    'Ouro'=>0,'Prata'=>0,'Bronze'=>0,'Cristal'=>0,'Esmeralda'=>0
];

// ===== Ativos iniciais =====
$ativos = [
    ['Nome'=>'Ouro','Preco'=>50],
    ['Nome'=>'Prata','Preco'=>30],
    ['Nome'=>'Bronze','Preco'=>10],
    ['Nome'=>'Cristal','Preco'=>100],
    ['Nome'=>'Esmeralda','Preco'=>150],
];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>📈 Bolsa RPG - Super Imersiva</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
body { background: radial-gradient(circle at top, #111 0%, #000 100%); color: #fff; font-family: 'Roboto', sans-serif; padding:2em; }
h1 { text-align:center; color:#ffd700; text-shadow: 0 0 8px rgba(255,215,0,0.8); margin-bottom:1em; }
.moedas { text-align:center; font-size:1.5em; color:#ff9900; font-weight:bold; margin-bottom:1em; transition: all 0.3s ease; }
.ativos { display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:1.5em; }
.ativo { background:#111; border:2px solid rgba(255,215,0,0.3); border-radius:1em; padding:1.5em; text-align:center; box-shadow:0 0 0.75em rgba(255,215,0,0.15); transition: transform 0.2s, box-shadow 0.3s; position:relative; overflow:hidden; }
.ativo:hover { transform:translateY(-0.3em); box-shadow:0 0 1.25em rgba(255,215,0,0.4); }
.ativo h3 { color:#ffd700; margin:0.5em 0; font-size:1.5em; }
.ativo p { margin:0.5em 0; }
input[type=number] { width:4em; text-align:center; border-radius:0.5em; padding:0.4em; border:1px solid #555; margin:0.5em 0; }
button { padding:0.6em 1em; margin:0.25em; border:none; border-radius:0.5em; cursor:pointer; font-weight:bold; transition:0.3s; }
.buy { background:linear-gradient(45deg,#28a745,#34d058); color:white; box-shadow:0 0 0.5em rgba(40,167,69,0.6); }
.buy:hover { box-shadow:0 0 1em rgba(40,167,69,0.9); }
.sell { background:linear-gradient(45deg,#dc3545,#ff4b5c); color:white; box-shadow:0 0 0.5em rgba(220,53,69,0.6); }
.sell:hover { box-shadow:0 0 1em rgba(220,53,69,0.9); }
.msg { text-align:center; font-weight:bold; margin:1em 0; font-size:1.2em; transition: all 0.3s ease; }
.msg-ativo { font-size: 1em; font-weight: bold; transition: opacity 0.5s ease; position: absolute; top: 0.5em; left: 50%; transform: translateX(-50%); }
#msg-global { text-align:center; font-size:1.3em; font-weight:bold; margin-bottom:1em; transition: all 0.5s ease; }
.moeda-flutua { position:absolute; font-size:1.2em; animation:moedaAnim 1s ease forwards; pointer-events:none; }
@keyframes moedaAnim { 0% {transform: translateY(0); opacity:1;} 50% {transform: translateY(-30px); opacity:0.8;} 100% {transform: translateY(-60px); opacity:0;} }
.seta { position: absolute; top: 10px; right: 10px; font-size: 1.5em; opacity: 0; pointer-events: none; }
@keyframes piscaSeta { 0% {opacity:0; transform:translateY(0);} 25%{opacity:1; transform:translateY(-5px);}50%{opacity:1; transform:translateY(-10px);}75%{opacity:1; transform:translateY(-5px);}100%{opacity:0; transform:translateY(0);} }
.seta.up { color:#4caf50; animation:piscaSeta 1s ease forwards; }
.seta.down { color:#ff4b5c; animation:piscaSeta 1s ease forwards; }
nav { display:flex; justify-content:center; align-items:center; margin:20px; }
nav a, nav button { margin: 0 10px; background: #333; border-radius:8px; padding:10px 20px; color:#fff; font-weight:bold; text-decoration:none; transition:0.3s; cursor:pointer; }
nav a:hover, nav button:hover { background:#ffcc00; color:#000; box-shadow:0 0 15px #ffcc0077; }

/* Histórico */
table { border-collapse:collapse; }
table th, table td { padding:8px; }
</style>
</head>
<body>

<nav>
    <form method="post" style="display:flex; gap:15px; justify-content:center; align-items:center;">
        <button type="submit" class="btn" name="refresh">🔄 Atualizar</button>
        <a href="trade.php" class="btn">📈 Trade</a>
        <a href="dashboard.php" class="btn">⬅️ Voltar</a>
    </form>
</nav>

<h1>📈 Bolsa de Valores RPG</h1>
<p class="moedas">💰 Saldo: <span id="saldo"><?= $moeda ?></span> moedas</p>
<div id="msg-global"></div>
<p class="msg" id="msg"></p>

<div class="ativos">
<?php foreach($ativos as $a): 
    $qtd = $carteira[$a['Nome']] ?? 0;
?>
    <div class="ativo" data-nome="<?= $a['Nome'] ?>">
        <h3><?= $a['Nome'] ?></h3>
        <p>Preço: <span class="preco"><?= $a['Preco'] ?></span> moedas</p>
        <p>Você possui: <span class="qtd"><?= $qtd ?></span></p>
        <input type="number" class="quantidade" value="1" min="1">
        <br>
        <button class="buy">Comprar</button>
        <button class="sell">Vender</button>
        <canvas class="grafico" width="220" height="100"></canvas>
        <div class="msg-ativo"></div>
        <div class="seta"></div>
    </div>
<?php endforeach; ?>
</div>

<h2 style="text-align:center; margin-top:2em; color:#ffd700;">📝 Últimas 10 Transações</h2>
<table id="historico-table" style="width:100%; max-width:600px; margin:1em auto; border-collapse:collapse; color:#fff; text-align:center;">
    <thead>
        <tr style="background:#222;">
            <th>Data/Hora</th>
            <th>Ação</th>
            <th>Ativo</th>
            <th>Qtd</th>
        </tr>
    </thead>
    <tbody>
        <!-- Histórico será preenchido pelo JS -->
    </tbody>
</table>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const charts = {};
document.querySelectorAll('.ativo').forEach(div => {
    const nome = div.dataset.nome;
    const ctx = div.querySelector('.grafico').getContext('2d');
    charts[nome] = new Chart(ctx, {
        type: 'line',
        data: { labels: [], datasets: [{ label: nome, data: [], borderColor: '#ffd700', backgroundColor: 'rgba(255,215,0,0.2)', tension:0.3, pointRadius:0 }] },
        options: { responsive:false, plugins:{legend:{display:false}}, scales:{x:{display:false}, y:{beginAtZero:true}} }
    });
});

function flutuarMoeda(element, sinal, quantidade){
    for(let i=0;i<Math.min(quantidade,10);i++){
        const moeda = document.createElement('span');
        moeda.className = 'moeda-flutua';
        moeda.innerText = sinal + '💰';
        document.body.appendChild(moeda);
        const rect = element.getBoundingClientRect();
        moeda.style.left = rect.left + rect.width/2 + 'px';
        moeda.style.top = rect.top + 'px';
        setTimeout(()=>moeda.remove(),1000);
    }
}

function mostrarSeta(div, variacao) {
    const seta = div.querySelector('.seta');
    if(variacao>0){ seta.innerText='⬆️'; seta.className='seta up'; }
    else if(variacao<0){ seta.innerText='⬇️'; seta.className='seta down'; }
    else { seta.innerText=''; seta.className='seta'; return; }
    void seta.offsetWidth;
}

document.querySelectorAll('.ativo').forEach(div=>{
    const nome = div.dataset.nome;
    const input = div.querySelector('.quantidade');
    const qtdSpan = div.querySelector('.qtd');

    div.querySelector('.buy').addEventListener('click', ()=>{ transacao('comprar',nome,input.value,qtdSpan); flutuarMoeda(qtdSpan,'+',input.value); });
    div.querySelector('.sell').addEventListener('click', ()=>{ transacao('vender',nome,input.value,qtdSpan); flutuarMoeda(qtdSpan,'-',input.value); });
});

function transacao(acao, ativo, quantidade, qtdSpan){
    fetch('bolsa_ajax.php',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body: new URLSearchParams({acao, ativo, quantidade})
    }).then(r=>r.json())
    .then(data=>{
        if(data.error){ alert("⚠️ "+data.error); return; }
        document.getElementById('saldo').innerText=data.novo_saldo;
        const div=document.querySelector(`[data-nome="${ativo}"]`);
        div.querySelector('.qtd').innerText=data.nova_qtd;
        div.querySelector('.preco').innerText=data.novo_preco;
        charts[ativo].data.labels.push(charts[ativo].data.labels.length+1);
        charts[ativo].data.datasets[0].data.push(data.novo_preco);
        if(charts[ativo].data.labels.length>20){ charts[ativo].data.labels.shift(); charts[ativo].data.datasets[0].data.shift(); }
        charts[ativo].update();
        div.querySelector('.msg-ativo').innerText=data.msg;
        div.querySelector('.msg-ativo').style.color = data.variacao>0?'#4caf50':(data.variacao<0?'#ff4b5c':'#ffd700');
        div.querySelector('.msg-ativo').style.opacity=1;
        setTimeout(()=>{div.querySelector('.msg-ativo').style.opacity=0;},2000);
        mostrarSeta(div, data.variacao);

        // Atualiza o histórico
        atualizarHistorico();
    }).catch(err=>console.error(err));
}

function atualizarHistorico(){
    fetch('historico_ajax.php')
    .then(r => r.json())
    .then(data => {
        if(data.error){ console.warn(data.error); return; }
        const tbody = document.querySelector('#historico-table tbody');
        tbody.innerHTML = '';
        data.forEach(h => {
            const tr = document.createElement('tr');
            tr.style.borderBottom = '1px solid #555';
            tr.innerHTML = `<td>${h.datahora}</td><td>${h.acao}</td><td>${h.item}</td><td>${h.qtd}</td>`;
            tbody.appendChild(tr);
        });
    }).catch(err => console.error(err));
}

// Atualiza mercado e histórico periodicamente
function atualizarMercado(){
    fetch('bolsa_ajax.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({})})
    .then(r=>r.json())
    .then(data=>{
        if(data.error){ console.warn(data.error); return; }
        document.getElementById('saldo').innerText = data.novo_saldo;
        for(let nome in data.ativos){
            const ativoData = data.ativos[nome];
            const div=document.querySelector(`[data-nome="${nome}"]`);
            if(!div) continue;
            div.querySelector('.preco').innerText = ativoData.preco;
            div.querySelector('.qtd').innerText = ativoData.qtd;
            charts[nome].data.labels.push(charts[nome].data.labels.length+1);
            charts[nome].data.datasets[0].data.push(ativoData.preco);
            if(charts[nome].data.labels.length>20){ charts[nome].data.labels.shift(); charts[nome].data.datasets[0].data.shift(); }
            charts[nome].update();
            mostrarSeta(div, ativoData.variacao);
        }
        atualizarHistorico();
    }).catch(err=>console.error(err));
}

setInterval(atualizarMercado,15000);
atualizarHistorico();
atualizarMercado();
</script>
</body>
</html>
