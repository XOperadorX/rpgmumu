<?php
session_start();
include "db.php";
include "check_ban.php";

header('Content-Type: application/json');

if(!isset($_SESSION['PlayerID'])){
    echo json_encode(['success'=>false,'message'=>"⛔ Acesso negado. Faça login."]);
    exit;
}

// Recebe CharID do POST
$input = json_decode(file_get_contents('php://input'), true);
$charID = $input['CharID'] ?? null;

if(!$charID){
    echo json_encode(['success'=>false,'message'=>"⛔ Personagem inválido."]);
    exit;
}

$playerID = $_SESSION['PlayerID'];
$valorRestaurar = 500;

// Busca atributos atuais do personagem específico
$sql = "SELECT HP, MaxHP, Mana, MaxMana, Power, Exp, Level, MoedaMumu
        FROM Characters c
        JOIN Players p ON c.PlayerID = p.PlayerID
        WHERE c.PlayerID = ? AND c.CharID = ?";
$params = [$playerID, $charID];
$stmt = sqlsrv_query($conn, $sql, $params);
$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

if(!$row){
    echo json_encode(['success'=>false,'message'=>"Erro ao buscar atributos do personagem."]);
    exit;
}

// Verifica se já está tudo completo
$hpFull = $row['HP'] >= $row['MaxHP'];
$manaFull = $row['Mana'] >= $row['MaxMana'];
$powerFull = $row['Power'] >= 100; // assume Power máximo 100

if($hpFull && $manaFull && $powerFull){
    echo json_encode([
        'success' => true,
        'message' => "⚡ Atributos já estão completos, nenhum gasto necessário!",
        'HP' => $row['HP'],
        'MaxHP' => $row['MaxHP'],
        'Mana' => $row['Mana'],
        'MaxMana' => $row['MaxMana'],
        'Power' => $row['Power'],
        'Exp' => $row['Exp'],
        'Level' => $row['Level'],
        'MoedaMumu' => $row['MoedaMumu']
    ]);
    exit;
}

// Verifica saldo
$saldo = $row['MoedaMumu'] ?? 0;
if($saldo < $valorRestaurar){
    echo json_encode([
        'success' => false,
        'message' => "⛔ Saldo de MoedaMumu insuficiente. Você precisa de $valorRestaurar MoedaMumu."
    ]);
    exit;
}

// Deduz MoedaMumu
$sql = "UPDATE Players SET MoedaMumu = MoedaMumu - ? WHERE PlayerID = ?";
$params = [$valorRestaurar, $playerID];
sqlsrv_query($conn, $sql, $params);

// Restaura atributos
$sql = "UPDATE Characters SET HP = MaxHP, Mana = MaxMana, Power = 100 WHERE CharID = ? AND PlayerID = ?";
$params = [$charID, $playerID];
sqlsrv_query($conn, $sql, $params);

// Busca atributos atualizados
$sql = "SELECT HP, MaxHP, Mana, MaxMana, Power, Exp, Level, MoedaMumu
        FROM Characters c
        JOIN Players p ON c.PlayerID = p.PlayerID
        WHERE c.CharID = ? AND c.PlayerID = ?";
$params = [$charID, $playerID];
$stmt = sqlsrv_query($conn, $sql, $params);
$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

// Atualiza sessão (opcional)
$_SESSION['char'][$charID] = [
    'HP' => $row['HP'],
    'MaxHP' => $row['MaxHP'],
    'Mana' => $row['Mana'],
    'MaxMana' => $row['MaxMana'],
    'Power' => $row['Power'],
    'Exp' => $row['Exp'],
    'Level' => $row['Level']
];

// Retorna sucesso
echo json_encode([
    'success' => true,
    'message' => "✅ Atributos restaurados por $valorRestaurar MoedaMumu!",
    'HP' => $row['HP'],
    'MaxHP' => $row['MaxHP'],
    'Mana' => $row['Mana'],
    'MaxMana' => $row['MaxMana'],
    'Power' => $row['Power'],
    'Exp' => $row['Exp'],
    'Level' => $row['Level'],
    'MoedaMumu' => $row['MoedaMumu']
]);
