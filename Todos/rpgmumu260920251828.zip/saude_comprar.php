<?php
session_start();
include "db.php";

header('Content-Type: application/json');

if (!isset($_SESSION['PlayerID'])) {
    echo json_encode(['msg'=>'Não logado']);
    exit;
}

$playerID = $_SESSION['PlayerID'];

// Pega saldo
$sql = "SELECT MoedaMumu FROM Players WHERE PlayerID=?";
$stmt = sqlsrv_query($conn, $sql, [$playerID]);
$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
$moeda = (int)($row['MoedaMumu'] ?? 0);

if($moeda >= 20){
    // Deduz 20 moedas
    sqlsrv_query($conn, "UPDATE Players SET MoedaMumu=MoedaMumu-20 WHERE PlayerID=?", [$playerID]);
    // Registra como login extra
    $ip = $_SERVER['REMOTE_ADDR'];
    sqlsrv_query($conn, "INSERT INTO LoginHistory(PlayerID, LoginTime, LoginIP) VALUES (?, GETDATE(), ?)", [$playerID, $ip]);
    echo json_encode(['msg'=>'✅ Você comprou 10 pontos de saúde por 20 MoedaMumu!']);
}else{
    echo json_encode(['msg'=>'❌ Você não tem MoedaMumu suficiente!']);
}
