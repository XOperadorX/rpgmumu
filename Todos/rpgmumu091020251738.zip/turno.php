<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include "db.php"; // conexão SQL Server ($conn)
include "check_ban.php"; // protege a página

header('Content-Type: application/json');

// ===== Verificações iniciais =====
if (!isset($_SESSION['dungeon']) || !is_array($_SESSION['dungeon'])) {
    echo json_encode(['fim'=>true,'msg'=>'A dungeon não está ativa.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$dungeon =& $_SESSION['dungeon'];
if (!isset($dungeon['char']) || !isset($dungeon['playerID'])) {
    echo json_encode(['fim'=>true,'msg'=>'Dungeon inválida.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$char =& $dungeon['char'];
$hora = date('d/m/Y H:i:s');
$log = [];
$currentIndex = isset($dungeon['current']) ? (int)$dungeon['current'] : 0;

// pega inimigo por referência
$currentEnemy =& $dungeon['enemies'][$currentIndex] ?? null;

// 1️⃣ Jogador morreu
if ($char['HP'] <= 0) {
    $log[] = "💀 [$hora] Você morreu! Dungeon encerrada.";
    $dungeon['fim'] = true;
    unset($_SESSION['dungeon']);
    echo json_encode(['char'=>$char,'enemy'=>null,'log'=>$log,'fim'=>true], JSON_UNESCAPED_UNICODE);
    exit;
}

// 2️⃣ Acabou a dungeon
if (!$currentEnemy) {
    $log[] = "🏁 [$hora] Todos os inimigos foram derrotados!";
    $dungeon['fim'] = true;
    unset($_SESSION['dungeon']);
    echo json_encode(['char'=>$char,'enemy'=>null,'log'=>$log,'fim'=>true], JSON_UNESCAPED_UNICODE);
    exit;
}

// garante campos mínimos
$char['Level'] = $char['Level'] ?? 1;
$char['HP'] = $char['HP'] ?? 100;
$char['MaxHP'] = $char['MaxHP'] ?? 100;
$char['Mana'] = $char['Mana'] ?? 50;
$char['MaxMana'] = $char['MaxMana'] ?? 50;
$char['Exp'] = $char['Exp'] ?? 0;
$char['Power'] = $char['Power'] ?? 0;
$char['MaxPower'] = $char['MaxPower'] ?? 0;

$currentEnemy['Level'] = $currentEnemy['Level'] ?? 1;
$currentEnemy['HP'] = $currentEnemy['HP'] ?? 1;
$currentEnemy['MaxHP'] = $currentEnemy['MaxHP'] ?? 1;

// guarda HP anterior
$prevEnemyHP = $currentEnemy['HP'];

// 3️⃣ Ataque do jogador
$damage = rand(5,10) + $char['Level'];
$currentEnemy['HP'] = max(0, $currentEnemy['HP'] - $damage);
$log[] = "<span style='color:blue;'>⚔️ [$hora] {$char['Name']} atacou {$currentEnemy['Name']} causando $damage de dano. HP do inimigo: {$currentEnemy['HP']}/{$currentEnemy['MaxHP']}</span>";

// 4️⃣ Ataque do inimigo
if ($currentEnemy['HP'] > 0) {
    $damageEnemy = rand(3,8) + $currentEnemy['Level'];
    $char['HP'] = max(0, $char['HP'] - $damageEnemy);
    $log[] = "<span style='color:red;'>👹 [$hora] {$currentEnemy['Name']} atacou {$char['Name']} causando $damageEnemy de dano. Seu HP: {$char['HP']}/{$char['MaxHP']}</span>";
} else {
    // 5️⃣ Inimigo derrotado
    $xpGain = $currentEnemy['XP'] ?? 0;
    $log[] = "<span style='color:green;'>✅ [$hora] Você derrotou {$currentEnemy['Name']}! Ganhou {$xpGain} XP.</span>";

    // cópia do personagem para level-up e transação
    $charAfter = $char;
    $charAfter['Exp'] += $xpGain;

    while ($charAfter['Exp'] >= $charAfter['Level']*50) {
        $charAfter['Exp'] -= $charAfter['Level']*50;
        $charAfter['Level']++;
        $charAfter['MaxHP'] += 10;
        $charAfter['HP'] = $charAfter['MaxHP'];
        $charAfter['MaxMana'] += 5;
        $charAfter['Mana'] = $charAfter['MaxMana'];
        $charAfter['MaxPower'] += 3;
        $charAfter['Power'] = $charAfter['MaxPower'];
        $log[] = "🎉 [$hora] Parabéns! Você subiu para o nível {$charAfter['Level']}!";
    }

    // ===== Transação segura =====
    $ok = false;
    $lootGiven = [];

    if (sqlsrv_begin_transaction($conn)) {
        $ok = true;

        if (!empty($currentEnemy['Loot']) && is_array($currentEnemy['Loot'])) {
            foreach ($currentEnemy['Loot'] as $item) {
                // insere item
                $stmtItem = sqlsrv_prepare($conn,
                    "INSERT INTO Items (PlayerID, CharID, Nome, Quantidade) VALUES (?, ?, ?, ?)",
                    [$dungeon['playerID'], $char['CharID'], $item, 1]
                );
                if ($stmtItem === false || !sqlsrv_execute($stmtItem)) {
                    $ok = false; break;
                }

                // histórico com Action = 'Loot' e DataHora automático
                $stmtHist = sqlsrv_prepare($conn,
                    "INSERT INTO Historico (PlayerID, CharID, Action, Item) VALUES (?, ?, ?, ?)",
                    [$dungeon['playerID'], $char['CharID'], 'Loot', $item]
                );
                if ($stmtHist === false || !sqlsrv_execute($stmtHist)) {
                    $ok = false; break;
                }

                $lootGiven[] = $item;
                $log[] = "<span style='color:orange;'>🎁 [$hora] Você pegou: $item</span>";
            }
        }

        // atualiza personagem
        if ($ok) {
            $stmtChar = sqlsrv_prepare($conn,
                "UPDATE Characters SET HP=?, Mana=?, Exp=?, Level=?, MaxHP=?, MaxMana=?, Power=?, MaxPower=? WHERE CharID=?",
                [$charAfter['HP'], $charAfter['Mana'], $charAfter['Exp'], $charAfter['Level'],
                 $charAfter['MaxHP'], $charAfter['MaxMana'], $charAfter['Power'], $charAfter['MaxPower'], $charAfter['CharID']]
            );
            if ($stmtChar === false || !sqlsrv_execute($stmtChar)) $ok = false;
        }

        if ($ok) {
            sqlsrv_commit($conn);
            // aplica mudanças na sessão
            foreach ($lootGiven as $i) $dungeon['loot'][] = $i;
            $fields = ['HP','Mana','Exp','Level','MaxHP','MaxMana','Power','MaxPower'];
            foreach ($fields as $f) $char[$f] = $charAfter[$f];
            $dungeon['enemies'][$currentIndex]['HP'] = 0;

            // próximo inimigo
            $dungeon['current'] = $currentIndex + 1;
            $enemiesLeft = count($dungeon['enemies']) - $dungeon['current'];
            if ($enemiesLeft > 0) {
                $nextEnemy = $dungeon['enemies'][$dungeon['current']]['Name'] ?? 'Desconhecido';
                $log[] = "📌 [$hora] Próximo inimigo: {$nextEnemy}. Inimigos restantes: $enemiesLeft";
            } else {
                $log[] = "🏁 [$hora] Todos os inimigos foram derrotados!";
                $dungeon['fim'] = true;
            }
        } else {
            sqlsrv_rollback($conn);
            $dungeon['enemies'][$currentIndex]['HP'] = $prevEnemyHP;
            $log[] = "<span style='color:gray;'>⛔ [$hora] Erro detectado — alterações desfeitas.</span>";
        }

    } else {
        $log[] = "⚠️ [$hora] Erro ao iniciar transação: ".json_encode(sqlsrv_errors());
    }
}

// ===== Atualiza personagem no banco (garantia final) =====
$stmtCharFinal = sqlsrv_prepare($conn,
    "UPDATE Characters SET HP=?, Mana=?, Exp=?, Level=?, MaxHP=?, MaxMana=?, Power=?, MaxPower=? WHERE CharID=?",
    [$char['HP'],$char['Mana'],$char['Exp'],$char['Level'],$char['MaxHP'],$char['MaxMana'],$char['Power'],$char['MaxPower'],$char['CharID']]
);
if ($stmtCharFinal !== false) @sqlsrv_execute($stmtCharFinal);

// ===== Retorno JSON =====
$output = [
    'char' => $char,
    'enemy' => $dungeon['enemies'][$dungeon['current']] ?? null,
    'log' => $log,
    'fim' => $dungeon['fim'] ?? false
];

if (!empty($dungeon['fim'])) unset($_SESSION['dungeon']);

echo json_encode($output, JSON_UNESCAPED_UNICODE);
exit;
?>
