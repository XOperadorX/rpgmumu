<?php
session_start();
include "db.php";
include "check_ban.php"; // protege a página

if(!isset($_SESSION['PlayerID'])) die('0');
$playerID = $_SESSION['PlayerID'];
$row = sqlsrv_fetch_array(sqlsrv_query($conn,"SELECT MoedaMumu FROM Players WHERE PlayerID=?",[$playerID]),SQLSRV_FETCH_ASSOC);
echo $row['MoedaMumu'] ?? 0;
